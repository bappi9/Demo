﻿using Procurement.IRepository;
using Procurement.Repository;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using MicroRabbit.Infra.Bus;
using Domain.Core.Bus;
using Procurement.FunctionalService;

namespace Procurement
{
    public class DependencyContainer
    {
        public static void RegisterServices(IServiceCollection services)
        {
            //Domain Bus
            services.AddSingleton<IEventBus, RabbitMQBus>(sp =>
            {
                var scopeFactory = sp.GetRequiredService<IServiceScopeFactory>();
                return new RabbitMQBus(sp.GetService<IMediator>(), scopeFactory);
            });
          
            //Subscriptions

           // services.AddTransient<CreateClientAccountDemoEventHandler>();
            //services.AddTransient<EditUserInformationEventHandler>();

            //Domain Events

            //services.AddTransient<IEventHandler<CreateAccountEvent>, CreateAccountEventHandler>();
            //services.AddTransient<IEventHandler<EditPasswordEvent>, EditPasswordEventHandler>();
            
            //Domain Banking Commands

           // services.AddTransient<IRequestHandler<CreateUserCommand, bool>, CreateUserCommandHandler>();
            //services.AddTransient<IRequestHandler<EditRoleManagerCommand, bool>, EditRoleManagerCommandHandler>();
            
            //data
            
            services.AddTransient<IPurchaseRequest , PurchaseRequest>();
            services.AddTransient<IPurchaseRequestApproval, PurchaseRequestApproval>();
            services.AddTransient<IPurchaseOrder , PurchaseOrder>();
            services.AddTransient<IBUPurchaseOrganization, BUPurchaseOrganization>();
            services.AddTransient<IPurchaseOrganization, PurchaseOrganization>();
            services.AddTransient<IRequestForQuotation, RequestForQuotation>();
            services.AddTransient<ISupplierInvoice, SupplierInvoice>();
            services.AddTransient<IPayemntRequest, PaymentRequest>();

            services.AddTransient<ApprovalTransections>();
           // services.AddSingleton<ApprovalTransections>();
            
        }
    }
}
