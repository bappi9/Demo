﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Procurement.Models.Read;

namespace Procurement.DbContexts
{
    public partial class ReadDbContext : DbContext
    {
        public ReadDbContext()
        {
        }

        public ReadDbContext(DbContextOptions<ReadDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TblApprovalConfigHeader> TblApprovalConfigHeader { get; set; }
        public virtual DbSet<TblApprovalConfigRow> TblApprovalConfigRow { get; set; }
        public virtual DbSet<TblApprovalTransectionHeader> TblApprovalTransectionHeader { get; set; }
        public virtual DbSet<TblApprovalTransectionRow> TblApprovalTransectionRow { get; set; }
        public virtual DbSet<TblBillOfMaterialHeader> TblBillOfMaterialHeader { get; set; }
        public virtual DbSet<TblBillOfMaterialRow> TblBillOfMaterialRow { get; set; }
        public virtual DbSet<TblBusinessArea> TblBusinessArea { get; set; }
        public virtual DbSet<TblBusinessPartner> TblBusinessPartner { get; set; }
        public virtual DbSet<TblBusinessPartnerPurchase> TblBusinessPartnerPurchase { get; set; }
        public virtual DbSet<TblBusinessPartnerRequestForQuotationHeader> TblBusinessPartnerRequestForQuotationHeader { get; set; }
        public virtual DbSet<TblBusinessPartnerRequestForQuotationRow> TblBusinessPartnerRequestForQuotationRow { get; set; }
        public virtual DbSet<TblBusinessPartnerSupplyingItem> TblBusinessPartnerSupplyingItem { get; set; }
        public virtual DbSet<TblBusinessUnitCurrency> TblBusinessUnitCurrency { get; set; }
        public virtual DbSet<TblBusinessUnitPurchaseOrganization> TblBusinessUnitPurchaseOrganization { get; set; }
        public virtual DbSet<TblControllingUnit> TblControllingUnit { get; set; }
        public virtual DbSet<TblCostCenter> TblCostCenter { get; set; }
        public virtual DbSet<TblCostElement> TblCostElement { get; set; }
        public virtual DbSet<TblCurrency> TblCurrency { get; set; }
        public virtual DbSet<TblIncoTerms> TblIncoTerms { get; set; }
        public virtual DbSet<TblInventoryTransactionHeader> TblInventoryTransactionHeader { get; set; }
        public virtual DbSet<TblInventoryTransactionRow> TblInventoryTransactionRow { get; set; }
        public virtual DbSet<TblItem> TblItem { get; set; }
        public virtual DbSet<TblItemPlantWarehouse> TblItemPlantWarehouse { get; set; }
        public virtual DbSet<TblItemPurchase> TblItemPurchase { get; set; }
        public virtual DbSet<TblItemRequestHeader> TblItemRequestHeader { get; set; }
        public virtual DbSet<TblItemRequestRow> TblItemRequestRow { get; set; }
        public virtual DbSet<TblItemUomconversion> TblItemUomconversion { get; set; }
        public virtual DbSet<TblModuleFeature> TblModuleFeature { get; set; }
        public virtual DbSet<TblOrganizationalUnitUserPermissionRow> TblOrganizationalUnitUserPermissionRow { get; set; }
        public virtual DbSet<TblPaymentTerms> TblPaymentTerms { get; set; }
        public virtual DbSet<TblPaymentTermsFino> TblPaymentTermsFino { get; set; }
        public virtual DbSet<TblPlant> TblPlant { get; set; }
        public virtual DbSet<TblPoreferenceType> TblPoreferenceType { get; set; }
        public virtual DbSet<TblPriceComponent> TblPriceComponent { get; set; }
        public virtual DbSet<TblPriceComponentType> TblPriceComponentType { get; set; }
        public virtual DbSet<TblPriceStructureHeader> TblPriceStructureHeader { get; set; }
        public virtual DbSet<TblPriceStructureRow> TblPriceStructureRow { get; set; }
        public virtual DbSet<TblPurchaseContractHeader> TblPurchaseContractHeader { get; set; }
        public virtual DbSet<TblPurchaseContractRow> TblPurchaseContractRow { get; set; }
        public virtual DbSet<TblPurchaseContractRowPricingDetail> TblPurchaseContractRowPricingDetail { get; set; }
        public virtual DbSet<TblPurchaseOrderHeader> TblPurchaseOrderHeader { get; set; }
        public virtual DbSet<TblPurchaseOrderReffTypeConfig> TblPurchaseOrderReffTypeConfig { get; set; }
        public virtual DbSet<TblPurchaseOrderRow> TblPurchaseOrderRow { get; set; }
        public virtual DbSet<TblPurchaseOrderRowBillOfMaterialDetail> TblPurchaseOrderRowBillOfMaterialDetail { get; set; }
        public virtual DbSet<TblPurchaseOrderRowPricingDetail> TblPurchaseOrderRowPricingDetail { get; set; }
        public virtual DbSet<TblPurchaseOrderType> TblPurchaseOrderType { get; set; }
        public virtual DbSet<TblPurchaseOrganization> TblPurchaseOrganization { get; set; }
        public virtual DbSet<TblPurchaseRequestHeader> TblPurchaseRequestHeader { get; set; }
        public virtual DbSet<TblPurchaseRequestPending> TblPurchaseRequestPending { get; set; }
        public virtual DbSet<TblPurchaseRequestRow> TblPurchaseRequestRow { get; set; }
        public virtual DbSet<TblPurchaseRequestType> TblPurchaseRequestType { get; set; }
        public virtual DbSet<TblRequestForQuotationHeader> TblRequestForQuotationHeader { get; set; }
        public virtual DbSet<TblRequestForQuotationRow> TblRequestForQuotationRow { get; set; }
        public virtual DbSet<TblSupplierInvoiceHeader> TblSupplierInvoiceHeader { get; set; }
        public virtual DbSet<TblSupplierInvoiceRow> TblSupplierInvoiceRow { get; set; }
        public virtual DbSet<TblUser> TblUser { get; set; }
        public virtual DbSet<TblWarehouse> TblWarehouse { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=test;Database=iBOSDDD;User ID=df;Password=sdfsdfsd;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TblApprovalConfigHeader>(entity =>
            {
                entity.HasKey(e => e.ApprovalConfigId);

                entity.ToTable("tblApprovalConfigHeader", "dco");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsAnyOrder).HasColumnName("isAnyOrder");

                entity.Property(e => e.IsInSequence).HasColumnName("isInSequence");

                entity.Property(e => e.LastActionDateTime).HasColumnType("datetime");

                entity.Property(e => e.PredisorActivityName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ServerDateTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<TblApprovalConfigRow>(entity =>
            {
                entity.HasKey(e => e.RowId)
                    .HasName("PK_tblApprovalConfigRow_1");

                entity.ToTable("tblApprovalConfigRow", "dco");

                entity.Property(e => e.StrUserName)
                    .HasColumnName("strUserName")
                    .HasMaxLength(50);

                entity.Property(e => e.Threshold).HasColumnType("numeric(18, 2)");

                entity.HasOne(d => d.ApprovalConfig)
                    .WithMany(p => p.TblApprovalConfigRow)
                    .HasForeignKey(d => d.ApprovalConfigId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tblApprov__intAp__1E105D02");
            });

            modelBuilder.Entity<TblApprovalTransectionHeader>(entity =>
            {
                entity.HasKey(e => e.IntApprovalTransectionId);

                entity.ToTable("tblApprovalTransectionHeader", "dco");

                entity.Property(e => e.IntApprovalTransectionId).HasColumnName("intApprovalTransectionId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntAnyUsers).HasColumnName("intAnyUsers");

                entity.Property(e => e.IntApprovalConfigId).HasColumnName("intApprovalConfigId");

                entity.Property(e => e.IntPredisorActivityId).HasColumnName("intPredisorActivityId");

                entity.Property(e => e.IntTransectionPkId).HasColumnName("intTransectionPkId");

                entity.Property(e => e.IntUnitId).HasColumnName("intUnitId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsAnyOrder).HasColumnName("isAnyOrder");

                entity.Property(e => e.IsApproved).HasColumnName("isApproved");

                entity.Property(e => e.IsInSequence).HasColumnName("isInSequence");

                entity.Property(e => e.StrPredisorActivityName)
                    .IsRequired()
                    .HasColumnName("strPredisorActivityName")
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblApprovalTransectionRow>(entity =>
            {
                entity.HasKey(e => e.IntRowId);

                entity.ToTable("tblApprovalTransectionRow", "dco");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.IntApprovalTransectionId).HasColumnName("intApprovalTransectionId");

                entity.Property(e => e.IntSequenceId).HasColumnName("intSequenceId");

                entity.Property(e => e.IntUserId).HasColumnName("intUserId");

                entity.Property(e => e.IsApprove).HasColumnName("isApprove");

                entity.Property(e => e.NumThreshold)
                    .HasColumnName("numThreshold")
                    .HasColumnType("numeric(18, 2)");

                entity.Property(e => e.StrUserName)
                    .HasColumnName("strUserName")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<TblBillOfMaterialHeader>(entity =>
            {
                entity.HasKey(e => e.IntBillOfMaterialId);

                entity.ToTable("tblBillOfMaterialHeader", "mes");

                entity.Property(e => e.IntBillOfMaterialId).HasColumnName("intBillOfMaterialId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBoMuoMid).HasColumnName("intBoMUoMId");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntPlantId).HasColumnName("intPlantId");

                entity.Property(e => e.IntShopFloorId).HasColumnName("intShopFloorId");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.IsStandardBoM).HasColumnName("isStandardBoM");

                entity.Property(e => e.NumLotSize)
                    .HasColumnName("numLotSize")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumWastagePercentage)
                    .HasColumnName("numWastagePercentage")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrBillOfMaterialCode)
                    .IsRequired()
                    .HasColumnName("strBillOfMaterialCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrBillOfMaterialName)
                    .IsRequired()
                    .HasColumnName("strBillOfMaterialName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrItemCode)
                    .IsRequired()
                    .HasColumnName("strItemCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblBillOfMaterialRow>(entity =>
            {
                entity.HasKey(e => e.IntBoMrowId);

                entity.ToTable("tblBillOfMaterialRow", "mes");

                entity.Property(e => e.IntBoMrowId).HasColumnName("intBoMRowId");

                entity.Property(e => e.IntBillOfMaterialId).HasColumnName("intBillOfMaterialId");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntUomid).HasColumnName("intUOMId");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.NumQuantity)
                    .HasColumnName("numQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrItemCode)
                    .IsRequired()
                    .HasColumnName("strItemCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblBusinessArea>(entity =>
            {
                entity.HasKey(e => e.IntSbuid);

                entity.ToTable("tblBusinessArea", "fin");

                entity.Property(e => e.IntSbuid).HasColumnName("intSBUId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrBusinessUnitName)
                    .IsRequired()
                    .HasColumnName("strBusinessUnitName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrSbucode)
                    .IsRequired()
                    .HasColumnName("strSBUCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrSbuname)
                    .IsRequired()
                    .HasColumnName("strSBUName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblBusinessPartner>(entity =>
            {
                entity.HasKey(e => e.IntBusinessPartnerId);

                entity.ToTable("tblBusinessPartner", "prt");

                entity.Property(e => e.IntBusinessPartnerId).HasColumnName("intBusinessPartnerId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessPartnerTypeId).HasColumnName("intBusinessPartnerTypeID");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntTaxBracketId).HasColumnName("intTaxBracketId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrAttachmentLink)
                    .HasColumnName("strAttachmentLink")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.StrBin)
                    .HasColumnName("strBIN")
                    .HasMaxLength(20);

                entity.Property(e => e.StrBusinessPartnerAddress)
                    .IsRequired()
                    .HasColumnName("strBusinessPartnerAddress")
                    .HasMaxLength(300);

                entity.Property(e => e.StrBusinessPartnerCode)
                    .IsRequired()
                    .HasColumnName("strBusinessPartnerCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrBusinessPartnerName)
                    .IsRequired()
                    .HasColumnName("strBusinessPartnerName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrContactNumber)
                    .IsRequired()
                    .HasColumnName("strContactNumber")
                    .HasMaxLength(20);

                entity.Property(e => e.StrEmail)
                    .IsRequired()
                    .HasColumnName("strEmail")
                    .HasMaxLength(100);

                entity.Property(e => e.StrLicenseNo)
                    .HasColumnName("strLicenseNo")
                    .HasMaxLength(50);

                entity.Property(e => e.StrNid)
                    .IsRequired()
                    .HasColumnName("strNID")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPartnerSalesType)
                    .HasColumnName("strPartnerSalesType")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblBusinessPartnerPurchase>(entity =>
            {
                entity.HasKey(e => e.IntConfigId)
                    .HasName("PK_tblBusinessPartnerWarehousePurchase");

                entity.ToTable("tblBusinessPartnerPurchase", "prt");

                entity.Property(e => e.IntConfigId).HasColumnName("intConfigId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAcPayGlid).HasColumnName("intAcPayGLId");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntAccruedPayGlid).HasColumnName("intAccruedPayGLId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntAdvanceGlid).HasColumnName("intAdvanceGLId");

                entity.Property(e => e.IntBusinessPartnerId).HasColumnName("intBusinessPartnerId");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntPriceStructureId).HasColumnName("intPriceStructureId");

                entity.Property(e => e.IntPurchaseOrganizationId).HasColumnName("intPurchaseOrganizationId");

                entity.Property(e => e.IntSbuid).HasColumnName("intSBUId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.NumLedgerBalance)
                    .HasColumnName("numLedgerBalance")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumUnbilledAmount)
                    .HasColumnName("numUnbilledAmount")
                    .HasColumnType("numeric(18, 6)");
            });

            modelBuilder.Entity<TblBusinessPartnerRequestForQuotationHeader>(entity =>
            {
                entity.HasKey(e => e.IntPartnerRfqid);

                entity.ToTable("tblBusinessPartnerRequestForQuotationHeader", "pro");

                entity.Property(e => e.IntPartnerRfqid).HasColumnName("intPartnerRFQId");

                entity.Property(e => e.DteIssueDate)
                    .HasColumnName("dteIssueDate")
                    .HasColumnType("date");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteReleaseDate)
                    .HasColumnName("dteReleaseDate")
                    .HasColumnType("date");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DteSupplierRefDate)
                    .HasColumnName("dteSupplierRefDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntBusinessPartnerId).HasColumnName("intBusinessPartnerId");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntLastActionBy).HasColumnName("intLastActionBy");

                entity.Property(e => e.IntRequestForQuotationId).HasColumnName("intRequestForQuotationId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsEmailSend).HasColumnName("isEmailSend");

                entity.Property(e => e.IsQuotationReceived).HasColumnName("isQuotationReceived");

                entity.Property(e => e.StrBusinessPartnerAddress)
                    .IsRequired()
                    .HasColumnName("strBusinessPartnerAddress")
                    .HasMaxLength(300);

                entity.Property(e => e.StrBusinessPartnerCode)
                    .IsRequired()
                    .HasColumnName("strBusinessPartnerCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrBusinessPartnerName)
                    .IsRequired()
                    .HasColumnName("strBusinessPartnerName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrContactNumber)
                    .HasColumnName("strContactNumber")
                    .HasMaxLength(100)
                    .IsFixedLength();

                entity.Property(e => e.StrDocAttachmentLink)
                    .HasColumnName("strDocAttachmentLink")
                    .HasMaxLength(300);

                entity.Property(e => e.StrEmail)
                    .HasColumnName("strEmail")
                    .HasMaxLength(100)
                    .IsFixedLength();

                entity.Property(e => e.StrRequestForQuotationCode)
                    .IsRequired()
                    .HasColumnName("strRequestForQuotationCode")
                    .HasMaxLength(100)
                    .IsFixedLength();

                entity.Property(e => e.StrSupplierRefNo)
                    .IsRequired()
                    .HasColumnName("strSupplierRefNo")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<TblBusinessPartnerRequestForQuotationRow>(entity =>
            {
                entity.HasKey(e => e.IntRowId);

                entity.ToTable("tblBusinessPartnerRequestForQuotationRow", "pro");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntPartnerRfqid).HasColumnName("intPartnerRFQId");

                entity.Property(e => e.IntUoMid).HasColumnName("intUoMId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsSelected).HasColumnName("isSelected");

                entity.Property(e => e.NumRate)
                    .HasColumnName("numRate")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumRequestQuantity)
                    .HasColumnName("numRequestQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumValue)
                    .HasColumnName("numValue")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrItemCode)
                    .IsRequired()
                    .HasColumnName("strItemCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrRemarks)
                    .HasColumnName("strRemarks")
                    .HasMaxLength(500);

                entity.Property(e => e.StrSelectionComments)
                    .HasColumnName("strSelectionComments")
                    .HasMaxLength(500);

                entity.Property(e => e.StrUoMname)
                    .IsRequired()
                    .HasColumnName("strUoMName")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<TblBusinessPartnerSupplyingItem>(entity =>
            {
                entity.HasKey(e => e.IntConfigId);

                entity.ToTable("tblBusinessPartnerSupplyingItem", "itm");

                entity.Property(e => e.IntConfigId).HasColumnName("intConfigId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessPartnerId).HasColumnName("intBusinessPartnerId");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntItemCategoryId).HasColumnName("intItemCategoryId");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrSupplierItemCode)
                    .IsRequired()
                    .HasColumnName("strSupplierItemCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrSupplierItemName)
                    .IsRequired()
                    .HasColumnName("strSupplierItemName")
                    .HasMaxLength(300);
            });

            modelBuilder.Entity<TblBusinessUnitCurrency>(entity =>
            {
                entity.HasKey(e => e.IntConfigId);

                entity.ToTable("tblBusinessUnitCurrency", "dco");

                entity.Property(e => e.IntConfigId).HasColumnName("intConfigId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntCurrencyId).HasColumnName("intCurrencyId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsBaseCurrency).HasColumnName("isBaseCurrency");
            });

            modelBuilder.Entity<TblBusinessUnitPurchaseOrganization>(entity =>
            {
                entity.HasKey(e => e.IntConfigId);

                entity.ToTable("tblBusinessUnitPurchaseOrganization", "pro");

                entity.Property(e => e.IntConfigId).HasColumnName("intConfigId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntPurchaseOrganizationid).HasColumnName("intPurchaseOrganizationid");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrAccountName)
                    .IsRequired()
                    .HasColumnName("strAccountName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrBusinessUnitName)
                    .IsRequired()
                    .HasColumnName("strBusinessUnitName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurchaseOrganization)
                    .IsRequired()
                    .HasColumnName("strPurchaseOrganization")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblControllingUnit>(entity =>
            {
                entity.HasKey(e => e.IntControllingUnitId);

                entity.ToTable("tblControllingUnit", "cco");

                entity.Property(e => e.IntControllingUnitId).HasColumnName("intControllingUnitId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntResponsiblePersonId).HasColumnName("intResponsiblePersonId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrControllingUnitCode)
                    .IsRequired()
                    .HasColumnName("strControllingUnitCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrControllingUnitName)
                    .IsRequired()
                    .HasColumnName("strControllingUnitName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblCostCenter>(entity =>
            {
                entity.HasKey(e => e.IntCostCenterId);

                entity.ToTable("tblCostCenter", "cco");

                entity.Property(e => e.IntCostCenterId).HasColumnName("intCostCenterId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntControllingUnitId).HasColumnName("intControllingUnitId");

                entity.Property(e => e.IntCostCenterGroupId).HasColumnName("intCostCenterGroupId");

                entity.Property(e => e.IntCostCenterTypeId).HasColumnName("intCostCenterTypeId");

                entity.Property(e => e.IntProfitCenterId).HasColumnName("intProfitCenterId");

                entity.Property(e => e.IntResponsiblePersonId).HasColumnName("intResponsiblePersonId");

                entity.Property(e => e.IntSbuid).HasColumnName("intSBUId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrCostCenterCode)
                    .IsRequired()
                    .HasColumnName("strCostCenterCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrCostCenterName)
                    .IsRequired()
                    .HasColumnName("strCostCenterName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblCostElement>(entity =>
            {
                entity.HasKey(e => e.IntCostElementId);

                entity.ToTable("tblCostElement", "cco");

                entity.Property(e => e.IntCostElementId).HasColumnName("intCostElementId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntControllingUnitId).HasColumnName("intControllingUnitId");

                entity.Property(e => e.IntCostCenterId).HasColumnName("intCostCenterId");

                entity.Property(e => e.IntGeneralLedgerId).HasColumnName("intGeneralLedgerId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrCostElementCode)
                    .IsRequired()
                    .HasColumnName("strCostElementCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrCostElementName)
                    .IsRequired()
                    .HasColumnName("strCostElementName")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.IntCostCenter)
                    .WithMany(p => p.TblCostElement)
                    .HasForeignKey(d => d.IntCostCenterId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName(@"FK_tblCostElement
_tblCostCenter");
            });

            modelBuilder.Entity<TblCurrency>(entity =>
            {
                entity.HasKey(e => e.IntCurrencyId);

                entity.ToTable("tblCurrency", "dco");

                entity.Property(e => e.IntCurrencyId).HasColumnName("intCurrencyId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrCurrencyCode)
                    .IsRequired()
                    .HasColumnName("strCurrencyCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrCurrencyName)
                    .IsRequired()
                    .HasColumnName("strCurrencyName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblIncoTerms>(entity =>
            {
                entity.HasKey(e => e.IntIncotermsId)
                    .HasName("PK_tblIncoterms");

                entity.ToTable("tblIncoTerms", "oms");

                entity.Property(e => e.IntIncotermsId).HasColumnName("intIncotermsId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrIncotermsCode)
                    .IsRequired()
                    .HasColumnName("strIncotermsCode")
                    .HasMaxLength(100);

                entity.Property(e => e.StrIncotermsName)
                    .IsRequired()
                    .HasColumnName("strIncotermsName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblInventoryTransactionHeader>(entity =>
            {
                entity.HasKey(e => e.IntInventoryTransactionId);

                entity.ToTable("tblInventoryTransactionHeader", "wms");

                entity.Property(e => e.IntInventoryTransactionId).HasColumnName("intInventoryTransactionId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DteTransactionDate)
                    .HasColumnName("dteTransactionDate")
                    .HasColumnType("date");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessPartnerId).HasColumnName("intBusinessPartnerId");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntCostCenterId).HasColumnName("intCostCenterId");

                entity.Property(e => e.IntEmployeeId).HasColumnName("intEmployeeId");

                entity.Property(e => e.IntPlantId).HasColumnName("intPlantId");

                entity.Property(e => e.IntProjectId).HasColumnName("intProjectId");

                entity.Property(e => e.IntReferenceId).HasColumnName("intReferenceId");

                entity.Property(e => e.IntReferenceTypeId).HasColumnName("intReferenceTypeId");

                entity.Property(e => e.IntSbuid).HasColumnName("intSBUId");

                entity.Property(e => e.IntTransactionTypeId).HasColumnName("intTransactionTypeId");

                entity.Property(e => e.IntWarehouseId).HasColumnName("intWarehouseId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrAccountName)
                    .IsRequired()
                    .HasColumnName("strAccountName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrBusinessPartnerName)
                    .HasColumnName("strBusinessPartnerName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrBusinessUnitName)
                    .IsRequired()
                    .HasColumnName("strBusinessUnitName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrComments)
                    .HasColumnName("strComments")
                    .HasMaxLength(300);

                entity.Property(e => e.StrCostCenterCode)
                    .HasColumnName("strCostCenterCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrCostCenterName)
                    .HasColumnName("strCostCenterName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrDocumentId)
                    .HasColumnName("strDocumentId")
                    .HasMaxLength(100);

                entity.Property(e => e.StrGateEntryNo)
                    .HasColumnName("strGateEntryNo")
                    .HasMaxLength(30);

                entity.Property(e => e.StrInventoryTransactionCode)
                    .IsRequired()
                    .HasColumnName("strInventoryTransactionCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPlantName)
                    .IsRequired()
                    .HasColumnName("strPlantName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrProjectCode)
                    .HasColumnName("strProjectCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrProjectName)
                    .HasColumnName("strProjectName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrReferenceCode)
                    .IsRequired()
                    .HasColumnName("strReferenceCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrReferenceTypeName)
                    .HasColumnName("strReferenceTypeName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrSbuname)
                    .IsRequired()
                    .HasColumnName("strSBUName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrTransactionTypeName)
                    .IsRequired()
                    .HasColumnName("strTransactionTypeName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrWarehouseName)
                    .IsRequired()
                    .HasColumnName("strWarehouseName")
                    .HasMaxLength(100);

                entity.Property(e => e.TransactionGroupName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.IntWarehouse)
                    .WithMany(p => p.TblInventoryTransactionHeader)
                    .HasForeignKey(d => d.IntWarehouseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblInventoryTransactionHeader_tblWarehouse");
            });

            modelBuilder.Entity<TblInventoryTransactionRow>(entity =>
            {
                entity.HasKey(e => e.IntRowId);

                entity.ToTable("tblInventoryTransactionRow", "wms");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBatchId).HasColumnName("intBatchId");

                entity.Property(e => e.IntInventoryLocationId).HasColumnName("intInventoryLocationId");

                entity.Property(e => e.IntInventoryStockTypeId).HasColumnName("intInventoryStockTypeId");

                entity.Property(e => e.IntInventoryTransactionId).HasColumnName("intInventoryTransactionId");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntUoMid).HasColumnName("intUoMId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.MonTransactionValue)
                    .HasColumnName("monTransactionValue")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumTransactionQuantity)
                    .HasColumnName("numTransactionQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrBatchNumber)
                    .HasColumnName("strBatchNumber")
                    .HasMaxLength(50);

                entity.Property(e => e.StrInventoryLocationName)
                    .IsRequired()
                    .HasColumnName("strInventoryLocationName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrInventoryStockTypeName)
                    .HasColumnName("strInventoryStockTypeName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrInventoryTransactionCode)
                    .IsRequired()
                    .HasColumnName("strInventoryTransactionCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrUoMname)
                    .IsRequired()
                    .HasColumnName("strUoMName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblItem>(entity =>
            {
                entity.HasKey(e => e.IntItemId);

                entity.ToTable("tblItem", "itm");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntItemCategoryId).HasColumnName("intItemCategoryId");

                entity.Property(e => e.IntItemSubCategoryId).HasColumnName("intItemSubCategoryId");

                entity.Property(e => e.IntItemTypeId).HasColumnName("intItemTypeId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrHscode)
                    .HasColumnName("strHSCode")
                    .HasMaxLength(100);

                entity.Property(e => e.StrItemCategoryName)
                    .IsRequired()
                    .HasColumnName("strItemCategoryName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrItemCode)
                    .IsRequired()
                    .HasColumnName("strItemCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(200);

                entity.Property(e => e.StrItemSubCategoryName)
                    .IsRequired()
                    .HasColumnName("strItemSubCategoryName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrItemTypeName)
                    .IsRequired()
                    .HasColumnName("strItemTypeName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblItemPlantWarehouse>(entity =>
            {
                entity.HasKey(e => e.IntConfigId);

                entity.ToTable("tblItemPlantWarehouse", "wms");

                entity.Property(e => e.IntConfigId).HasColumnName("intConfigId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBaseUomid).HasColumnName("intBaseUOMId");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntInventoryStockTypeId).HasColumnName("intInventoryStockTypeId");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntPlantId).HasColumnName("intPlantId");

                entity.Property(e => e.IntWarehouseId).HasColumnName("intWarehouseId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsManualCogs).HasColumnName("isManualCOGS");

                entity.Property(e => e.IsMultipleUom).HasColumnName("isMultipleUOM");

                entity.Property(e => e.NumBlockStock)
                    .HasColumnName("numBlockStock")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumCogs)
                    .HasColumnName("numCOGS")
                    .HasColumnType("numeric(18, 6)")
                    .HasComment("Not in Use");

                entity.Property(e => e.NumCurrentStock)
                    .HasColumnName("numCurrentStock")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumGrossWeight)
                    .HasColumnName("numGrossWeight")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumNetWeight)
                    .HasColumnName("numNetWeight")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrBaseUom)
                    .IsRequired()
                    .HasColumnName("strBaseUOM")
                    .HasMaxLength(50);

                entity.Property(e => e.StrBusinessUnitName)
                    .IsRequired()
                    .HasColumnName("strBusinessUnitName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(200);

                entity.Property(e => e.StrPlantName)
                    .IsRequired()
                    .HasColumnName("strPlantName")
                    .HasMaxLength(200);

                entity.Property(e => e.StrWareHouseName)
                    .IsRequired()
                    .HasColumnName("strWareHouseName")
                    .HasMaxLength(200);
            });

            modelBuilder.Entity<TblItemPurchase>(entity =>
            {
                entity.HasKey(e => e.IntConfigId);

                entity.ToTable("tblItemPurchase", "itm");

                entity.Property(e => e.IntConfigId).HasColumnName("intConfigId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntPurchaseOrganizationId).HasColumnName("intPurchaseOrganizationId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsMrp).HasColumnName("isMRP");

                entity.Property(e => e.NumLotSize)
                    .HasColumnName("numLotSize")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumMaxLeadDays)
                    .HasColumnName("numMaxLeadDays")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.NumMinLeadDays)
                    .HasColumnName("numMinLeadDays")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.NumMinOrderQuantity)
                    .HasColumnName("numMinOrderQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrHscode)
                    .HasColumnName("strHSCode")
                    .HasMaxLength(20);

                entity.Property(e => e.StrPurchaseDescription)
                    .HasColumnName("strPurchaseDescription")
                    .HasMaxLength(1000);
            });

            modelBuilder.Entity<TblItemRequestHeader>(entity =>
            {
                entity.HasKey(e => e.IntItemRequestId);

                entity.ToTable("tblItemRequestHeader", "wms");

                entity.Property(e => e.IntItemRequestId).HasColumnName("intItemRequestId");

                entity.Property(e => e.DteApprovedDateTime)
                    .HasColumnName("dteApprovedDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteClosedDateTime)
                    .HasColumnName("dteClosedDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteDueDate)
                    .HasColumnName("dteDueDate")
                    .HasColumnType("date");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteRequestDate)
                    .HasColumnName("dteRequestDate")
                    .HasColumnType("date");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DteValidTill)
                    .HasColumnName("dteValidTill")
                    .HasColumnType("datetime");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntApprovedBy).HasColumnName("intApprovedBy");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntClosedBy).HasColumnName("intClosedBy");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntPlantId).HasColumnName("intPlantId");

                entity.Property(e => e.IntReferenceTypeId).HasColumnName("intReferenceTypeId");

                entity.Property(e => e.IntSbuid).HasColumnName("intSBUId");

                entity.Property(e => e.IntWarehouseId).HasColumnName("intWarehouseId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsApproved).HasColumnName("isApproved");

                entity.Property(e => e.IsClosed).HasColumnName("isClosed");

                entity.Property(e => e.IsComplete).HasColumnName("isComplete");

                entity.Property(e => e.StrAccountName)
                    .IsRequired()
                    .HasColumnName("strAccountName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrApprovedBy)
                    .IsRequired()
                    .HasColumnName("strApprovedBy")
                    .HasMaxLength(100);

                entity.Property(e => e.StrBusinessUnitName)
                    .IsRequired()
                    .HasColumnName("strBusinessUnitName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrClosedBy)
                    .IsRequired()
                    .HasColumnName("strClosedBy")
                    .HasMaxLength(100);

                entity.Property(e => e.StrItemRequestCode)
                    .IsRequired()
                    .HasColumnName("strItemRequestCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPlantName)
                    .IsRequired()
                    .HasColumnName("strPlantName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurpose)
                    .IsRequired()
                    .HasColumnName("strPurpose")
                    .HasMaxLength(100);

                entity.Property(e => e.StrReferenceTypeName)
                    .IsRequired()
                    .HasColumnName("strReferenceTypeName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrSbuname)
                    .IsRequired()
                    .HasColumnName("strSBUName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrWarehouseName)
                    .IsRequired()
                    .HasColumnName("strWarehouseName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblItemRequestRow>(entity =>
            {
                entity.HasKey(e => e.IntRowId);

                entity.ToTable("tblItemRequestRow", "wms");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntItemRequestId).HasColumnName("intItemRequestId");

                entity.Property(e => e.IntUoMid).HasColumnName("intUoMId");

                entity.Property(e => e.NumApprovedQuantity)
                    .HasColumnName("numApprovedQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumIssueQuantity)
                    .HasColumnName("numIssueQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumRequestQuantity)
                    .HasColumnName("numRequestQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrItemCode)
                    .IsRequired()
                    .HasColumnName("strItemCode")
                    .HasMaxLength(100);

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrItemRequestCode)
                    .IsRequired()
                    .HasColumnName("strItemRequestCode")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StrReferenceId)
                    .HasColumnName("strReferenceId")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.StrRemarks)
                    .HasColumnName("strRemarks")
                    .HasMaxLength(300);

                entity.Property(e => e.StrUoMname)
                    .IsRequired()
                    .HasColumnName("strUoMName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblItemUomconversion>(entity =>
            {
                entity.HasKey(e => e.IntConfigId);

                entity.ToTable("tblItemUOMConversion", "itm");

                entity.Property(e => e.IntConfigId).HasColumnName("intConfigId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBaseUom).HasColumnName("intBaseUOM");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntConvertedUom).HasColumnName("intConvertedUOM");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.NumConversionRate)
                    .HasColumnName("numConversionRate")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrBaseUomName)
                    .IsRequired()
                    .HasColumnName("strBaseUomName")
                    .HasMaxLength(50);

                entity.Property(e => e.StrConvertedUomName)
                    .IsRequired()
                    .HasColumnName("strConvertedUomName")
                    .HasMaxLength(50);

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(200);
            });

            modelBuilder.Entity<TblModuleFeature>(entity =>
            {
                entity.HasKey(e => e.IntFeatureId);

                entity.ToTable("tblModuleFeature", "dco");

                entity.Property(e => e.IntFeatureId).HasColumnName("intFeatureId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntModuleId).HasColumnName("intModuleId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsApproval).HasColumnName("isApproval");

                entity.Property(e => e.StrActualFeatureName)
                    .HasColumnName("strActualFeatureName")
                    .HasMaxLength(4000)
                    .HasComputedColumnSql("(replace(concat([strModuleCode],'_',[strFeatureName]),' ','_'))");

                entity.Property(e => e.StrFeatureCode)
                    .HasColumnName("strFeatureCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrFeatureName)
                    .IsRequired()
                    .HasColumnName("strFeatureName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrModuleCode)
                    .IsRequired()
                    .HasColumnName("strModuleCode")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<TblOrganizationalUnitUserPermissionRow>(entity =>
            {
                entity.HasKey(e => e.IntRowId)
                    .HasName("PK_tblOrganizationTypeUserPermission");

                entity.ToTable("tblOrganizationalUnitUserPermissionRow", "dco");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime")
                    .HasComment("This field is used to keep record of every action's date & time in this table.");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("This field is used to keep record of every action's server's date & time in this table. ");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy)
                    .HasColumnName("intActionBy")
                    .HasComment("This field is used for keeping record of its users who will take any action (insert/Update) into this table.");

                entity.Property(e => e.IntOrganizationUnitReffId).HasColumnName("intOrganizationUnitReffId");

                entity.Property(e => e.IntOrganizationUnitTypeId).HasColumnName("intOrganizationUnitTypeId");

                entity.Property(e => e.IntPermissionId).HasColumnName("intPermissionId");

                entity.Property(e => e.IntUserId).HasColumnName("intUserId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))")
                    .HasComment("An acitivity status field.Value of this field will identify whether this Bank Journal header is active or not.");

                entity.Property(e => e.StrOrganizationUnitReffName)
                    .IsRequired()
                    .HasColumnName("strOrganizationUnitReffName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPaymentTerms>(entity =>
            {
                entity.HasKey(e => e.IntPaymentTerms)
                    .HasName("PK_tblPaymentTerms_1");

                entity.ToTable("tblPaymentTerms", "oms");

                entity.Property(e => e.IntPaymentTerms).HasColumnName("intPaymentTerms");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrPaymentTermsCode)
                    .IsRequired()
                    .HasColumnName("strPaymentTermsCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPaymentTermsName)
                    .IsRequired()
                    .HasColumnName("strPaymentTermsName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPaymentTermsFino>(entity =>
            {
                entity.HasKey(e => e.IntPaymentTerms)
                    .HasName("PK_tblPaymentTerms");

                entity.ToTable("tblPaymentTermsFino", "fin");

                entity.Property(e => e.IntPaymentTerms).HasColumnName("intPaymentTerms");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrPaymentTermsCode)
                    .IsRequired()
                    .HasColumnName("strPaymentTermsCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPaymentTermsName)
                    .IsRequired()
                    .HasColumnName("strPaymentTermsName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPlant>(entity =>
            {
                entity.HasKey(e => e.IntPlantId);

                entity.ToTable("tblPlant", "wms");

                entity.Property(e => e.IntPlantId).HasColumnName("intPlantId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrPlantAddress)
                    .IsRequired()
                    .HasColumnName("strPlantAddress")
                    .HasMaxLength(300);

                entity.Property(e => e.StrPlantCode)
                    .IsRequired()
                    .HasColumnName("strPlantCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPlantName)
                    .IsRequired()
                    .HasColumnName("strPlantName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPoreferenceType>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tblPOReferenceType", "pro");

                entity.Property(e => e.IntPoreferenceTypeId)
                    .HasColumnName("intPOReferenceTypeId")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.StrPoreferenceType)
                    .IsRequired()
                    .HasColumnName("strPOReferenceType")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPriceComponent>(entity =>
            {
                entity.HasKey(e => e.IntPriceComponentId);

                entity.ToTable("tblPriceComponent", "itm");

                entity.Property(e => e.IntPriceComponentId).HasColumnName("intPriceComponentId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntGeneralLedgerId).HasColumnName("intGeneralLedgerId");

                entity.Property(e => e.IntPriceComponentTypeId).HasColumnName("intPriceComponentTypeId");

                entity.Property(e => e.IntPriceStructureTypeId).HasColumnName("intPriceStructureTypeId");

                entity.Property(e => e.IntRoundingTypeId).HasColumnName("intRoundingTypeId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.NumFactor)
                    .HasColumnName("numFactor")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrPriceComponentCode)
                    .IsRequired()
                    .HasColumnName("strPriceComponentCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPriceComponentName)
                    .IsRequired()
                    .HasColumnName("strPriceComponentName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPriceStructureTypeName)
                    .HasColumnName("strPriceStructureTypeName")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<TblPriceComponentType>(entity =>
            {
                entity.HasKey(e => e.IntPriceComponentTypeId);

                entity.ToTable("tblPriceComponentType", "itm");

                entity.Property(e => e.IntPriceComponentTypeId).HasColumnName("intPriceComponentTypeId");

                entity.Property(e => e.StrPriceComponentTypeName)
                    .IsRequired()
                    .HasColumnName("strPriceComponentTypeName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPriceStructureHeader>(entity =>
            {
                entity.HasKey(e => e.IntPriceStructureId)
                    .HasName("PK_tblPriceCategoryHeader");

                entity.ToTable("tblPriceStructureHeader", "itm");

                entity.Property(e => e.IntPriceStructureId).HasColumnName("intPriceStructureId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntPriceStructureTypeId).HasColumnName("intPriceStructureTypeId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrPriceStructureCode)
                    .IsRequired()
                    .HasColumnName("strPriceStructureCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPriceStructureName)
                    .IsRequired()
                    .HasColumnName("strPriceStructureName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPriceStructureRow>(entity =>
            {
                entity.HasKey(e => e.IntRowId)
                    .HasName("PK_tblPriceCategoryRow");

                entity.ToTable("tblPriceStructureRow", "itm");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBaseComponentId).HasColumnName("intBaseComponentId");

                entity.Property(e => e.IntPriceComponentId).HasColumnName("intPriceComponentId");

                entity.Property(e => e.IntPriceComponentTypeId).HasColumnName("intPriceComponentTypeId");

                entity.Property(e => e.IntPriceStructureId).HasColumnName("intPriceStructureId");

                entity.Property(e => e.IntSerialNo).HasColumnName("intSerialNo");

                entity.Property(e => e.IntSumFromSerial).HasColumnName("intSumFromSerial");

                entity.Property(e => e.IntSumToSerial).HasColumnName("intSumToSerial");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsInclusive).HasColumnName("isInclusive");

                entity.Property(e => e.IsMannual).HasColumnName("isMannual");

                entity.Property(e => e.NumValue)
                    .HasColumnName("numValue")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrPriceComponentCode)
                    .IsRequired()
                    .HasColumnName("strPriceComponentCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPriceComponentName)
                    .HasColumnName("strPriceComponentName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPriceComponentTypeName)
                    .HasColumnName("strPriceComponentTypeName")
                    .HasMaxLength(50);

                entity.Property(e => e.StrValueType)
                    .IsRequired()
                    .HasColumnName("strValueType")
                    .HasMaxLength(10);
            });

            modelBuilder.Entity<TblPurchaseContractHeader>(entity =>
            {
                entity.HasKey(e => e.IntPurchaseContractId);

                entity.ToTable("tblPurchaseContractHeader", "pro");

                entity.Property(e => e.IntPurchaseContractId).HasColumnName("intPurchaseContractId");

                entity.Property(e => e.DteApproveDatetime)
                    .HasColumnName("dteApproveDatetime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteLastShipmentDate)
                    .HasColumnName("dteLastShipmentDate")
                    .HasColumnType("date");

                entity.Property(e => e.DtePcvalidityDate)
                    .HasColumnName("dtePCValidityDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtePurchaseContractDate)
                    .HasColumnName("dtePurchaseContractDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteReferenceDate)
                    .HasColumnName("dteReferenceDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntApproveBy).HasColumnName("intApproveBy");

                entity.Property(e => e.IntBusinessPartnerId).HasColumnName("intBusinessPartnerId");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntCashOrAdvancePercent).HasColumnName("intCashOrAdvancePercent");

                entity.Property(e => e.IntCreditPercent).HasColumnName("intCreditPercent");

                entity.Property(e => e.IntCurrencyId).HasColumnName("intCurrencyId");

                entity.Property(e => e.IntIncotermsId).HasColumnName("intIncotermsId");

                entity.Property(e => e.IntPaymentDaysAfterDelivery).HasColumnName("intPaymentDaysAfterDelivery");

                entity.Property(e => e.IntPaymentTerms).HasColumnName("intPaymentTerms");

                entity.Property(e => e.IntPlantId).HasColumnName("intPlantId");

                entity.Property(e => e.IntPriceStructureId).HasColumnName("intPriceStructureId");

                entity.Property(e => e.IntPurchaseOrganizationId).HasColumnName("intPurchaseOrganizationId");

                entity.Property(e => e.IntReferenceId).HasColumnName("intReferenceId");

                entity.Property(e => e.IntReferenceTypeId).HasColumnName("intReferenceTypeId");

                entity.Property(e => e.IntSbuId).HasColumnName("intSbuId");

                entity.Property(e => e.IntWarehouseId).HasColumnName("intWarehouseId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsApproved).HasColumnName("isApproved");

                entity.Property(e => e.StrContractType)
                    .HasColumnName("strContractType")
                    .HasMaxLength(50);

                entity.Property(e => e.StrCurrencyCode)
                    .IsRequired()
                    .HasColumnName("strCurrencyCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrDeliveryAddress)
                    .IsRequired()
                    .HasColumnName("strDeliveryAddress")
                    .HasMaxLength(300);

                entity.Property(e => e.StrItemGroupName)
                    .HasColumnName("strItemGroupName")
                    .HasMaxLength(50);

                entity.Property(e => e.StrOtherTerms)
                    .HasColumnName("strOtherTerms")
                    .HasMaxLength(500);

                entity.Property(e => e.StrPlantName)
                    .IsRequired()
                    .HasColumnName("strPlantName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurchaseContractNo)
                    .IsRequired()
                    .HasColumnName("strPurchaseContractNo")
                    .HasMaxLength(50);

                entity.Property(e => e.StrReferenceCode)
                    .HasColumnName("strReferenceCode")
                    .HasMaxLength(100);

                entity.Property(e => e.StrSupplierReference)
                    .HasColumnName("strSupplierReference")
                    .HasMaxLength(100);

                entity.Property(e => e.StrWarehouseName)
                    .IsRequired()
                    .HasColumnName("strWarehouseName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPurchaseContractRow>(entity =>
            {
                entity.HasKey(e => e.IntRowId);

                entity.ToTable("tblPurchaseContractRow", "pro");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.DteDeliveryDateTime)
                    .HasColumnName("dteDeliveryDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntPurchaseContractId).HasColumnName("intPurchaseContractId");

                entity.Property(e => e.IntReferenceId).HasColumnName("intReferenceId");

                entity.Property(e => e.IntUoMid).HasColumnName("intUoMId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.NumBasePrice)
                    .HasColumnName("numBasePrice")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumContractQty)
                    .HasColumnName("numContractQty")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumFinalPrice)
                    .HasColumnName("numFinalPrice")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumReferenceQty)
                    .HasColumnName("numReferenceQty")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumTotalValue)
                    .HasColumnName("numTotalValue")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurchaseDescription)
                    .HasColumnName("strPurchaseDescription")
                    .HasMaxLength(300);

                entity.Property(e => e.StrReferenceCode)
                    .IsRequired()
                    .HasColumnName("strReferenceCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrUoMname)
                    .IsRequired()
                    .HasColumnName("strUoMName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPurchaseContractRowPricingDetail>(entity =>
            {
                entity.HasKey(e => e.IntRowId);

                entity.ToTable("tblPurchaseContractRowPricingDetail", "pro");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.IntBaseComponentId).HasColumnName("intBaseComponentId");

                entity.Property(e => e.IntPriceComponentId).HasColumnName("intPriceComponentId");

                entity.Property(e => e.IntPriceStructureId).HasColumnName("intPriceStructureId");

                entity.Property(e => e.IntPurchaseContractRowId).HasColumnName("intPurchaseContractRowId");

                entity.Property(e => e.IntSequence).HasColumnName("intSequence");

                entity.Property(e => e.IntSumFromSerial).HasColumnName("intSumFromSerial");

                entity.Property(e => e.IntSumToSerial).HasColumnName("intSumToSerial");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsManual).HasColumnName("isManual");

                entity.Property(e => e.NumAmount)
                    .HasColumnName("numAmount")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumFactor)
                    .HasColumnName("numFactor")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.NumValue)
                    .HasColumnName("numValue")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrPriceComponentCode)
                    .HasColumnName("strPriceComponentCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPriceComponentName)
                    .HasColumnName("strPriceComponentName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrValueType)
                    .HasColumnName("strValueType")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<TblPurchaseOrderHeader>(entity =>
            {
                entity.HasKey(e => e.IntPurchaseOrderId);

                entity.ToTable("tblPurchaseOrderHeader", "pro");

                entity.Property(e => e.IntPurchaseOrderId).HasColumnName("intPurchaseOrderId");

                entity.Property(e => e.DteApproveDatetime)
                    .HasColumnName("dteApproveDatetime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteLastShipmentDate)
                    .HasColumnName("dteLastShipmentDate")
                    .HasColumnType("date");

                entity.Property(e => e.DtePovalidityDate)
                    .HasColumnName("dtePOValidityDate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DtePurchaseOrderDate)
                    .HasColumnName("dtePurchaseOrderDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteReferenceDate)
                    .HasColumnName("dteReferenceDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteReturnDateTime)
                    .HasColumnName("dteReturnDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntApproveBy).HasColumnName("intApproveBy");

                entity.Property(e => e.IntBusinessPartnerId).HasColumnName("intBusinessPartnerId");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntCashOrAdvancePercent).HasColumnName("intCashOrAdvancePercent");

                entity.Property(e => e.IntCreditPercent).HasColumnName("intCreditPercent");

                entity.Property(e => e.IntCurrencyId).HasColumnName("intCurrencyId");

                entity.Property(e => e.IntIncotermsId).HasColumnName("intIncotermsId");

                entity.Property(e => e.IntPaymentDaysAfterDelivery).HasColumnName("intPaymentDaysAfterDelivery");

                entity.Property(e => e.IntPaymentTerms).HasColumnName("intPaymentTerms");

                entity.Property(e => e.IntPlantId).HasColumnName("intPlantId");

                entity.Property(e => e.IntPriceStructureId).HasColumnName("intPriceStructureId");

                entity.Property(e => e.IntPurchaseOrderTypeId).HasColumnName("intPurchaseOrderTypeId");

                entity.Property(e => e.IntPurchaseOrganizationId).HasColumnName("intPurchaseOrganizationId");

                entity.Property(e => e.IntReferenceTypeId).HasColumnName("intReferenceTypeId");

                entity.Property(e => e.IntSbuid).HasColumnName("intSBUId");

                entity.Property(e => e.IntSupplyingWarehouseId).HasColumnName("intSupplyingWarehouseId");

                entity.Property(e => e.IntWarehouseId).HasColumnName("intWarehouseId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsApproved).HasColumnName("isApproved");

                entity.Property(e => e.IsClosed).HasColumnName("isClosed");

                entity.Property(e => e.StrBusinessPartnerName)
                    .HasColumnName("strBusinessPartnerName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrCurrencyCode)
                    .IsRequired()
                    .HasColumnName("strCurrencyCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrDeliveryAddress)
                    .IsRequired()
                    .HasColumnName("strDeliveryAddress")
                    .HasMaxLength(300);

                entity.Property(e => e.StrOtherTerms)
                    .HasColumnName("strOtherTerms")
                    .HasMaxLength(500);

                entity.Property(e => e.StrPlantName)
                    .IsRequired()
                    .HasColumnName("strPlantName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurchaseOrderNo)
                    .IsRequired()
                    .HasColumnName("strPurchaseOrderNo")
                    .HasMaxLength(50);

                entity.Property(e => e.StrSupplierReference)
                    .HasColumnName("strSupplierReference")
                    .HasMaxLength(100);

                entity.Property(e => e.StrSupplyingWarehouseName)
                    .HasColumnName("strSupplyingWarehouseName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrWarehouseName)
                    .IsRequired()
                    .HasColumnName("strWarehouseName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPurchaseOrderReffTypeConfig>(entity =>
            {
                entity.HasKey(e => e.IntConfigId);

                entity.ToTable("tblPurchaseOrderReffTypeConfig", "pro");

                entity.Property(e => e.IntConfigId).HasColumnName("intConfigId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntPoreferenceTypeId).HasColumnName("intPOReferenceTypeId");

                entity.Property(e => e.IntPurchaseOrderTypeId).HasColumnName("intPurchaseOrderTypeId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrPoreferenceType)
                    .IsRequired()
                    .HasColumnName("strPOReferenceType")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurchaseOrderTypeName)
                    .IsRequired()
                    .HasColumnName("strPurchaseOrderTypeName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPurchaseOrderRow>(entity =>
            {
                entity.HasKey(e => e.IntRowId);

                entity.ToTable("tblPurchaseOrderRow", "pro");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntControllingUnitId).HasColumnName("intControllingUnitId");

                entity.Property(e => e.IntCostCenterId).HasColumnName("intCostCenterId");

                entity.Property(e => e.IntCostElementId).HasColumnName("intCostElementId");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntPurchaseOrderId).HasColumnName("intPurchaseOrderId");

                entity.Property(e => e.IntReferenceId).HasColumnName("intReferenceId");

                entity.Property(e => e.IntUoMid).HasColumnName("intUoMId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.NumBasePrice)
                    .HasColumnName("numBasePrice")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumFinalPrice)
                    .HasColumnName("numFinalPrice")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumOrderQty)
                    .HasColumnName("numOrderQty")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumReferenceQty)
                    .HasColumnName("numReferenceQty")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumTotalValue)
                    .HasColumnName("numTotalValue")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrControllingUnitName)
                    .HasColumnName("strControllingUnitName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrCostCenterName)
                    .HasColumnName("strCostCenterName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrCostElementName)
                    .HasColumnName("strCostElementName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurchaseDescription)
                    .HasColumnName("strPurchaseDescription")
                    .HasMaxLength(100)
                    .IsFixedLength();

                entity.Property(e => e.StrReferenceCode)
                    .IsRequired()
                    .HasColumnName("strReferenceCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrUoMname)
                    .IsRequired()
                    .HasColumnName("strUoMName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPurchaseOrderRowBillOfMaterialDetail>(entity =>
            {
                entity.HasKey(e => e.IntRowId);

                entity.ToTable("tblPurchaseOrderRowBillOfMaterialDetail", "pro");

                entity.Property(e => e.IntRowId)
                    .HasColumnName("intRowId")
                    .ValueGeneratedNever();

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBillOfMaterialCode)
                    .IsRequired()
                    .HasColumnName("intBillOfMaterialCode")
                    .HasMaxLength(50);

                entity.Property(e => e.IntBillOfMaterialId).HasColumnName("intBillOfMaterialId");

                entity.Property(e => e.IntBomitemId).HasColumnName("intBOMItemId");

                entity.Property(e => e.IntBomitemUnitOfMeasureId).HasColumnName("intBOMItemUnitOfMeasureId");

                entity.Property(e => e.IntPurchaseOrderRowId).HasColumnName("intPurchaseOrderRowId");

                entity.Property(e => e.IntPurchaseOrderRowItemId).HasColumnName("intPurchaseOrderRowItemId");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.NumBomitemNetWeightKg)
                    .HasColumnName("numBOMItemNetWeightKg")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumBomitemQuantity)
                    .HasColumnName("numBOMItemQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrBillOfMaterialName)
                    .IsRequired()
                    .HasColumnName("strBillOfMaterialName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrBomitemName)
                    .IsRequired()
                    .HasColumnName("strBOMItemName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPurchaseOrderRowPricingDetail>(entity =>
            {
                entity.HasKey(e => e.IntRowId);

                entity.ToTable("tblPurchaseOrderRowPricingDetail", "pro");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.IntBaseComponentId).HasColumnName("intBaseComponentId");

                entity.Property(e => e.IntPriceComponentId).HasColumnName("intPriceComponentId");

                entity.Property(e => e.IntPriceStructureId).HasColumnName("intPriceStructureId");

                entity.Property(e => e.IntPurchaseOrderRowId).HasColumnName("intPurchaseOrderRowId");

                entity.Property(e => e.IntSequence).HasColumnName("intSequence");

                entity.Property(e => e.IntSumFromSerial).HasColumnName("intSumFromSerial");

                entity.Property(e => e.IntSumToSerial).HasColumnName("intSumToSerial");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsManual).HasColumnName("isManual");

                entity.Property(e => e.NumAmount)
                    .HasColumnName("numAmount")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumFactor)
                    .HasColumnName("numFactor")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.NumValue)
                    .HasColumnName("numValue")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrPriceComponentCode)
                    .HasColumnName("strPriceComponentCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPriceComponentName)
                    .HasColumnName("strPriceComponentName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrValueType)
                    .HasColumnName("strValueType")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<TblPurchaseOrderType>(entity =>
            {
                entity.HasKey(e => e.IntPurchaseOrderTypeId);

                entity.ToTable("tblPurchaseOrderType", "pro");

                entity.Property(e => e.IntPurchaseOrderTypeId).HasColumnName("intPurchaseOrderTypeId");

                entity.Property(e => e.IntPurchaseRequestTypeId).HasColumnName("intPurchaseRequestTypeId");

                entity.Property(e => e.StrPurchaseOrderTypeName)
                    .IsRequired()
                    .HasColumnName("strPurchaseOrderTypeName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPurchaseOrganization>(entity =>
            {
                entity.HasKey(e => e.IntPurchaseOrganizationid);

                entity.ToTable("tblPurchaseOrganization", "pro");

                entity.Property(e => e.IntPurchaseOrganizationid).HasColumnName("intPurchaseOrganizationid");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IsActive)
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrPurchaseOrganization)
                    .IsRequired()
                    .HasColumnName("strPurchaseOrganization")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPurchaseRequestHeader>(entity =>
            {
                entity.HasKey(e => e.IntPurchaseRequestId);

                entity.ToTable("tblPurchaseRequestHeader", "pro");

                entity.Property(e => e.IntPurchaseRequestId).HasColumnName("intPurchaseRequestId");

                entity.Property(e => e.DteApprovedDateTime)
                    .HasColumnName("dteApprovedDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteClosedDateTime)
                    .HasColumnName("dteClosedDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteRequestDate)
                    .HasColumnName("dteRequestDate")
                    .HasColumnType("date");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntApprovedBy).HasColumnName("intApprovedBy");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntClosedBy).HasColumnName("intClosedBy");

                entity.Property(e => e.IntPlantId).HasColumnName("intPlantId");

                entity.Property(e => e.IntPurchaseOrganizationId).HasColumnName("intPurchaseOrganizationId");

                entity.Property(e => e.IntPurchaseRequestTypeId).HasColumnName("intPurchaseRequestTypeId");

                entity.Property(e => e.IntSbuid).HasColumnName("intSBUId");

                entity.Property(e => e.IntSupplyingWarehouseId).HasColumnName("intSupplyingWarehouseId");

                entity.Property(e => e.IntWarehouseId).HasColumnName("intWarehouseId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsApproved).HasColumnName("isApproved");

                entity.Property(e => e.IsClosed).HasColumnName("isClosed");

                entity.Property(e => e.IsComplete).HasColumnName("isComplete");

                entity.Property(e => e.StrAccountName)
                    .IsRequired()
                    .HasColumnName("strAccountName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrApprovedBy)
                    .HasColumnName("strApprovedBy")
                    .HasMaxLength(100);

                entity.Property(e => e.StrBusinessUnitName)
                    .IsRequired()
                    .HasColumnName("strBusinessUnitName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrClosedBy)
                    .HasColumnName("strClosedBy")
                    .HasMaxLength(100);

                entity.Property(e => e.StrDeliveryAddress)
                    .IsRequired()
                    .HasColumnName("strDeliveryAddress")
                    .HasMaxLength(300);

                entity.Property(e => e.StrPlantName)
                    .IsRequired()
                    .HasColumnName("strPlantName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurchaseOrganizationName)
                    .IsRequired()
                    .HasColumnName("strPurchaseOrganizationName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurchaseRequestCode)
                    .HasColumnName("strPurchaseRequestCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPurchaseRequestTypeName)
                    .IsRequired()
                    .HasColumnName("strPurchaseRequestTypeName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrReffNo)
                    .HasColumnName("strReffNo")
                    .HasMaxLength(100);

                entity.Property(e => e.StrSbuname)
                    .IsRequired()
                    .HasColumnName("strSBUName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrSupplyingWarehouseName)
                    .HasColumnName("strSupplyingWarehouseName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrWarehouseName)
                    .IsRequired()
                    .HasColumnName("strWarehouseName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPurchaseRequestPending>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tblPurchaseRequestPending", "pro");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntPurchaseRequestId).HasColumnName("intPurchaseRequestId");

                entity.Property(e => e.IntUoMid).HasColumnName("intUoMId");

                entity.Property(e => e.NumApprovedQuantity)
                    .HasColumnName("numApprovedQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumPendingQuantity)
                    .HasColumnName("numPendingQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrItemCode)
                    .IsRequired()
                    .HasColumnName("strItemCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurchaseRequestCode)
                    .IsRequired()
                    .HasColumnName("strPurchaseRequestCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrUoMname)
                    .IsRequired()
                    .HasColumnName("strUoMName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPurchaseRequestRow>(entity =>
            {
                entity.HasKey(e => e.IntRowId);

                entity.ToTable("tblPurchaseRequestRow", "pro");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.DteRequiredDate)
                    .HasColumnName("dteRequiredDate")
                    .HasColumnType("date");

                entity.Property(e => e.IntBillOfMaterialId).HasColumnName("intBillOfMaterialId");

                entity.Property(e => e.IntCostElementId).HasColumnName("intCostElementId");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntPurchaseRequestId).HasColumnName("intPurchaseRequestId");

                entity.Property(e => e.IntUoMid).HasColumnName("intUoMId");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.NumApprovedQuantity)
                    .HasColumnName("numApprovedQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumPurchaseOrderQuantity)
                    .HasColumnName("numPurchaseOrderQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumRequestQuantity)
                    .HasColumnName("numRequestQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumRfqquantity)
                    .HasColumnName("numRFQQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrCostElementName)
                    .HasColumnName("strCostElementName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrItemCode)
                    .HasColumnName("strItemCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurchaseRequestCode)
                    .HasColumnName("strPurchaseRequestCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrRemarks)
                    .IsRequired()
                    .HasColumnName("strRemarks")
                    .HasMaxLength(300);

                entity.Property(e => e.StrUoMname)
                    .IsRequired()
                    .HasColumnName("strUoMName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblPurchaseRequestType>(entity =>
            {
                entity.HasKey(e => e.IntPurchaseRequestTypeId);

                entity.ToTable("tblPurchaseRequestType", "pro");

                entity.Property(e => e.IntPurchaseRequestTypeId).HasColumnName("intPurchaseRequestTypeId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IsActive)
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrPurchaseRequestTypeName)
                    .IsRequired()
                    .HasColumnName("strPurchaseRequestTypeName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblRequestForQuotationHeader>(entity =>
            {
                entity.HasKey(e => e.IntRequestForQuotationId);

                entity.ToTable("tblRequestForQuotationHeader", "pro");

                entity.Property(e => e.IntRequestForQuotationId).HasColumnName("intRequestForQuotationId");

                entity.Property(e => e.DteApprovedDateTime)
                    .HasColumnName("dteApprovedDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteRfqdate)
                    .HasColumnName("dteRFQDate")
                    .HasColumnType("date");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DteValidTillDate)
                    .HasColumnName("dteValidTillDate")
                    .HasColumnType("date");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntApprovedBy).HasColumnName("intApprovedBy");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntCurrencyId).HasColumnName("intCurrencyId");

                entity.Property(e => e.IntPlantId).HasColumnName("intPlantId");

                entity.Property(e => e.IntPurchaseOrganizationId).HasColumnName("intPurchaseOrganizationId");

                entity.Property(e => e.IntRequestTypeId).HasColumnName("intRequestTypeId");

                entity.Property(e => e.IntSbuid).HasColumnName("intSBUId");

                entity.Property(e => e.IntWarehouseId).HasColumnName("intWarehouseId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsApproved).HasColumnName("isApproved");

                entity.Property(e => e.StrAccountName)
                    .IsRequired()
                    .HasColumnName("strAccountName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrApprovedBy)
                    .IsRequired()
                    .HasColumnName("strApprovedBy")
                    .HasMaxLength(100);

                entity.Property(e => e.StrBusinessUnitName)
                    .IsRequired()
                    .HasColumnName("strBusinessUnitName")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.StrCurrencyCode)
                    .IsRequired()
                    .HasColumnName("strCurrencyCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPlantName)
                    .IsRequired()
                    .HasColumnName("strPlantName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurchaseOrganizationName)
                    .IsRequired()
                    .HasColumnName("strPurchaseOrganizationName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrReferenceTypeName)
                    .IsRequired()
                    .HasColumnName("strReferenceTypeName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrRequestForQuotationCode)
                    .IsRequired()
                    .HasColumnName("strRequestForQuotationCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrRequestTypeName)
                    .IsRequired()
                    .HasColumnName("strRequestTypeName")
                    .HasMaxLength(50);

                entity.Property(e => e.StrSbuname)
                    .IsRequired()
                    .HasColumnName("strSBUName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrWarehouseName)
                    .IsRequired()
                    .HasColumnName("strWarehouseName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblRequestForQuotationRow>(entity =>
            {
                entity.HasKey(e => e.IntRowId);

                entity.ToTable("tblRequestForQuotationRow", "pro");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.IntItemId).HasColumnName("intItemId");

                entity.Property(e => e.IntReferenceId).HasColumnName("intReferenceId");

                entity.Property(e => e.IntRequestForQuotationId).HasColumnName("intRequestForQuotationId");

                entity.Property(e => e.IntUoMid).HasColumnName("intUoMId");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.NumReferenceQuantity)
                    .HasColumnName("numReferenceQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumRfqquantity)
                    .HasColumnName("numRFQQuantity")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrDescription)
                    .IsRequired()
                    .HasColumnName("strDescription")
                    .HasMaxLength(300);

                entity.Property(e => e.StrItemCode)
                    .IsRequired()
                    .HasColumnName("strItemCode")
                    .HasMaxLength(100);

                entity.Property(e => e.StrItemName)
                    .IsRequired()
                    .HasColumnName("strItemName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrReferenceCode)
                    .HasColumnName("strReferenceCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrRequestForQuotationCode)
                    .IsRequired()
                    .HasColumnName("strRequestForQuotationCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrUoMname)
                    .IsRequired()
                    .HasColumnName("strUoMName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblSupplierInvoiceHeader>(entity =>
            {
                entity.HasKey(e => e.IntSupplierInvoiceId);

                entity.ToTable("tblSupplierInvoiceHeader", "inv");

                entity.Property(e => e.IntSupplierInvoiceId).HasColumnName("intSupplierInvoiceId");

                entity.Property(e => e.DteInvoiceDate)
                    .HasColumnName("dteInvoiceDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtePaymentDate)
                    .HasColumnName("dtePaymentDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtePaymentDueDate)
                    .HasColumnName("dtePaymentDueDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtePurchaseOrderDate)
                    .HasColumnName("dtePurchaseOrderDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DteTransactionDate)
                    .HasColumnName("dteTransactionDate")
                    .HasColumnType("date");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntBusinessPartnerId).HasColumnName("intBusinessPartnerId");

                entity.Property(e => e.IntBusinessUnitId).HasColumnName("intBusinessUnitId");

                entity.Property(e => e.IntPlantId).HasColumnName("intPlantId");

                entity.Property(e => e.IntPurchaseOrderId).HasColumnName("intPurchaseOrderId");

                entity.Property(e => e.IntPurchaseOrganizationId).HasColumnName("intPurchaseOrganizationId");

                entity.Property(e => e.IntSbuid).HasColumnName("intSBUId");

                entity.Property(e => e.IntSupplierInvoiceCode)
                    .IsRequired()
                    .HasColumnName("intSupplierInvoiceCode")
                    .HasMaxLength(50);

                entity.Property(e => e.IntVoucherId).HasColumnName("intVoucherId");

                entity.Property(e => e.IntWarehouseId).HasColumnName("intWarehouseId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsPayment).HasColumnName("isPayment");

                entity.Property(e => e.NumAdvanceAdjustmentAmount)
                    .HasColumnName("numAdvanceAdjustmentAmount")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumDeductionAmount)
                    .HasColumnName("numDeductionAmount")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumGrossInvoiceAmount)
                    .HasColumnName("numGrossInvoiceAmount")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumNetPaymentAmount)
                    .HasColumnName("numNetPaymentAmount")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.NumTotalReferenceAmount)
                    .HasColumnName("numTotalReferenceAmount")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.StrAttachmentId)
                    .HasColumnName("strAttachmentId")
                    .HasMaxLength(50);

                entity.Property(e => e.StrBusinessUnitName)
                    .IsRequired()
                    .HasColumnName("strBusinessUnitName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrInvoiceNumber)
                    .IsRequired()
                    .HasColumnName("strInvoiceNumber")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPlantName)
                    .IsRequired()
                    .HasColumnName("strPlantName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrPurchaseOrderNo)
                    .IsRequired()
                    .HasColumnName("strPurchaseOrderNo")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPurchaseOrganizationName)
                    .IsRequired()
                    .HasColumnName("strPurchaseOrganizationName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrRemarks)
                    .HasColumnName("strRemarks")
                    .HasMaxLength(500);

                entity.Property(e => e.StrSbuname)
                    .IsRequired()
                    .HasColumnName("strSBUName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrVoucherCode)
                    .HasColumnName("strVoucherCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrWarehouseName)
                    .IsRequired()
                    .HasColumnName("strWarehouseName")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TblSupplierInvoiceRow>(entity =>
            {
                entity.HasKey(e => e.IntRowId);

                entity.ToTable("tblSupplierInvoiceRow", "inv");

                entity.Property(e => e.IntRowId).HasColumnName("intRowId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntReferenceAmount)
                    .HasColumnName("intReferenceAmount")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.IntReferenceId).HasColumnName("intReferenceId");

                entity.Property(e => e.IntSupplierInvoiceId).HasColumnName("intSupplierInvoiceId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<TblUser>(entity =>
            {
                entity.HasKey(e => e.IntUserId);

                entity.ToTable("tblUser", "dco");

                entity.Property(e => e.IntUserId).HasColumnName("intUserId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtePasswordExpDate)
                    .HasColumnName("dtePasswordExpDate")
                    .HasColumnType("date");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IntCountryId).HasColumnName("intCountryId");

                entity.Property(e => e.IntDefaultBusinessUnit).HasColumnName("intDefaultBusinessUnit");

                entity.Property(e => e.IntUserReferenceId).HasColumnName("intUserReferenceId");

                entity.Property(e => e.IntUserType).HasColumnName("intUserType");

                entity.Property(e => e.IsActive)
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsDefaultPassword)
                    .HasColumnName("isDefaultPassword")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsSuperUser)
                    .HasColumnName("isSuperUser")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrContact)
                    .HasColumnName("strContact")
                    .HasMaxLength(50);

                entity.Property(e => e.StrCountryName)
                    .HasColumnName("strCountryName")
                    .HasMaxLength(50);

                entity.Property(e => e.StrEmailAddress)
                    .HasColumnName("strEmailAddress")
                    .HasMaxLength(100);

                entity.Property(e => e.StrLoginId)
                    .HasColumnName("strLoginId")
                    .HasMaxLength(50);

                entity.Property(e => e.StrPassword)
                    .HasColumnName("strPassword")
                    .HasMaxLength(50);

                entity.Property(e => e.StrUserName)
                    .HasColumnName("strUserName")
                    .HasMaxLength(100);

                entity.Property(e => e.StrUserReferenceNo)
                    .HasColumnName("strUserReferenceNo")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<TblWarehouse>(entity =>
            {
                entity.HasKey(e => e.IntWarehouseId);

                entity.ToTable("tblWarehouse", "wms");

                entity.Property(e => e.IntWarehouseId).HasColumnName("intWarehouseId");

                entity.Property(e => e.DteLastActionDateTime)
                    .HasColumnName("dteLastActionDateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.DteServerDateTime)
                    .HasColumnName("dteServerDateTime")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IntAccountId).HasColumnName("intAccountId");

                entity.Property(e => e.IntActionBy).HasColumnName("intActionBy");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StrWarehouseAddress)
                    .IsRequired()
                    .HasColumnName("strWarehouseAddress")
                    .HasMaxLength(300);

                entity.Property(e => e.StrWarehouseCode)
                    .IsRequired()
                    .HasColumnName("strWarehouseCode")
                    .HasMaxLength(50);

                entity.Property(e => e.StrWarehouseName)
                    .IsRequired()
                    .HasColumnName("strWarehouseName")
                    .HasMaxLength(100);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
