﻿using Procurement.DTO.LandingPasignation;
using Procurement.DTO.PurchaseRequestApproval;
using Procurement.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.IRepository
{
    public interface IPurchaseRequestApproval
    {
        public Task<GetPurchaseRequestApproveLandingPagination> GetPurchaseRequestApproveLandingPagination(long accountId, long businessUnitId, long plantId, long warehouseId, long PageNo, long PageSize, string viewOrder);

        public Task<List<GetPurchaseRequestHeaderAppDTO>> GetPurchaseRequestApproveList(long accountId, long businessUnitId, long plantId, long warehouseId);

        public Task<GetPurchaseRequestApproveCommonDTO> GetPurchaseRequestInformationByRequestId(long PurchaseRequestId);

        public Task<MessageHelper> EditPurchaseRequestApprove(EditPurchaseRequestApproveCommonDTO editPurchaseRequestCommonDTO);

        public Task<MessageHelper> UpdateStatusPurchaseRequestApprove(UpdateStatusPurchaseRequestHeaderApprDTO objDTO);
    }
}
