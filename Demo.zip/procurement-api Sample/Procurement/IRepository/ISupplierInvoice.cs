﻿using Procurement.DTO.LandingPasignation;
using Procurement.DTO.SupplierInvoice;
using Procurement.Helper;
using Procurement.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.IRepository
{
    public interface ISupplierInvoice
    {
        public Task<SupplierInvoicePasignation> GetSupplierInvoicePasignation(long AccountId, long UnitId, long SbuId, long Plant, long WearHouse, long PurchaseOrganizationId, string viewOrder, long PageNo, long PageSize);
        public Task<SupplierInvoicePasignation> GetSupplierInvoiceSearchPasignation(string searchTerm, long AccountId, long UnitId, long SbuId, long Plant, long WearHouse, long PurchaseOrganizationId, string viewOrder, long PageNo, long PageSize);
        public Task<GetSupplierInvoiceCommonDTOById> GetSupplierInvoiceCommonDTOById(long SupplierInvoiceId);
        public Task<MessageHelper> CreateSupplierInvoice(CreateSupplierInvoiceCommonDTO objSI);

        public Task<MessageHelper> EditSupplierInvoice(EditSupplierInvoiceCommonDTO objESI);

    }
}
