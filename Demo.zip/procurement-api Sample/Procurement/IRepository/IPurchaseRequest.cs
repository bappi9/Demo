﻿using Procurement.DTO.LandingPasignation;
using Procurement.DTO.PurchaseRequest;
using Procurement.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.IRepository
{
    public interface IPurchaseRequest
    {
        public Task<MessageHelper> CreatePurchaseRequestInfo(CratePruchaseRequestCommonDTO createPurchaseRequestCommonDTO);
        public Task<MessageHelper> EditPurchaseRequest(EditPurchaseRequestCommonDTO editPurchaseRequestCommonDTO);
        public Task<List<GetPurchaseRequestHeaderDTO>> GetPurchaseRequestInformation(long AccountId , long BusinessUnitId , long plant , long Whouse);
        public Task<purchaseRequestPasignation> GetPurchaseRequestInformationPasignation(string search,long AccountId ,long BusinessUnitId,string viewOrder , long PageNo , long PageSize);
        public Task<purchaseRequestPasignation> GetPurchaseRequestInformationSearchPasignation(string searchTerm,long AccountId, long BusinessUnitId, string viewOrder, long PageNo, long PageSize);
        public Task<List<GetPurchaseRequestCommonDTO>> GetPurchaseRequestInformationByRequestId(long RequestId);
        public Task<MessageHelper> UpdatePurchaseRequestStatus(EditPurchaseRequestStatusUpdate updatePurchaseRequestStatusDTO);
        public Task<List<GetPurchaseRequestTypeDDL>> GetPurchaseRequestTypeListDDL();
    }
}
