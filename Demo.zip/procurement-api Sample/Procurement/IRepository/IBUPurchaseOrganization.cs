﻿using Procurement.DTO.BusinessUnitPurchaseOrganization;
using Procurement.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.IRepository
{
    public interface IBUPurchaseOrganization
    {
        public Task<List<GetBusinessUnitPurchaseOrganizationDTO>> GetBUPurchaseOrganization(long AccountId, long BusinessUnitId);
        public Task<List<GetBusinessUnitPurchaseOrganizationDTO>> GetBUPurchaseOrganizationById(long ConfigID);
        public Task<GetBUPurchaseOrganizationPaginationDTO> GetBUPurchaseOrganizationLandingPagination(long AccountId, long BusinessUnitId, bool status, long PageNo, long PageSize, string viewOrder);
        public Task<List<CommonDDLDTO>> GetBUPurchaseOrganizationDDL(long AccountId, long BusinessUnitId);
        public Task<MessageHelper> CreateBusinessUnitPurchaseOrganization(CreateBusinessUnitPurchaseOrganizationDTO objCreateBUPO);
        public Task<MessageHelper> EditBusinessUnitPurchaseOrganization(EditBusinessUnitPurchaseOrganizationDTO objEditBUPO);
        public Task<MessageHelper> UpdateStatusBUPurchaseOrganization(UpdateStatusBUPurchaseOrganizationDTO objUpdateStatusBUPO);
    }
}
