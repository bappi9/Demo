﻿using Procurement.DTO;
using Procurement.DTO.PaymentRequest;
using Procurement.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.IRepository
{
    public interface IPayemntRequest
    {
        public Task<InvoiceDetalisDTO> PurchaseInvoiceDetails(long InvoiceId);
        public Task<PaymentRequestLandingPasignation> PaymentRequestLanding(long BusinessUnitId, long PlantId,long UserId, string viewOrder, long PageNo, long PageSize);

        public Task<List<GetPaymentGLDTO>> GetCPurchaseGridData(long AccountId, long BusinessUnitId, long SBUId, long PartnerId, long CashGLId, decimal CashAmount, long BankAccId);

        public Task<MessageHelper> CreateCashBankPayment(CreateCashPaymentCommonDTO objCreate);
    }
}
