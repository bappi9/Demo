﻿using Procurement.DTO.LandingPasignation;
using Procurement.DTO.POCreate;
using Procurement.DTO.PurchaseOrder;
using Procurement.DTO.PurchaseOrganization;
using Procurement.Helper;
using Procurement.DTO.CCO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Procurement.DTO;

namespace Procurement.IRepository
{
    public interface IPurchaseOrder
    {
        public Task<purchaseOrderPasignation> GetPurchaseOrderInformationPasignation(long AccountId, long UnitId, long Sbu, long Plant, long WearHouse, long PurchaseOrderTypeId, long PurchaseOrganizationId, long ReferenceTypeId, bool isApproved, string viewOrder, long PageNo, long PageSize); //paging
        public Task<purchaseOrderPasignation> GetPurchaseOrderInformationSearchPasignation(string searchTerm, long AccountId, long UnitId, long Sbu, long Plant, long WearHouse, long PurchaseOrderTypeId, long PurchaseOrganizationId, long ReferenceTypeId, bool isApproved, string viewOrder, long PageNo, long PageSize);
        public Task<List<GetPurchaseOrderCommonDTObyId>> GetPurchaseOrderInformationByPO_Id(long PurchaseOrderId); //GetById
        public Task<List<GetPriceStructureCommonDTO>> GetPriceStructureList(long AccountId, long BusinessUnitId, long PriceStructureId);
        public Task<List<GetBillOfMaterialCommonDTO>> GetBillOfMaterialList(long AccountId, long BusinessUnitId, long BillOfMaterialId);
        public Task<List<GetOrderTypeDDLDTO>> GetOrderTypeListDDL();
        public Task<List<GetPurchaseOrderDDLDTO>> GetPurchaseOrderDDL(long AccountId, long BusinessUnitId, long SBUId,long PurchaseOrganizationId, long PlantId, long WarehouseId, long SupplierId);
        public Task<List<GetPurchaseOrderPIDDLDTO>> GetPurchaseOrderPIDDL(long AccountId, long BusinessUnitId, long SBUId);
        public Task<List<GetIncotermDDLDTO>> GetIncotermListDDL();
        public Task<List<GetCurrencyDDLDTO>> GetCurrencyListDDL(long AccountId,long UnitId);
        public Task<List<GetSupplierDDLDTO>> GetSupplierListDDL(long AccountId, long UnitId, long SBUId);
        public Task<List<GetSupplierDDLDTO>> GetSupplierDDL(long AccountId, long UnitId);
        public Task<List<GetPaymentTermsDDLDTO>> GetPaymentTermsListDDL();
        public Task<List<GetPlantDDLDTO>> GetPlantDDLFromPOH(long AccountId, long BusinessUnitId);
        public Task<List<GetWearHouseDDLDTO>> GetWearHouseDDLFromPOH(long AccountId, long BusinessUnitId, long plantId);
        public Task<List<GetOrderTypeDDLDTO>> GetOrderTypeDDLFromPOH(long AccountId, long BusinessUnitId, long plantId, long WearhousId);
        public Task<MessageHelper> CreateStanderdAssetServicePurchaseOrder(CreatePurchaseOrderCommonDTO objPO); //Create PO
        public Task<MessageHelper> CreatePurchaseContact(CreatePurchaseContactCommonDTO objPC);
        public Task<List<getReferenceTypeDTO>> getPOReferenceType(long PoTypeId);
        public Task<List<GetCommonDDLDTO>> GetPOReferenceNoDDL(long RefTypeId, long WarehouseId);
        public Task<List<GetItemDropdownWithPriceStructure>> GetPOReferenceNoWiseItemDDL(long AccountId, long BusinessUnitId, /*long SbuId,*/ long PurchaseOrganizationId, long PlantId, long WearhouseId, long PartnerId, long RefTypeId, long RefNoId);
        public Task<List<getWHAddressDTO>> getWHAddressbyWHId(long WhId);
        public Task<List<ReferanceNoDTO>> getReferanceNoByPR(long AccontId, long UnitId, long referenceTypeId);
        public Task<List<PurchaseRequestItemDTO>> getPRItemList(long RequestId, long ReferanceTypeId);
        public Task<List<getBOMDTO>> getBOM(long AccountId, long UnitId, long PlantId , long ItemId);
        public Task<List<getControllingUnitDTO>> GetControllingUnit(long AccountId, long UnitId);
        public Task<List<getCostElementDTO>> GetCostElement(long AccountId, long UnitId, long ControllingUnitId);
        public Task<List<getCostCenterDTO>> GetCostCenter(long AccountId, long UnitId);
        public Task<List<getPurchaseContractHeaderDTO>> getPurchaseContactHeaderInfo(long PurchaseContractId);
        public Task<List<getPriceStructureDTO>> getPriceStructure(long AccountId, long UnitId);

        public Task<List<PurchaseRequestItemDTO>> getPRItemByItemId(long RequestId, long ReferanceTypeId, long ItemId);

        public Task<MessageHelper> EditPurchaseOrder(EditPurchaseOrderCommonDTO objPO); //Edit PO
        public Task<MessageHelper> EditPurchaseContact(EditPurchaseContactCommonDTO objPO);

        public Task<List<PurchaseRequestItemDTO>> GetPOItemByItemId(long RequestId, long ReferanceTypeId, long ItemId, string ReferanceTypeName);
        public Task<List<PurchaseRequestItemDTO>> GetPOItemListInfo(long RequestId, long ReferanceTypeId, string ReferanceTypeName);
        public Task<List<GetPriceStructureByPartnerDTO>> GetPriceStructureByPartnerId(long AccountId, long UnitId, long PartnerId);
        public Task<List<GetPurchaseOrderDDLDTO>> GetPONoDDL(long AccountId, long BusinessUnitId, long WarehouseId);
    }
}

