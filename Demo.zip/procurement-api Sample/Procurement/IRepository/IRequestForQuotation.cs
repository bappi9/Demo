﻿using Procurement.DTO;
using Procurement.DTO.LandingPasignation;
using Procurement.DTO.RequestForQuotation;
using Procurement.DTO.RequestForQuotation.RFQEdit;
using Procurement.DTO.RequestForQuotation.RFQEntryPage;
using Procurement.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.IRepository
{
    public interface IRequestForQuotation
    {
        public Task<RequestForQuotationPasignation> GetRequestForQuotationPasignation(long AccountId, long UnitId, long RequestTypeId, long SBUId, long PurchaseOrganizationId, long PlantId, long WearHouseId, bool status, string viewOrder, long PageNo, long PageSize);
        public Task<List<GetRequestForQuotationCommonByIdDTO>> GetRequestForQuotationById( long RequestForQuotationId);
        public Task<MessageHelper> CreateRequestForQuotation(CreateRequestForQuotationCommonDTO objRFQ);
        public Task<MessageHelper> EditRequestForQuotation(RFQEditCommonDTO objRFQ);
        public Task<MessageHelper> CreateRFQEntryPage(CreateCommonRFQEntryPage postRFQ);
        public Task<List<GetCommonDDLDTO>> GetPRReferrenceNoDDL(long AccountId, long BusinessUnitId, long SBUId, long PurchaseOrganizationId, long PlantId, long WearHouseId );
        public Task<List<GetCommonDDLDTO>> GetRFQSupplierDDL(long AccountId, long BusinessUnitId, long RequestForQuotationId);
        public Task<List<GetCommonDDLDTO>> GetRFQUOMDDL(long AccountId, long BusinessUnitId, long ItemId); 
        public Task<List<GetCommonDDLDTO>> GetRFQItemDDL(long AccountId, long BusinessUnitId, long SBUId, long PurchaseOrganizationId, long PlantId, long WearHouseId, long PurchaseRequestId, string Referrence); 
        public Task<RFQQuotationEntryPasignation> GetRFQQuotationEntry (long AccountId, long BusinessUnitId, long RFQId, bool status, string viewOrder, long PageNo, long PageSize);
        public Task<List<GetRFQCSDTO>> GetRFQCS( long RequestForQuotationId );
    }
}
