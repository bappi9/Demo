﻿using Procurement.DTO;
using Procurement.DTO.LandingPasignation;
using Procurement.DTO.PurchaseOrganization;
using Procurement.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.IRepository
{
    public interface IPurchaseOrganization
    {
        public Task<PurchaseOrganizationPasignation> GetPurchaseOrganizationPasignation(long AccountId, bool status, string viewOrder, long PageNo, long PageSize);
        public Task<ConfigPurchaseOrganizationPasignation> GetConfigPurchaseOrganizationPasignation (long AccountId, bool status, string viewOrder, long PageNo, long PageSize);
        public Task<List<GetPurchaseOrganizationByIdDTO>> GetPurchaseOrganizationById( long POId);
        public Task<MessageHelper> CreatePurchaseOrganization(CreatePurchaseOrganizationDTO objCPO);
        public Task<MessageHelper> ConfigPurchaseOrganization(List<ConfigPurchaseOrganizationDTO> objConfigCPO);
        public Task<MessageHelper> UpdatePurchaseOrganization(UpdatePurchaseOrganizationDTO objUpdateConfigCPO);
        public Task<List<GetPOcommonDTO>> GetPurchaseOrganizationViewDataByPOId(long POId);

        public Task<List<PurchaseOrganizationDTO>> GetPurchaseOrganizationList(long UnitId);


    }
}
