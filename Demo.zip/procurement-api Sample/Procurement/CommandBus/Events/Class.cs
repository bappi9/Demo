﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CostController.CommandBus.Events
{
    public class Class
    {
    }
}
