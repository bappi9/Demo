﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblPaymentTerms1
    {
        public long IntPaymentTerms { get; set; }
        public string StrPaymentTermsName { get; set; }
        public string StrPaymentTermsCode { get; set; }
        public bool? IsActive { get; set; }
    }
}
