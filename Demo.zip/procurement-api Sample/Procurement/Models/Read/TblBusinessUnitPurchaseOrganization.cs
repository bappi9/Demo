﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblBusinessUnitPurchaseOrganization
    {
        public long IntConfigId { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public string StrBusinessUnitName { get; set; }
        public string StrAccountName { get; set; }
        public long IntPurchaseOrganizationid { get; set; }
        public string StrPurchaseOrganization { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
