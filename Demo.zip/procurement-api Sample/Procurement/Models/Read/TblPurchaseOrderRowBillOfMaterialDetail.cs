﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblPurchaseOrderRowBillOfMaterialDetail
    {
        public long IntRowId { get; set; }
        public long IntPurchaseOrderRowId { get; set; }
        public long IntPurchaseOrderRowItemId { get; set; }
        public long IntBillOfMaterialId { get; set; }
        public string IntBillOfMaterialCode { get; set; }
        public string StrBillOfMaterialName { get; set; }
        public long IntBomitemId { get; set; }
        public string StrBomitemName { get; set; }
        public long IntBomitemUnitOfMeasureId { get; set; }
        public decimal NumBomitemQuantity { get; set; }
        public decimal? NumBomitemNetWeightKg { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool IsActive { get; set; }
    }
}
