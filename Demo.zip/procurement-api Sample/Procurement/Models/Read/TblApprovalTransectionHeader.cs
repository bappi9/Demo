﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblApprovalTransectionHeader
    {
        public long IntApprovalTransectionId { get; set; }
        public long IntApprovalConfigId { get; set; }
        public long IntTransectionPkId { get; set; }
        public long IntPredisorActivityId { get; set; }
        public string StrPredisorActivityName { get; set; }
        public bool IsAnyOrder { get; set; }
        public bool IsInSequence { get; set; }
        public int? IntAnyUsers { get; set; }
        public bool? IsApproved { get; set; }
        public long IntAccountId { get; set; }
        public long IntUnitId { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
