﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblUser
    {
        public long IntUserId { get; set; }
        public string StrUserName { get; set; }
        public long IntAccountId { get; set; }
        public long? IntDefaultBusinessUnit { get; set; }
        public string StrLoginId { get; set; }
        public string StrPassword { get; set; }
        public string StrEmailAddress { get; set; }
        public bool? IsDefaultPassword { get; set; }
        public string StrContact { get; set; }
        public long? IntCountryId { get; set; }
        public string StrCountryName { get; set; }
        public DateTime? DtePasswordExpDate { get; set; }
        public long? IntUserType { get; set; }
        public long? IntUserReferenceId { get; set; }
        public string StrUserReferenceNo { get; set; }
        public bool? IsSuperUser { get; set; }
        public long? IntActionBy { get; set; }
        public DateTime? DteLastActionDateTime { get; set; }
        public DateTime? DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
