﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblModuleFeature
    {
        public long IntFeatureId { get; set; }
        public string StrFeatureCode { get; set; }
        public string StrFeatureName { get; set; }
        public long IntModuleId { get; set; }
        public string StrModuleCode { get; set; }
        public string StrActualFeatureName { get; set; }
        public bool? IsApproval { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
