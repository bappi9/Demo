﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblOrganizationalUnitUserPermissionRow
    {
        public long IntRowId { get; set; }
        public long IntPermissionId { get; set; }
        public long IntAccountId { get; set; }
        public long IntUserId { get; set; }
        public long IntOrganizationUnitTypeId { get; set; }
        public long IntOrganizationUnitReffId { get; set; }
        public string StrOrganizationUnitReffName { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
