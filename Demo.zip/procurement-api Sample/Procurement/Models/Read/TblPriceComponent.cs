﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblPriceComponent
    {
        public long IntPriceComponentId { get; set; }
        public string StrPriceComponentCode { get; set; }
        public string StrPriceComponentName { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public long IntPriceComponentTypeId { get; set; }
        public decimal NumFactor { get; set; }
        public long IntRoundingTypeId { get; set; }
        public long IntGeneralLedgerId { get; set; }
        public long? IntPriceStructureTypeId { get; set; }
        public string StrPriceStructureTypeName { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
