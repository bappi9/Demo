﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblItemPlantWarehouse
    {
        public long IntConfigId { get; set; }
        public long IntItemId { get; set; }
        public string StrItemName { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public string StrBusinessUnitName { get; set; }
        public long IntPlantId { get; set; }
        public string StrPlantName { get; set; }
        public long IntWarehouseId { get; set; }
        public string StrWareHouseName { get; set; }
        public long IntInventoryLocationId { get; set; }
        public long IntBaseUomid { get; set; }
        public string StrBaseUom { get; set; }
        public decimal NumGrossWeight { get; set; }
        public decimal NumNetWeight { get; set; }
        public long IntActionBy { get; set; }
        public decimal NumCurrentStock { get; set; }
        public decimal NumBlockStock { get; set; }
        public decimal NumCogs { get; set; }
        public bool IsManualCogs { get; set; }
        public long IntInventoryStockTypeId { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
        public bool IsMultipleUom { get; set; }
    }
}
