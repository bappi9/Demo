﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblBusinessPartnerPurchase
    {
        public long IntConfigId { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public long IntSbuid { get; set; }
        public long IntBusinessPartnerId { get; set; }
        public long IntPriceStructureId { get; set; }
        public long IntPurchaseOrganizationId { get; set; }
        public long? IntAccruedPayGlid { get; set; }
        public long? IntAdvanceGlid { get; set; }
        public long IntAcPayGlid { get; set; }
        public decimal NumLedgerBalance { get; set; }
        public decimal NumUnbilledAmount { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
