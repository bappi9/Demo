﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblBillOfMaterialRow
    {
        public long IntBoMrowId { get; set; }
        public long IntBillOfMaterialId { get; set; }
        public long IntItemId { get; set; }
        public string StrItemCode { get; set; }
        public string StrItemName { get; set; }
        public decimal NumQuantity { get; set; }
        public long IntUomid { get; set; }
        public bool IsActive { get; set; }
    }
}
