﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblPurchaseOrderType
    {
        public int IntPurchaseOrderTypeId { get; set; }
        public string StrPurchaseOrderTypeName { get; set; }
        public long IntPurchaseRequestTypeId { get; set; }
    }
}
