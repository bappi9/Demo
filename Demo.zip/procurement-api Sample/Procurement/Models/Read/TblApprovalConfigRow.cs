﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblApprovalConfigRow
    {
        public long RowId { get; set; }
        public long ApprovalConfigId { get; set; }
        public long? UserId { get; set; }
        public string StrUserName { get; set; }
        public decimal? Threshold { get; set; }
        public int? SequenceId { get; set; }

        public virtual TblApprovalConfigHeader ApprovalConfig { get; set; }
    }
}
