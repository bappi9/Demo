﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblPurchaseRequestPending
    {
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public long IntPurchaseRequestId { get; set; }
        public string StrPurchaseRequestCode { get; set; }
        public long IntItemId { get; set; }
        public string StrItemName { get; set; }
        public string StrItemCode { get; set; }
        public long IntUoMid { get; set; }
        public string StrUoMname { get; set; }
        public decimal NumApprovedQuantity { get; set; }
        public decimal NumPendingQuantity { get; set; }
    }
}
