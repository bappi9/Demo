﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblCostElement
    {
        public long IntCostElementId { get; set; }
        public string StrCostElementCode { get; set; }
        public string StrCostElementName { get; set; }
        public long IntCostCenterId { get; set; }
        public long IntGeneralLedgerId { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public long IntControllingUnitId { get; set; }
        public bool IsAllocationBased { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }

        public virtual TblCostCenter IntCostCenter { get; set; }
    }
}
