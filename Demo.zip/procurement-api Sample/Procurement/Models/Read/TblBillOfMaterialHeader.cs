﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblBillOfMaterialHeader
    {
        public long IntBillOfMaterialId { get; set; }
        public string StrBillOfMaterialCode { get; set; }
        public string StrBillOfMaterialName { get; set; }
        public long IntItemId { get; set; }
        public string StrItemCode { get; set; }
        public string StrItemName { get; set; }
        public decimal NumLotSize { get; set; }
        public long IntBoMuoMid { get; set; }
        public decimal NumWastagePercentage { get; set; }
        public long IntAccountId { get; set; }
        public long IntPlantId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public long IntShopFloorId { get; set; }
        public bool IsStandardBoM { get; set; }
        public bool IsActive { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
    }
}
