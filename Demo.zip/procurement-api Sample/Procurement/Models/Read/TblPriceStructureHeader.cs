﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblPriceStructureHeader
    {
        public long IntPriceStructureId { get; set; }
        public string StrPriceStructureCode { get; set; }
        public string StrPriceStructureName { get; set; }
        public long IntPriceStructureTypeId { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
