﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblSupplierInvoiceRow
    {
        public long IntRowId { get; set; }
        public long IntSupplierInvoiceId { get; set; }
        public long IntReferenceId { get; set; }
        public decimal IntReferenceAmount { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
