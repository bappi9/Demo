﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblControllingUnit
    {
        public long IntControllingUnitId { get; set; }
        public string StrControllingUnitCode { get; set; }
        public string StrControllingUnitName { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public long IntResponsiblePersonId { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
