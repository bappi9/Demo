﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblApprovalTransectionRow
    {
        public long IntRowId { get; set; }
        public long IntApprovalTransectionId { get; set; }
        public long? IntUserId { get; set; }
        public string StrUserName { get; set; }
        public decimal? NumThreshold { get; set; }
        public int? IntSequenceId { get; set; }
        public bool IsApprove { get; set; }
    }
}
