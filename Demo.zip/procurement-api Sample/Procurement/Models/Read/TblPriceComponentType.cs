﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblPriceComponentType
    {
        public long IntPriceComponentTypeId { get; set; }
        public string StrPriceComponentTypeName { get; set; }
    }
}
