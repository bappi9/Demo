﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Read
{
    public partial class TblPriceStructureRow
    {
        public long IntRowId { get; set; }
        public long IntPriceStructureId { get; set; }
        public long IntPriceComponentId { get; set; }
        public string StrPriceComponentCode { get; set; }
        public string StrPriceComponentName { get; set; }
        public long? IntPriceComponentTypeId { get; set; }
        public string StrPriceComponentTypeName { get; set; }
        public string StrValueType { get; set; }
        public decimal NumValue { get; set; }
        public long? IntBaseComponentId { get; set; }
        public long IntSerialNo { get; set; }
        public long IntSumFromSerial { get; set; }
        public long IntSumToSerial { get; set; }
        public bool IsMannual { get; set; }
        public bool IsInclusive { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
