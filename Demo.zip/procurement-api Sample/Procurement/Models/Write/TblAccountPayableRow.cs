﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblAccountPayableRow
    {
        public long IntRowId { get; set; }
        public long IntAccountReceivablePayableId { get; set; }
        public string StrInvoiceCode { get; set; }
        public long IntGrnid { get; set; }
        public string StrGrncode { get; set; }
        public long IntPurchaseOrderId { get; set; }
        public string StrPurchaseOrderCode { get; set; }
        public long IntGrnrowId { get; set; }
        public long IntItemId { get; set; }
        public string StrItemCode { get; set; }
        public string StrItemName { get; set; }
        public long IntUom { get; set; }
        public string StrUom { get; set; }
        public decimal NumQuantity { get; set; }
        public decimal? NumItemPrice { get; set; }
        public decimal NumGrnvalue { get; set; }
        public bool IsFreeItem { get; set; }
        public bool IsActive { get; set; }
    }
}
