﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblPurchaseOrganization
    {
        public long IntPurchaseOrganizationid { get; set; }
        public long IntAccountId { get; set; }
        public string StrPurchaseOrganization { get; set; }
        public bool? IsActive { get; set; }
    }
}
