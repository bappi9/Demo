﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblPurchaseContractRow
    {
        public long IntRowId { get; set; }
        public long IntPurchaseContractId { get; set; }
        public long IntReferenceId { get; set; }
        public string StrReferenceCode { get; set; }
        public long IntItemId { get; set; }
        public string StrItemName { get; set; }
        public long IntUoMid { get; set; }
        public string StrUoMname { get; set; }
        public string StrPurchaseDescription { get; set; }
        public decimal NumReferenceQty { get; set; }
        public decimal NumContractQty { get; set; }
        public decimal NumBasePrice { get; set; }
        public decimal NumFinalPrice { get; set; }
        public decimal NumTotalValue { get; set; }
        public DateTime DteDeliveryDateTime { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
