﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblIncoTerms
    {
        public long IntIncotermsId { get; set; }
        public string StrIncotermsName { get; set; }
        public string StrIncotermsCode { get; set; }
        public bool? IsActive { get; set; }
    }
}
