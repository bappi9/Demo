﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblApprovalConfigHeader
    {
        public TblApprovalConfigHeader()
        {
            TblApprovalConfigRow = new HashSet<TblApprovalConfigRow>();
        }

        public long ApprovalConfigId { get; set; }
        public long PredisorActivityId { get; set; }
        public string PredisorActivityName { get; set; }
        public bool IsAnyOrder { get; set; }
        public bool IsInSequence { get; set; }
        public int? AnyUsers { get; set; }
        public long AccountId { get; set; }
        public long UnitId { get; set; }
        public long ActionBy { get; set; }
        public DateTime LastActionDateTime { get; set; }
        public DateTime ServerDateTime { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<TblApprovalConfigRow> TblApprovalConfigRow { get; set; }
    }
}
