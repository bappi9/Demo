﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblItemUomconversion
    {
        public long IntConfigId { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public long IntItemId { get; set; }
        public string StrItemName { get; set; }
        public long IntBaseUom { get; set; }
        public string StrBaseUomName { get; set; }
        public long IntConvertedUom { get; set; }
        public string StrConvertedUomName { get; set; }
        public decimal NumConversionRate { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
