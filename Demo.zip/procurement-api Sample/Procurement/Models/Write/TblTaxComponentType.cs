﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblTaxComponentType
    {
        public long IntTaxTypeId { get; set; }
        public string StrTaxType { get; set; }
        public string StrTaxComponentName { get; set; }
    }
}
