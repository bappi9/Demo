﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblPurchaseOrderRow
    {
        public long IntRowId { get; set; }
        public long IntPurchaseOrderId { get; set; }
        public long IntReferenceId { get; set; }
        public string StrReferenceCode { get; set; }
        public decimal NumReferenceQty { get; set; }
        public long IntItemId { get; set; }
        public string StrItemName { get; set; }
        public long IntUoMid { get; set; }
        public string StrUoMname { get; set; }
        public long? IntControllingUnitId { get; set; }
        public string StrControllingUnitName { get; set; }
        public long? IntCostCenterId { get; set; }
        public string StrCostCenterName { get; set; }
        public long? IntCostElementId { get; set; }
        public string StrCostElementName { get; set; }
        public string StrPurchaseDescription { get; set; }
        public decimal NumOrderQty { get; set; }
        public decimal NumBasePrice { get; set; }
        public decimal NumFinalPrice { get; set; }
        public decimal NumTotalValue { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
