﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblPurchaseContractHeader
    {
        public long IntPurchaseContractId { get; set; }
        public string StrPurchaseContractNo { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public long IntPlantId { get; set; }
        public string StrPlantName { get; set; }
        public long IntSbuId { get; set; }
        public long IntWarehouseId { get; set; }
        public string StrWarehouseName { get; set; }
        public long IntPurchaseOrganizationId { get; set; }
        public long IntBusinessPartnerId { get; set; }
        public DateTime DtePurchaseContractDate { get; set; }
        public long IntCurrencyId { get; set; }
        public string StrCurrencyCode { get; set; }
        public long IntReferenceTypeId { get; set; }
        public long? IntReferenceId { get; set; }
        public string StrReferenceCode { get; set; }
        public long? IntPaymentTerms { get; set; }
        public int? IntCreditPercent { get; set; }
        public int? IntCashOrAdvancePercent { get; set; }
        public long? IntIncotermsId { get; set; }
        public string StrSupplierReference { get; set; }
        public DateTime? DteReferenceDate { get; set; }
        public string StrItemGroupName { get; set; }
        public string StrContractType { get; set; }
        public DateTime? DtePcvalidityDate { get; set; }
        public string StrOtherTerms { get; set; }
        public long? IntPriceStructureId { get; set; }
        public bool? IsApproved { get; set; }
        public long IntApproveBy { get; set; }
        public DateTime DteApproveDatetime { get; set; }
        public DateTime DteLastShipmentDate { get; set; }
        public long IntPaymentDaysAfterDelivery { get; set; }
        public string StrDeliveryAddress { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
