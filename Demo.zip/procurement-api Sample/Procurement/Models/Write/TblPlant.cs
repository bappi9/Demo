﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblPlant
    {
        public long IntPlantId { get; set; }
        public long IntAccountId { get; set; }
        public string StrPlantCode { get; set; }
        public string StrPlantName { get; set; }
        public string StrPlantAddress { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
