﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblBusinessUnitTaxComponentGl
    {
        public long IntAutoId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public long IntTaxComponentTypeId { get; set; }
        public long IntTaxComponentGl { get; set; }
    }
}
