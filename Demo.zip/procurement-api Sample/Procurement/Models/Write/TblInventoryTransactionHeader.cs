﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblInventoryTransactionHeader
    {
        public long IntInventoryTransactionId { get; set; }
        public string StrInventoryTransactionCode { get; set; }
        public DateTime DteTransactionDate { get; set; }
        public long TransactionGroupId { get; set; }
        public string TransactionGroupName { get; set; }
        public long IntTransactionTypeId { get; set; }
        public string StrTransactionTypeName { get; set; }
        public long? IntReferenceTypeId { get; set; }
        public string StrReferenceTypeName { get; set; }
        public long IntReferenceId { get; set; }
        public string StrReferenceCode { get; set; }
        public long IntAccountId { get; set; }
        public string StrAccountName { get; set; }
        public long IntBusinessUnitId { get; set; }
        public string StrBusinessUnitName { get; set; }
        public long IntSbuid { get; set; }
        public string StrSbuname { get; set; }
        public long IntPlantId { get; set; }
        public string StrPlantName { get; set; }
        public long IntWarehouseId { get; set; }
        public string StrWarehouseName { get; set; }
        public long? IntBusinessPartnerId { get; set; }
        public string StrBusinessPartnerName { get; set; }
        public long? IntEmployeeId { get; set; }
        public long? IntCostCenterId { get; set; }
        public string StrCostCenterCode { get; set; }
        public string StrCostCenterName { get; set; }
        public long? IntProjectId { get; set; }
        public string StrProjectCode { get; set; }
        public string StrProjectName { get; set; }
        public string StrComments { get; set; }
        public string StrGateEntryNo { get; set; }
        public bool IsInvoicePosted { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public string StrDocumentId { get; set; }
        public bool? IsActive { get; set; }

        public virtual TblWarehouse IntWarehouse { get; set; }
    }
}
