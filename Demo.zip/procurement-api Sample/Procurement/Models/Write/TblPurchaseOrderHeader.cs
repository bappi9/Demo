﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblPurchaseOrderHeader
    {
        public long IntPurchaseOrderId { get; set; }
        public string StrPurchaseOrderNo { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public long IntSbuid { get; set; }
        public long IntPlantId { get; set; }
        public string StrPlantName { get; set; }
        public long IntWarehouseId { get; set; }
        public string StrWarehouseName { get; set; }
        public long? IntSupplyingWarehouseId { get; set; }
        public string StrSupplyingWarehouseName { get; set; }
        public long IntPurchaseOrganizationId { get; set; }
        public long IntBusinessPartnerId { get; set; }
        public string StrBusinessPartnerName { get; set; }
        public DateTime DtePurchaseOrderDate { get; set; }
        public long IntPurchaseOrderTypeId { get; set; }
        public long IntIncotermsId { get; set; }
        public long IntCurrencyId { get; set; }
        public string StrCurrencyCode { get; set; }
        public string StrSupplierReference { get; set; }
        public DateTime? DteReferenceDate { get; set; }
        public long IntReferenceTypeId { get; set; }
        public long? IntPriceStructureId { get; set; }
        public bool? IsApproved { get; set; }
        public long? IntApproveBy { get; set; }
        public DateTime? DteApproveDatetime { get; set; }
        public long IntPaymentTerms { get; set; }
        public long IntCreditPercent { get; set; }
        public long IntCashOrAdvancePercent { get; set; }
        public string StrOtherTerms { get; set; }
        public DateTime DteReturnDateTime { get; set; }
        public DateTime DtePovalidityDate { get; set; }
        public DateTime DteLastShipmentDate { get; set; }
        public long IntPaymentDaysAfterDelivery { get; set; }
        public string StrDeliveryAddress { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
        public bool IsClosed { get; set; }
    }
}
