﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblBankJournalRow
    {
        public long IntRowId { get; set; }
        public long IntBankJournalId { get; set; }
        public string StrBankJournalCode { get; set; }
        public long IntBusinessTransactionId { get; set; }
        public string StrBusinessTransactionCode { get; set; }
        public string StrBusinessTransactionName { get; set; }
        public long IntGeneralLedgerId { get; set; }
        public string StrGeneralLedgerCode { get; set; }
        public string StrGeneralLedgerName { get; set; }
        public decimal NumAmount { get; set; }
        public string StrNarration { get; set; }
        public long? IntBankAccountId { get; set; }
        public string StrBankAccNo { get; set; }
        public bool? IsActive { get; set; }
    }
}
