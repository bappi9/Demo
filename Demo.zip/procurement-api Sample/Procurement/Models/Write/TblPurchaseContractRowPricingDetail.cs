﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblPurchaseContractRowPricingDetail
    {
        public long IntRowId { get; set; }
        public long IntPurchaseContractRowId { get; set; }
        public long? IntPriceStructureId { get; set; }
        public long? IntPriceComponentId { get; set; }
        public string StrPriceComponentCode { get; set; }
        public string StrPriceComponentName { get; set; }
        public long? IntBaseComponentId { get; set; }
        public long? IntSequence { get; set; }
        public string StrValueType { get; set; }
        public decimal? NumValue { get; set; }
        public long? IntSumFromSerial { get; set; }
        public long? IntSumToSerial { get; set; }
        public decimal? NumFactor { get; set; }
        public decimal? NumAmount { get; set; }
        public bool? IsManual { get; set; }
        public bool? IsActive { get; set; }
    }
}
