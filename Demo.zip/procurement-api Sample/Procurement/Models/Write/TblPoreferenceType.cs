﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblPoreferenceType
    {
        public long IntPoreferenceTypeId { get; set; }
        public string StrPoreferenceType { get; set; }
    }
}
