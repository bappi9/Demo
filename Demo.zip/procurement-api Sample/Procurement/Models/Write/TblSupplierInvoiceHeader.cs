﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblSupplierInvoiceHeader
    {
        public long IntSupplierInvoiceId { get; set; }
        public string IntSupplierInvoiceCode { get; set; }
        public DateTime? DteTransactionDate { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public string StrBusinessUnitName { get; set; }
        public long IntSbuid { get; set; }
        public string StrSbuname { get; set; }
        public long IntPurchaseOrganizationId { get; set; }
        public string StrPurchaseOrganizationName { get; set; }
        public long IntPlantId { get; set; }
        public string StrPlantName { get; set; }
        public long IntWarehouseId { get; set; }
        public string StrWarehouseName { get; set; }
        public long IntBusinessPartnerId { get; set; }
        public long IntPurchaseOrderId { get; set; }
        public string StrPurchaseOrderNo { get; set; }
        public DateTime DtePurchaseOrderDate { get; set; }
        public string StrInvoiceNumber { get; set; }
        public DateTime DteInvoiceDate { get; set; }
        public decimal NumTotalReferenceAmount { get; set; }
        public decimal NumGrossInvoiceAmount { get; set; }
        public decimal NumDeductionAmount { get; set; }
        public decimal? NumAdvanceAdjustmentAmount { get; set; }
        public decimal NumNetPaymentAmount { get; set; }
        public DateTime DtePaymentDueDate { get; set; }
        public string StrRemarks { get; set; }
        public string StrVoucherCode { get; set; }
        public long? IntVoucherId { get; set; }
        public bool? IsPayment { get; set; }
        public DateTime? DtePaymentDate { get; set; }
        public string StrAttachmentId { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
