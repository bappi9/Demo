﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblRequestForQuotationRow
    {
        public long IntRowId { get; set; }
        public long IntRequestForQuotationId { get; set; }
        public string StrRequestForQuotationCode { get; set; }
        public long IntItemId { get; set; }
        public string StrItemCode { get; set; }
        public string StrItemName { get; set; }
        public long IntUoMid { get; set; }
        public string StrUoMname { get; set; }
        public decimal NumRfqquantity { get; set; }
        public long? IntReferenceId { get; set; }
        public string StrReferenceCode { get; set; }
        public decimal? NumReferenceQuantity { get; set; }
        public string StrDescription { get; set; }
        public bool IsActive { get; set; }
    }
}
