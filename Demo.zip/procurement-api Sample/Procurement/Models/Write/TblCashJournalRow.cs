﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblCashJournalRow
    {
        public long IntRowId { get; set; }
        public long IntCashJournalId { get; set; }
        public string StrCashJournalCode { get; set; }
        public long? IntBankAccountId { get; set; }
        public string StrBankAccNo { get; set; }
        public long IntBusinessTransactionId { get; set; }
        public string StrBusinessTransactionCode { get; set; }
        public string StrBusinessTransactionName { get; set; }
        public long IntGeneralLedgerId { get; set; }
        public string StrGeneralLedgerCode { get; set; }
        public string StrGeneralLedgerName { get; set; }
        public decimal NumAmount { get; set; }
        public string StrNarration { get; set; }
        public bool IsActive { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
    }
}
