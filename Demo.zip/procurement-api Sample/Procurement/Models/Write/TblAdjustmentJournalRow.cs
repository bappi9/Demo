﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblAdjustmentJournalRow
    {
        public long IntRowId { get; set; }
        public long IntAdjustmentJournalId { get; set; }
        public string StrAdjustmentJournalCode { get; set; }
        public long IntGeneralLedgerId { get; set; }
        public string StrGeneralLedgerCode { get; set; }
        public string StrGeneralLedgerName { get; set; }
        public string StrNarration { get; set; }
        public decimal NumAmount { get; set; }
        public bool? IsActive { get; set; }
    }
}
