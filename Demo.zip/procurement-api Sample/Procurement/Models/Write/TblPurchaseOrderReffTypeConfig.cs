﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblPurchaseOrderReffTypeConfig
    {
        public long IntConfigId { get; set; }
        public int IntPurchaseOrderTypeId { get; set; }
        public string StrPurchaseOrderTypeName { get; set; }
        public long IntPoreferenceTypeId { get; set; }
        public string StrPoreferenceType { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
