﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblInventoryTransactionRow
    {
        public long IntRowId { get; set; }
        public long IntInventoryTransactionId { get; set; }
        public string StrInventoryTransactionCode { get; set; }
        public long IntItemId { get; set; }
        public string StrItemName { get; set; }
        public long IntUoMid { get; set; }
        public string StrUoMname { get; set; }
        public decimal NumTransactionQuantity { get; set; }
        public decimal MonTransactionValue { get; set; }
        public long IntInventoryLocationId { get; set; }
        public string StrInventoryLocationName { get; set; }
        public long? IntBatchId { get; set; }
        public string StrBatchNumber { get; set; }
        public long? IntInventoryStockTypeId { get; set; }
        public string StrInventoryStockTypeName { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
