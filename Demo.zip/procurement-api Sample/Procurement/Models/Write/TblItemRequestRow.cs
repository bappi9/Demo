﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblItemRequestRow
    {
        public long IntRowId { get; set; }
        public long IntItemRequestId { get; set; }
        public string StrItemRequestCode { get; set; }
        public string StrReferenceId { get; set; }
        public long IntItemId { get; set; }
        public string StrItemCode { get; set; }
        public string StrItemName { get; set; }
        public long IntUoMid { get; set; }
        public string StrUoMname { get; set; }
        public decimal NumRequestQuantity { get; set; }
        public decimal? NumApprovedQuantity { get; set; }
        public decimal? NumIssueQuantity { get; set; }
        public string StrRemarks { get; set; }
        public bool? IsActive { get; set; }
    }
}
