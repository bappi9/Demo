﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblCashJournalHeader
    {
        public long IntCashJournalId { get; set; }
        public string StrCashJournalCode { get; set; }
        public DateTime DteJournalDate { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public long IntSbuid { get; set; }
        public string StrReceiveFrom { get; set; }
        public string StrTransferTo { get; set; }
        public string StrPaidTo { get; set; }
        public long IntGeneralLedgerId { get; set; }
        public string StrGeneralLedgerCode { get; set; }
        public string StrGeneralLedgerName { get; set; }
        public decimal NumAmount { get; set; }
        public decimal? NumInvoiceAdjustAmount { get; set; }
        public decimal? NumAdjustmentPendingAmount { get; set; }
        public string StrNarration { get; set; }
        public bool IsPosted { get; set; }
        public DateTime? DteCompleteDateTime { get; set; }
        public long? IntBusinessPartnerId { get; set; }
        public string StrBusinessPartnerCode { get; set; }
        public string StrBusinessPartnerName { get; set; }
        public long IntAccountingJournalTypeId { get; set; }
        public bool IsDirectPosting { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsEmployee { get; set; }
    }
}
