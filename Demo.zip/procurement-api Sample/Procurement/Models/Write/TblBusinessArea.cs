﻿using System;
using System.Collections.Generic;

namespace Procurement.Models.Write
{
    public partial class TblBusinessArea
    {
        public long IntSbuid { get; set; }
        public long IntAccountId { get; set; }
        public long IntBusinessUnitId { get; set; }
        public string StrBusinessUnitName { get; set; }
        public string StrSbucode { get; set; }
        public string StrSbuname { get; set; }
        public long IntActionBy { get; set; }
        public DateTime DteLastActionDateTime { get; set; }
        public DateTime DteServerDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
