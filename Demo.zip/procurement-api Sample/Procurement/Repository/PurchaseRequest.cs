﻿using Procurement.DbContexts;
using Procurement.DTO.LandingPasignation;
using Procurement.DTO.PurchaseRequest;
using Procurement.FunctionalService;
using Procurement.Helper;
using Procurement.IRepository;
using Procurement.Models.Write;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Procurement.StoreProcedure;
using System.Data;

namespace Procurement.Repository
{
    public class PurchaseRequest : IPurchaseRequest
    {
        public readonly ReadDbContext _contextR;
        public readonly WriteDbContext _contextW;
        public readonly ApprovalTransections _approval;
        CodeGenerate objCG = new CodeGenerate();

        public PurchaseRequest(ReadDbContext contextR, WriteDbContext contextW, ApprovalTransections approval)
        {
            _contextR = contextR;
            _contextW = contextW;
            _approval = approval;
        }


        public async Task<MessageHelper> CreatePurchaseRequestInfo(CratePruchaseRequestCommonDTO createPurchaseRequestCommonDTO)
        {
            //throw new NotImplementedException();
            try
            {
                if (createPurchaseRequestCommonDTO.CreatePurchaseRequestRow.Count > 0)
                {
                    DataTable purchaseRequest = objCG.getCodeGenerate(createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.AccountId, createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.BusinessUnitId, 32);

                    var detalis = new TblPurchaseRequestHeader
                    {
                        StrPurchaseRequestCode = purchaseRequest.Rows[0][0].ToString(),
                        StrReffNo = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.ReffNo,
                        IntPurchaseRequestTypeId = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.PurchaseRequestTypeId,
                        StrPurchaseRequestTypeName = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.PurchaseRequestTypeName,
                        IntAccountId = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.AccountId,
                        StrAccountName = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.AccountName,
                        IntBusinessUnitId = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.BusinessUnitId,
                        StrBusinessUnitName = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.BusinessUnitName,
                        IntSbuid = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.Sbuid,
                        StrSbuname = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.Sbuname,
                        IntPurchaseOrganizationId = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.PurchaseOrganizationId,
                        StrPurchaseOrganizationName = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.PurchaseOrganizationName,
                        IntPlantId = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.PlantId,
                        StrPlantName = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.PlantName,
                        IntWarehouseId = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.WarehouseId,
                        StrWarehouseName = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.WarehouseName,
                        StrDeliveryAddress = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.DeliveryAddress,
                        IntSupplyingWarehouseId = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.SupplyingWarehouseId,
                        StrSupplyingWarehouseName = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.SupplyingWarehouseName,
                        DteRequestDate = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.RequestDate,
                        IsApproved = false,
                        IntApprovedBy = 0,
                        StrApprovedBy = "",
                        DteApprovedDateTime = DateTime.UtcNow,
                        IsComplete = false,
                        IsClosed = false,
                        IntClosedBy = 0,
                        StrClosedBy = "",
                        DteClosedDateTime = DateTime.UtcNow,
                        IntActionBy = createPurchaseRequestCommonDTO.CreatePurchaseRequestHeader.ActionBy,
                        DteLastActionDateTime = DateTime.UtcNow,
                        IsActive = true
                    };
                    var dt = _contextR.TblApprovalConfigHeader.Where(a => a.PredisorActivityId == 1 && a.UnitId == detalis.IntBusinessUnitId && a.IsActive == true).FirstOrDefault();
                    if (dt == null)
                    {
                        detalis.IsApproved = true;
                    }
                    await _contextW.TblPurchaseRequestHeader.AddAsync(detalis);
                    await _contextW.SaveChangesAsync();


                    var mRows = new List<TblPurchaseRequestRow>(createPurchaseRequestCommonDTO.CreatePurchaseRequestRow.Count);
                    foreach (var datas in createPurchaseRequestCommonDTO.CreatePurchaseRequestRow)
                    {

                        var detalisrow = new TblPurchaseRequestRow { };
                        detalisrow.IntPurchaseRequestId = detalis.IntPurchaseRequestId;
                        detalisrow.StrPurchaseRequestCode = purchaseRequest.Rows[0][0].ToString();
                        //detalisrow.StrPurchaseRequestCode = detalis.StrPurchaseRequestCode;
                        detalisrow.IntItemId = datas.ItemId;
                        detalisrow.StrItemName = (from i in _contextR.TblItem where i.IntItemId == datas.ItemId select i.StrItemName).FirstOrDefault(); ;
                        detalisrow.StrItemCode = (from i in _contextR.TblItem where i.IntItemId == datas.ItemId select i.StrItemCode).FirstOrDefault();
                        detalisrow.IntUoMid = datas.UoMid;
                        detalisrow.StrUoMname = datas.UoMname;
                        detalisrow.NumRequestQuantity = datas.NumRequestQuantity;
                        detalisrow.NumApprovedQuantity = 0;
                        detalisrow.NumRfqquantity = 0;
                        detalisrow.NumPurchaseOrderQuantity = 0;
                        detalisrow.DteRequiredDate = datas.DteRequiredDate;
                        detalisrow.IntCostElementId = datas.CostElementId;
                        detalisrow.StrCostElementName = datas.CostElementName;
                        detalisrow.IntBillOfMaterialId = datas.BillOfMaterialId;
                        detalisrow.StrRemarks = datas.Remarks;
                        detalisrow.IsActive = true;

                        if (dt == null)
                        {
                            detalisrow.NumApprovedQuantity = detalisrow.NumRequestQuantity;
                        }
                        mRows.Add(detalisrow);
                    }

                    await _contextW.TblPurchaseRequestRow.AddRangeAsync(mRows);
                    await _contextW.SaveChangesAsync();

                    //Purchase Request Activity Id 19
                    long PRActivityId = _contextR.TblModuleFeature.FirstOrDefault(a => a.StrFeatureName == "Purchase Request").IntFeatureId;

                    await _approval.CreateApproval(detalis.IntPurchaseRequestId, detalis.IntBusinessUnitId, detalis.IntActionBy, detalis.IntAccountId, PRActivityId);

                    var msg = new MessageHelper();
                    msg.Message = "Purchase Request Code " + detalis.StrPurchaseRequestCode + " has been Created";
                    msg.statuscode = 200;
                    return msg;
                }
                else
                {
                    throw new Exception("Please Add details data!!!");
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<MessageHelper> EditPurchaseRequest(EditPurchaseRequestCommonDTO objEdit)
        {
            try
            {
                var mRowsNew = new List<TblPurchaseRequestRow>(objEdit.objRow.Count);
                var mRowsEdit = new List<TblPurchaseRequestRow>(objEdit.objRow.Count);
                foreach (var datas in objEdit.objRow)
                {
                    if (datas.RowId == 0)
                    {

                        var detalisrow = new TblPurchaseRequestRow { };

                        detalisrow.IntItemId = datas.ItemId;
                        detalisrow.IntPurchaseRequestId = objEdit.objHeader.PurchaseRequestId; //editPurchaseRequestCommonDTO.EditPurchaseRequestHeader.PurchaseRequestId;
                        detalisrow.StrPurchaseRequestCode = objEdit.objHeader.PurchaseRequestCode;//editPurchaseRequestCommonDTO.EditPurchaseRequestHeader.PurchaseRequestCode;
                        detalisrow.StrItemName = (from i in _contextR.TblItem where i.IntItemId == datas.ItemId select i.StrItemName).FirstOrDefault();
                        detalisrow.StrItemCode = (from i in _contextR.TblItem where i.IntItemId == datas.ItemId select i.StrItemCode).FirstOrDefault();
                        detalisrow.IntUoMid = datas.UoMid;
                        detalisrow.StrUoMname = datas.UoMname;
                        detalisrow.NumRequestQuantity = datas.NumRequestQuantity;
                        detalisrow.NumApprovedQuantity = 0;//datas.NumApprovedQuantity;
                        detalisrow.NumRfqquantity = 0;// datas.NumRfqquantity;
                        detalisrow.NumPurchaseOrderQuantity = 0;// datas.NumPurchaseOrderQuantity;
                        detalisrow.DteRequiredDate = datas.DteRequiredDate;
                        detalisrow.IntCostElementId = datas.CostElementId;
                        detalisrow.StrCostElementName = datas.CostElementName;
                        detalisrow.IntBillOfMaterialId = datas.BillOfMaterialId;
                        detalisrow.StrRemarks = datas.Remarks;
                        detalisrow.IsActive = true;

                        mRowsNew.Add(detalisrow);
                    }
                    else
                    {
                        TblPurchaseRequestRow details = _contextW.TblPurchaseRequestRow.Where(x => x.IntRowId == datas.RowId && x.IsActive == true).FirstOrDefault();

                        if (details == null)
                            throw new Exception("Edit Data Not Found");

                        details.IntItemId = datas.ItemId;
                        details.IntUoMid = datas.UoMid;
                        details.StrUoMname = datas.UoMname;
                        details.NumRequestQuantity = datas.NumRequestQuantity;
                        details.DteRequiredDate = datas.DteRequiredDate;
                        details.IntCostElementId = datas.CostElementId;
                        details.StrCostElementName = datas.CostElementName;
                        details.IntBillOfMaterialId = datas.BillOfMaterialId;
                        details.StrRemarks = datas.Remarks;

                        mRowsEdit.Add(details);
                    }
                }

                //Sayeem
                //For updating rather than making isActive false

                // var innerquery = from c in objEdit.objRow
                //                  where c.RowId > 0
                //                  select c.RowId;
                // var inactiveItems = (from p in _contextW.TblPurchaseRequestRow
                //                      where p.IntPurchaseRequestId == objEdit.objHeader.PurchaseRequestId
                //                      && !innerquery.Contains(p.IntRowId)
                //                      select p).ToList();

                // foreach (var a in inactiveItems)
                // {
                //     a.IsActive = false;
                // }

                // _contextW.TblPurchaseRequestRow.UpdateRange(inactiveItems);
                // await _contextW.SaveChangesAsync();

                if (mRowsNew.Count > 0)
                {
                    await _contextW.TblPurchaseRequestRow.AddRangeAsync(mRowsNew);
                    await _contextW.SaveChangesAsync();
                }
                if (mRowsEdit.Count > 0)
                {
                    _contextW.TblPurchaseRequestRow.UpdateRange(mRowsEdit);
                    await _contextW.SaveChangesAsync();
                }

                var msg = new MessageHelper();
                msg.Message = "Processing";
                msg.statuscode = 200;
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<GetPurchaseRequestHeaderDTO>> GetPurchaseRequestInformation(long AccountId, long BusinessUnitId, long plant, long Whouse)
        {
            //throw new NotImplementedException();
            var data = await Task.FromResult((from prh in _contextR.TblPurchaseRequestHeader
                                              where prh.IsActive == true && prh.IntAccountId == AccountId && prh.IntBusinessUnitId == BusinessUnitId && prh.IntPlantId == plant && prh.IntWarehouseId == Whouse
                                              select new GetPurchaseRequestHeaderDTO
                                              {
                                                  PurchaseRequestId = prh.IntPurchaseRequestId,
                                                  PurchaseRequestCode = prh.StrPurchaseRequestCode,
                                                  ReffNo = prh.StrReffNo,
                                                  PurchaseRequestTypeId = prh.IntPurchaseRequestTypeId,
                                                  PurchaseRequestTypeName = prh.StrPurchaseRequestTypeName,
                                                  AccountId = prh.IntAccountId,
                                                  AccountName = prh.StrAccountName,
                                                  BusinessUnitId = prh.IntBusinessUnitId,
                                                  BusinessUnitName = prh.StrBusinessUnitName,
                                                  Sbuid = prh.IntSbuid,
                                                  Sbuname = prh.StrSbuname,
                                                  PurchaseOrganizationId = prh.IntPurchaseOrganizationId,
                                                  PurchaseOrganizationName = prh.StrPurchaseOrganizationName,
                                                  PlantId = prh.IntPlantId,
                                                  PlantName = prh.StrPlantName,
                                                  WarehouseId = prh.IntWarehouseId,
                                                  WarehouseName = prh.StrWarehouseName,
                                                  DeliveryAddress = prh.StrDeliveryAddress,
                                                  SupplyingWarehouseId = prh.IntSupplyingWarehouseId,
                                                  SupplyingWarehouseName = prh.StrSupplyingWarehouseName,
                                                  RequestDate = prh.DteRequestDate,
                                                  IsApproved = prh.IsApproved,
                                                  ApprovedBy = prh.IntApprovedBy,
                                                  ApprovedByName = prh.StrApprovedBy,
                                                  ApprovedDateTime = prh.DteApprovedDateTime,
                                                  IsComplete = prh.IsComplete,
                                                  IsClosed = prh.IsClosed,
                                                  ClosedBy = prh.IntClosedBy,
                                                  ClosedByName = prh.StrClosedBy,
                                                  ClosedDateTime = prh.DteClosedDateTime,
                                                  ActionBy = prh.IntActionBy,
                                                  LastActionDateTime = prh.DteLastActionDateTime,
                                                  IsActive = prh.IsActive

                                              }).ToList());

            if (data == null)
                throw new Exception("Purchase Request Header Not Exist in Database");

            int index = 1;
            foreach (var itms in data)
            {
                itms.Sl = index++;
            }

            return data;
        }

        public async Task<List<GetPurchaseRequestCommonDTO>> GetPurchaseRequestInformationByRequestId(long RequestId)
        {
            //throw new NotImplementedException();
            try
            {
                GetPurchaseRequestHeaderDTO header = await Task.FromResult((from prh in _contextR.TblPurchaseRequestHeader
                                                                            where prh.IsActive == true && prh.IntPurchaseRequestId == RequestId
                                                                            select new GetPurchaseRequestHeaderDTO
                                                                            {
                                                                                PurchaseRequestId = prh.IntPurchaseRequestId,
                                                                                PurchaseRequestCode = prh.StrPurchaseRequestCode,
                                                                                ReffNo = prh.StrReffNo,
                                                                                PurchaseRequestTypeId = prh.IntPurchaseRequestTypeId,
                                                                                PurchaseRequestTypeName = prh.StrPurchaseRequestTypeName,
                                                                                AccountId = prh.IntAccountId,
                                                                                AccountName = prh.StrAccountName,
                                                                                BusinessUnitId = prh.IntBusinessUnitId,
                                                                                BusinessUnitName = prh.StrBusinessUnitName,
                                                                                Sbuid = prh.IntSbuid,
                                                                                Sbuname = prh.StrSbuname,
                                                                                PurchaseOrganizationId = prh.IntPurchaseOrganizationId,
                                                                                PurchaseOrganizationName = prh.StrPurchaseOrganizationName,
                                                                                PlantId = prh.IntPlantId,
                                                                                PlantName = prh.StrPlantName,
                                                                                WarehouseId = prh.IntWarehouseId,
                                                                                WarehouseName = prh.StrWarehouseName,
                                                                                DeliveryAddress = prh.StrDeliveryAddress,
                                                                                SupplyingWarehouseId = prh.IntSupplyingWarehouseId,
                                                                                SupplyingWarehouseName = prh.StrSupplyingWarehouseName,
                                                                                RequestDate = prh.DteRequestDate,
                                                                                IsApproved = prh.IsApproved,
                                                                                ApprovedBy = prh.IntApprovedBy,
                                                                                ApprovedByName = prh.StrApprovedBy,
                                                                                ApprovedDateTime = prh.DteApprovedDateTime,
                                                                                IsComplete = prh.IsComplete,
                                                                                IsClosed = prh.IsClosed,
                                                                                ClosedBy = prh.IntClosedBy,
                                                                                ClosedByName = prh.StrClosedBy,
                                                                                ClosedDateTime = prh.DteClosedDateTime,
                                                                                ActionBy = prh.IntActionBy,
                                                                                LastActionDateTime = prh.DteLastActionDateTime,
                                                                                IsActive = prh.IsActive

                                                                            }).FirstOrDefault());

                List<GetPurchaseRequestRowDTO> row = await Task.FromResult((from t in _contextR.TblPurchaseRequestRow

                                                                            where t.IntPurchaseRequestId == RequestId && t.IsActive == true
                                                                            select new GetPurchaseRequestRowDTO
                                                                            {
                                                                                RowId = t.IntRowId,
                                                                                PurchaseRequestId = t.IntPurchaseRequestId,
                                                                                PurchaseRequestCode = t.StrPurchaseRequestCode,
                                                                                ItemId = t.IntItemId,
                                                                                ItemName = t.StrItemName,
                                                                                ItemCode = t.StrItemCode,
                                                                                UoMid = t.IntUoMid,
                                                                                UoMname = t.StrUoMname,
                                                                                NumRequestQuantity = t.NumRequestQuantity,
                                                                                NumApprovedQuantity = t.NumApprovedQuantity,
                                                                                NumRfqquantity = t.NumRfqquantity,
                                                                                NumPurchaseOrderQuantity = t.NumPurchaseOrderQuantity,
                                                                                DteRequiredDate = t.DteRequiredDate,
                                                                                CostElementId = t.IntCostElementId,
                                                                                CostElementName = t.StrCostElementName,
                                                                                BillOfMaterialId = t.IntBillOfMaterialId,
                                                                                Remarks = t.StrRemarks

                                                                            }).ToList());

                List<GetPurchaseRequestCommonDTO> objListData = new List<GetPurchaseRequestCommonDTO>();
                GetPurchaseRequestCommonDTO objData = new GetPurchaseRequestCommonDTO()
                {
                    GetPurchaseRequestHeader = header,
                    GetPurchaseRequestRow = row
                };


                if (objData == null)
                    throw new Exception("Purchase Request Information Not Exist in Database");
                else
                    objListData.Add(objData);

                return objListData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<purchaseRequestPasignation> GetPurchaseRequestInformationPasignation(string search, long AccountId, long BusinessUnitId, string viewOrder, long PageNo, long PageSize)
        {
            //throw new NotImplementedException();
            purchaseRequestPasignation itm = new purchaseRequestPasignation();
            var HaveWHPermission = await Task.FromResult((from oup in _contextR.TblOrganizationalUnitUserPermissionRow
                                                          join u in _contextR.TblUser on oup.IntAccountId equals u.IntAccountId
                                                          where oup.IntAccountId == AccountId && oup.IntOrganizationUnitTypeId == 8 && oup.IntUserId == u.IntUserId
                                                          select oup).FirstOrDefault());
            if (HaveWHPermission != null)
            {
                //var counts =  _contextR.TblPurchaseRequestHeader.Where(x => x.IntAccountId == AccountId && x.IntBusinessUnitId == BusinessUnitId && x.IsActive == true).Count();
                IQueryable<GetPurchaseRequestHeaderDTO> data = (from prh in _contextR.TblPurchaseRequestHeader
                                                                where prh.IntAccountId == AccountId && prh.IntBusinessUnitId == BusinessUnitId
                                                                && prh.IsActive == true && ((prh.StrPurchaseRequestCode.ToLower().Contains(search.ToString().ToLower())) || (prh.StrPurchaseRequestTypeName.ToLower().Contains(search.ToString().ToLower())))
                                                                select new GetPurchaseRequestHeaderDTO
                                                                {
                                                                    PurchaseRequestId = prh.IntPurchaseRequestId,
                                                                    PurchaseRequestCode = prh.StrPurchaseRequestCode,
                                                                    ReffNo = prh.StrReffNo,
                                                                    PurchaseRequestTypeId = prh.IntPurchaseRequestTypeId,
                                                                    PurchaseRequestTypeName = prh.StrPurchaseRequestTypeName,
                                                                    AccountId = prh.IntAccountId,
                                                                    AccountName = prh.StrAccountName,
                                                                    BusinessUnitId = prh.IntBusinessUnitId,
                                                                    BusinessUnitName = prh.StrBusinessUnitName,
                                                                    Sbuid = prh.IntSbuid,
                                                                    Sbuname = prh.StrSbuname,
                                                                    PurchaseOrganizationId = prh.IntPurchaseOrganizationId,
                                                                    PurchaseOrganizationName = prh.StrPurchaseOrganizationName,
                                                                    PlantId = prh.IntPlantId,
                                                                    PlantName = prh.StrPlantName,
                                                                    WarehouseId = prh.IntWarehouseId,
                                                                    WarehouseName = prh.StrWarehouseName,
                                                                    DeliveryAddress = prh.StrDeliveryAddress,
                                                                    SupplyingWarehouseId = prh.IntSupplyingWarehouseId,
                                                                    SupplyingWarehouseName = prh.StrSupplyingWarehouseName,
                                                                    RequestDate = prh.DteRequestDate,
                                                                    IsApproved = prh.IsApproved,
                                                                    ApprovedBy = prh.IntApprovedBy,
                                                                    ApprovedByName = prh.StrApprovedBy,
                                                                    ApprovedDateTime = prh.DteApprovedDateTime,
                                                                    IsComplete = prh.IsComplete,
                                                                    IsClosed = prh.IsClosed,
                                                                    ClosedBy = prh.IntClosedBy,
                                                                    ClosedByName = prh.StrClosedBy,
                                                                    ClosedDateTime = prh.DteClosedDateTime,
                                                                    ActionBy = prh.IntActionBy,
                                                                    LastActionDateTime = prh.DteLastActionDateTime,
                                                                    IsActive = prh.IsActive

                                                                });
                var counts = data.Count();
                if (data == null)
                    throw new Exception("Purchase Request Header Not Exist in Database");
                else
                {
                    if (viewOrder.ToUpper() == "ASC")
                        data = data.OrderBy(o => o.PurchaseRequestId);
                    else if (viewOrder.ToUpper() == "DESC")
                        data = data.OrderByDescending(o => o.PurchaseRequestId);
                }

                if (PageNo <= 0)
                    PageNo = 1;
                var itemdata = await Task.FromResult(PagingList<GetPurchaseRequestHeaderDTO>.CreateAsync(data, PageNo, PageSize));

                int index = 1;
                foreach (var itms in itemdata)
                {
                    itms.Sl = index++;
                }

                itm.Data = itemdata;
                itm.currentPage = PageNo;
                itm.totalCount = counts;
                itm.pageSize = PageSize;
            }
            else
            {
                itm.currentPage = PageNo;
                itm.totalCount = 0;
                itm.pageSize = PageSize;
            }

            return itm;
        }

        public async Task<MessageHelper> UpdatePurchaseRequestStatus(EditPurchaseRequestStatusUpdate updatePurchaseRequestStatusDTO)
        {
            //throw new NotImplementedException();
            try
            {
                var msg = new MessageHelper();
                TblPurchaseRequestHeader datas = await Task.FromResult(_contextW.TblPurchaseRequestHeader.First(x => x.IntPurchaseRequestId == updatePurchaseRequestStatusDTO.PurchaseRequestId));

                datas.IntActionBy = updatePurchaseRequestStatusDTO.ActionBy;
                datas.DteLastActionDateTime = DateTime.UtcNow;
                datas.IsActive = updatePurchaseRequestStatusDTO.IsActive;

                _contextW.TblPurchaseRequestHeader.Update(datas);
                await _contextW.SaveChangesAsync();

                msg.Message = "Processing";
                msg.statuscode = 200;
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<GetPurchaseRequestTypeDDL>> GetPurchaseRequestTypeListDDL()
        {
            var data = await Task.FromResult((from prh in _contextR.TblPurchaseRequestType
                                              where prh.IsActive == true
                                              orderby prh.StrPurchaseRequestTypeName ascending
                                              select new GetPurchaseRequestTypeDDL
                                              {
                                                  PurchaseRequestTypeId = prh.IntPurchaseRequestTypeId,
                                                  PurchaseRequestTypeName = prh.StrPurchaseRequestTypeName
                                              }).ToList());

            if (data == null)
                throw new Exception("Purchase Request Type Not Exist in Database");

            return data;
        }

        public async Task<purchaseRequestPasignation> GetPurchaseRequestInformationSearchPasignation(string searchTerm, long AccountId, long BusinessUnitId, string viewOrder, long PageNo, long PageSize)
        {

            //purchaseRequestPasignation itm = new purchaseRequestPasignation();
            var HaveWHPermission = await Task.FromResult((from oup in _contextR.TblOrganizationalUnitUserPermissionRow
                                                          join u in _contextR.TblUser on oup.IntAccountId equals u.IntAccountId
                                                          where oup.IntAccountId == AccountId && oup.IntOrganizationUnitTypeId == 8 && oup.IntUserId == u.IntUserId
                                                          select oup).FirstOrDefault());
            if (HaveWHPermission != null)
            {
                var counts = _contextR.TblPurchaseRequestHeader.Where(x => x.IntAccountId == AccountId && x.IntBusinessUnitId == BusinessUnitId && x.IsActive == true).Count();
                IQueryable<GetPurchaseRequestHeaderDTO> data = (from prh in _contextR.TblPurchaseRequestHeader
                                                                where prh.IntAccountId == AccountId && prh.IntBusinessUnitId == BusinessUnitId
                                                                && prh.IsActive == true
                                                                select new GetPurchaseRequestHeaderDTO
                                                                {
                                                                    PurchaseRequestId = prh.IntPurchaseRequestId,
                                                                    PurchaseRequestCode = prh.StrPurchaseRequestCode,
                                                                    ReffNo = prh.StrReffNo,
                                                                    PurchaseRequestTypeId = prh.IntPurchaseRequestTypeId,
                                                                    PurchaseRequestTypeName = prh.StrPurchaseRequestTypeName,
                                                                    AccountId = prh.IntAccountId,
                                                                    AccountName = prh.StrAccountName,
                                                                    BusinessUnitId = prh.IntBusinessUnitId,
                                                                    BusinessUnitName = prh.StrBusinessUnitName,
                                                                    Sbuid = prh.IntSbuid,
                                                                    Sbuname = prh.StrSbuname,
                                                                    PurchaseOrganizationId = prh.IntPurchaseOrganizationId,
                                                                    PurchaseOrganizationName = prh.StrPurchaseOrganizationName,
                                                                    PlantId = prh.IntPlantId,
                                                                    PlantName = prh.StrPlantName,
                                                                    WarehouseId = prh.IntWarehouseId,
                                                                    WarehouseName = prh.StrWarehouseName,
                                                                    DeliveryAddress = prh.StrDeliveryAddress,
                                                                    SupplyingWarehouseId = prh.IntSupplyingWarehouseId,
                                                                    SupplyingWarehouseName = prh.StrSupplyingWarehouseName,
                                                                    RequestDate = prh.DteRequestDate,
                                                                    IsApproved = prh.IsApproved,
                                                                    ApprovedBy = prh.IntApprovedBy,
                                                                    ApprovedByName = prh.StrApprovedBy,
                                                                    ApprovedDateTime = prh.DteApprovedDateTime,
                                                                    IsComplete = prh.IsComplete,
                                                                    IsClosed = prh.IsClosed,
                                                                    ClosedBy = prh.IntClosedBy,
                                                                    ClosedByName = prh.StrClosedBy,
                                                                    ClosedDateTime = prh.DteClosedDateTime,
                                                                    ActionBy = prh.IntActionBy,
                                                                    LastActionDateTime = prh.DteLastActionDateTime,
                                                                    IsActive = prh.IsActive

                                                                });

                purchaseRequestPasignation itm = new purchaseRequestPasignation();

                if (searchTerm != null)
                {
                    var countss = from t in data
                                  where t.PurchaseRequestCode.ToLower().Contains(searchTerm.ToString().ToLower()) || t.PurchaseRequestTypeName.ToLower().Contains(searchTerm.ToString().ToLower())
                                  select t;

                    IQueryable<GetPurchaseRequestHeaderDTO> test = countss.AsQueryable();

                    if (PageNo <= 0)
                        PageNo = 1;
                    var itemdataa = PagingList<GetPurchaseRequestHeaderDTO>.CreateAsync(test, PageNo, PageSize);
                    int indexx = 1;
                    foreach (var itms in itemdataa)
                    {
                        itms.Sl = indexx++;
                    }


                    itm.Data = itemdataa;
                    itm.currentPage = PageNo;
                    itm.totalCount = test.Count();
                    itm.pageSize = PageSize;
                }
                else
                {
                    if (data == null)
                        throw new Exception("Data Not Found.");
                    else
                    {
                        if (viewOrder.ToUpper() == "ASC")
                            data = data.OrderBy(o => o.PurchaseRequestId);
                        else if (viewOrder.ToUpper() == "DESC")
                            data = data.OrderByDescending(o => o.PurchaseRequestId);
                    }

                    if (PageNo <= 0)
                        PageNo = 1;
                    var itemdata = PagingList<GetPurchaseRequestHeaderDTO>.CreateAsync(data, PageNo, PageSize);
                    int index = 1;
                    foreach (var itms in itemdata)
                    {
                        itms.Sl = index++;
                    }

                    itm.Data = itemdata;
                    itm.currentPage = PageNo;
                    itm.totalCount = data.Count();
                    itm.pageSize = PageSize;

                }

                return itm;
            }




            throw new NotImplementedException();
        }
    }
}
