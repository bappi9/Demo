﻿using Procurement.DbContexts;
using Procurement.DTO.LandingPasignation;
using Procurement.DTO.SupplierInvoice;
using Procurement.Helper;
using Procurement.IRepository;
using Procurement.Models.Write;
using Procurement.StoreProcedure;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace Procurement.Repository
{
    public class SupplierInvoice : ISupplierInvoice
    {
        public readonly ReadDbContext _contextR;
        public readonly WriteDbContext _contextW;
        CodeGenerate objCG = new CodeGenerate();

        public SupplierInvoice(ReadDbContext contextR, WriteDbContext contextW)
        {
            _contextR = contextR;
            _contextW = contextW;
        }


        public async Task<SupplierInvoicePasignation> GetSupplierInvoicePasignation(long AccountId, long UnitId, long SbuId, long Plant, long WearHouse, long PurchaseOrganizationId, string viewOrder, long PageNo, long PageSize)
        {
            //throw new NotImplementedException();

            var counts = _contextR.TblSupplierInvoiceHeader.Where(x => x.IntAccountId == AccountId && x.IntBusinessUnitId == UnitId && x.IntSbuid == SbuId
            && x.IntPlantId == Plant && x.IntWarehouseId == WearHouse && x.IsActive == true
            && x.IntPurchaseOrganizationId == PurchaseOrganizationId).Count();

            IQueryable<GetSupplierInvoiceHeaderViewDTO> data = await Task.FromResult(from sih in _contextR.TblSupplierInvoiceHeader
                                                                                     join bp in _contextR.TblBusinessPartner on sih.IntBusinessPartnerId equals bp.IntBusinessPartnerId
                                                                                     where sih.IntAccountId == AccountId && sih.IntBusinessUnitId == UnitId
                                                                                     && sih.IntSbuid == SbuId && sih.IntPlantId == Plant && sih.IntWarehouseId == WearHouse
                                                                                     && sih.IntPurchaseOrganizationId == PurchaseOrganizationId
                                                                                     && sih.IsActive == true
                                                                                     select new GetSupplierInvoiceHeaderViewDTO
                                                                                     {
                                                                                         SupplierInvoiceId = sih.IntSupplierInvoiceId,
                                                                                         SupplierInvoiceCode=sih.IntSupplierInvoiceCode,
                                                                                         TransactionDate=sih.DteTransactionDate,
                                                                                         BillDate = sih.DteInvoiceDate,
                                                                                         BillNumber = sih.StrInvoiceNumber,
                                                                                         GrossInvoiceAmount = sih.NumGrossInvoiceAmount,
                                                                                         BusinessPartnerId = sih.IntBusinessPartnerId,
                                                                                         BusinessPartneName = bp.StrBusinessPartnerName,
                                                                                         PurchaseOrderNo = sih.StrPurchaseOrderNo,
                                                                                         DeductionAmount = sih.NumDeductionAmount,
                                                                                         AdvanceAdjustmentAmount = sih.NumAdvanceAdjustmentAmount,
                                                                                         NetPaymentAmount = sih.NumNetPaymentAmount,
                                                                                         PaymentDueDate = sih.DtePaymentDueDate
                                                                                     });
            int d = data.Count();
            if (data == null)
                throw new Exception("Supplier Invoice Header Not Exist in Database");
            else
            {
                if (viewOrder.ToUpper() == "ASC")
                    data = data.OrderBy(o => o.SupplierInvoiceId);
                else if (viewOrder.ToUpper() == "DESC")
                    data = data.OrderByDescending(o => o.SupplierInvoiceId);
            }

            if (PageNo <= 0)
                PageNo = 1;
            var itemdata = PagingList<GetSupplierInvoiceHeaderViewDTO>.CreateAsync(data, PageNo, PageSize);

            int index = 1;
            foreach (var itms in itemdata)
            {
                itms.Sl = index++;
            }
            SupplierInvoicePasignation itm = new SupplierInvoicePasignation();
            itm.Data = itemdata;
            itm.currentPage = PageNo;
            itm.totalCount = counts;
            itm.pageSize = PageSize;

            return itm;

        }

        public async Task<GetSupplierInvoiceCommonDTOById> GetSupplierInvoiceCommonDTOById(long SupplierInvoiceId)
        {
            //throw new NotImplementedException();

            try
            {
                GetSupplierInvoiceHeaderDTO headerData = await Task.FromResult((from sih in _contextR.TblSupplierInvoiceHeader
                                                                                join bp in _contextR.TblBusinessPartner on sih.IntBusinessPartnerId equals bp.IntBusinessPartnerId
                                                                                where sih.IsActive == true && sih.IntSupplierInvoiceId == SupplierInvoiceId
                                                                                select new GetSupplierInvoiceHeaderDTO
                                                                                {
                                                                                    SupplierInvoiceId = sih.IntSupplierInvoiceId,
                                                                                    SupplierInvoiceCode = sih.IntSupplierInvoiceCode,
                                                                                    AccountId = sih.IntAccountId,
                                                                                    BusinessUnitId = sih.IntBusinessUnitId,
                                                                                    BusinessUnitName = sih.StrBusinessUnitName,
                                                                                    Sbuid = sih.IntSbuid,
                                                                                    Sbuname = sih.StrSbuname,
                                                                                    PurchaseOrganizationId = sih.IntPurchaseOrganizationId,
                                                                                    PurchaseOrganizationName = sih.StrPurchaseOrganizationName,
                                                                                    PlantId = sih.IntPlantId,
                                                                                    PlantName = sih.StrPlantName,
                                                                                    WarehouseId = sih.IntWarehouseId,
                                                                                    WarehouseName = sih.StrWarehouseName,
                                                                                    BusinessPartnerId = sih.IntBusinessPartnerId,
                                                                                    BusinessPartnerName = bp.StrBusinessPartnerName,
                                                                                    PurchaseOrderId = sih.IntPurchaseOrderId,
                                                                                    PurchaseOrderNo = sih.StrPurchaseOrderNo,
                                                                                    PurchaseOrderDate = sih.DtePurchaseOrderDate,
                                                                                    InvoiceNumber = sih.StrInvoiceNumber,
                                                                                    InvoiceDate = sih.DteInvoiceDate,
                                                                                    TotalReferenceAmount = sih.NumTotalReferenceAmount,
                                                                                    GrossInvoiceAmount = sih.NumGrossInvoiceAmount,
                                                                                    DeductionAmount = sih.NumDeductionAmount,
                                                                                    AdvanceAdjustmentAmount = sih.NumAdvanceAdjustmentAmount,
                                                                                    NetPaymentAmount = sih.NumNetPaymentAmount,
                                                                                    Remarks = sih.StrRemarks,
                                                                                    ActionBy = sih.IntActionBy,
                                                                                    PaymentDueDate = sih.DtePaymentDueDate,
                                                                                    AttachmentId = sih.StrAttachmentId,
                                                                                    SupplierName = bp.StrBusinessPartnerName,
                                                                                    TotalPOAmount = (from i in _contextR.TblPurchaseOrderRow
                                                                                                     where i.IntPurchaseOrderId == sih.IntPurchaseOrderId
                                                                                                     select i.NumTotalValue).Sum(),
                                                                                }).FirstOrDefault());
                if (headerData == null)
                    throw new Exception("Supplier Invoice Not Exist in Database");

                List<GetSupplierInvoiceRowDTO> rowData = await Task.FromResult((from rw in _contextR.TblSupplierInvoiceRow
                    join it in _contextR.TblInventoryTransactionHeader on rw.IntReferenceId equals  it.IntInventoryTransactionId
                                                                                where rw.IntSupplierInvoiceId == SupplierInvoiceId && rw.IsActive == true
                                                                                select new GetSupplierInvoiceRowDTO
                                                                                {
                                                                                    RowId = rw.IntRowId,
                                                                                    SupplierInvoiceId = rw.IntSupplierInvoiceId,
                                                                                    ReferenceId = rw.IntReferenceId,
                                                                                    ReferenceAmount = rw.IntReferenceAmount,
                                                                                    ReferenceName = it.StrInventoryTransactionCode,
                                                                                    ActionBy = rw.IntActionBy
                                                                                }).ToList());


                GetSupplierInvoiceCommonDTOById objData = new GetSupplierInvoiceCommonDTOById()
                {
                    objHeaderDTO = headerData,
                    objRowListDTO = rowData
                };


                return objData;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<MessageHelper> CreateSupplierInvoice(CreateSupplierInvoiceCommonDTO objSI)
        {
            try
            {
                DataTable dtInvoiceCode = objCG.getCodeGenerate(objSI.HeaderData.AccountId, objSI.HeaderData.BusinessUnitId, 12);

                var detalis = new TblSupplierInvoiceHeader
                {
                    IntSupplierInvoiceId = objSI.HeaderData.SupplierInvoiceId,
                    IntSupplierInvoiceCode = dtInvoiceCode.Rows[0][0].ToString(),
                    DteTransactionDate=DateTime.UtcNow,
                    IntAccountId = objSI.HeaderData.AccountId,
                    IntBusinessUnitId = objSI.HeaderData.BusinessUnitId,
                    StrBusinessUnitName = objSI.HeaderData.BusinessUnitName,
                    IntSbuid = objSI.HeaderData.Sbuid,
                    StrSbuname = objSI.HeaderData.Sbuname,
                    IntPurchaseOrganizationId = objSI.HeaderData.PurchaseOrganizationId,
                    StrPurchaseOrganizationName = objSI.HeaderData.PurchaseOrganizationName,
                    IntPlantId = objSI.HeaderData.PlantId,
                    StrPlantName = objSI.HeaderData.PlantName,
                    IntWarehouseId = objSI.HeaderData.WarehouseId,
                    StrWarehouseName = objSI.HeaderData.WarehouseName,
                    IntBusinessPartnerId = objSI.HeaderData.BusinessPartnerId,
                    IntPurchaseOrderId = objSI.HeaderData.PurchaseOrderId,
                    StrPurchaseOrderNo = objSI.HeaderData.PurchaseOrderNo,
                    DtePurchaseOrderDate = objSI.HeaderData.PurchaseOrderDate,
                    StrInvoiceNumber = objSI.HeaderData.InvoiceNumber,
                    DteInvoiceDate = objSI.HeaderData.InvoiceDate,
                    NumTotalReferenceAmount = objSI.HeaderData.TotalReferenceAmount,
                    NumGrossInvoiceAmount = objSI.HeaderData.GrossInvoiceAmount,
                    NumDeductionAmount = objSI.HeaderData.DeductionAmount,
                    NumAdvanceAdjustmentAmount = objSI.HeaderData.AdvanceAdjustmentAmount,
                    NumNetPaymentAmount = objSI.HeaderData.NetPaymentAmount,
                    DtePaymentDueDate = objSI.HeaderData.PaymentDueDate,
                    StrRemarks = objSI.HeaderData.Remarks,
                    IntActionBy = objSI.HeaderData.ActionBy,
                    DteLastActionDateTime = DateTime.UtcNow,
                    IsActive = true,
                    StrAttachmentId = objSI.HeaderData.AttachmentId
                };


                await _contextW.TblSupplierInvoiceHeader.AddAsync(detalis);
                await _contextW.SaveChangesAsync();

                var JournalRows = new List<TblSupplierInvoiceRow>(objSI.RowListData.Count);
                foreach (var datas in objSI.RowListData)
                {
                    TblSupplierInvoiceRow detalisrow = new TblSupplierInvoiceRow { };

                    detalisrow.IntSupplierInvoiceId = detalis.IntSupplierInvoiceId;
                    detalisrow.IntReferenceId = datas.ReferenceId;
                    detalisrow.IntReferenceAmount = datas.ReferenceAmount;
                    detalisrow.IntActionBy = datas.ActionBy;
                    detalisrow.IsActive = datas.Active;
                    detalisrow.DteLastActionDateTime = datas.LastActionDateTime;
                    detalisrow.DteServerDateTime = DateTime.UtcNow;
                    JournalRows.Add(detalisrow);
                }

                await _contextW.TblSupplierInvoiceRow.AddRangeAsync(JournalRows);
                await _contextW.SaveChangesAsync();

                #region ACCOUNTING WITH GL
                var busPartner = _contextW.TblBusinessPartner.Where(x => x.IntBusinessPartnerId == objSI.HeaderData.BusinessPartnerId).FirstOrDefault();

                var detalisAcRP = new TblAccountReceivablePayableHeader
                {
                    IntAccountId = objSI.HeaderData.AccountId,
                    IntBusinessUnitId = objSI.HeaderData.BusinessUnitId,
                    IntSbuid = objSI.HeaderData.Sbuid,
                    IntBusinessPartnerId = objSI.HeaderData.BusinessPartnerId,
                    StrInvoiceCode = dtInvoiceCode.Rows[0][0].ToString(),
                    NumAmount = objSI.HeaderData.NetPaymentAmount,
                    StrNarration = "Being The Amount Purchase TO " + busPartner.StrBusinessPartnerName + " [" + objSI.HeaderData.BusinessPartnerId + "] . Purchase Order No: " + objSI.HeaderData.PurchaseOrderNo.ToString(),
                    IsReceivable = false,
                    IntPayTerm = 0,
                    DteTransactionDate = DateTime.UtcNow,
                    DteDueDate = DateTime.UtcNow,
                    IsCleared = false,
                    IntActionBy = objSI.HeaderData.ActionBy,
                    DteLastActionDateTime = DateTime.UtcNow
                };

                await _contextW.TblAccountReceivablePayableHeader.AddAsync(detalisAcRP);
                await _contextW.SaveChangesAsync();

                var accPayRow = await Task.FromResult((from ph in objSI.RowListData
                                                       join h in _contextW.TblInventoryTransactionHeader on ph.ReferenceId equals h.IntInventoryTransactionId
                                                       join pr in _contextW.TblInventoryTransactionRow on h.IntInventoryTransactionId equals pr.IntInventoryTransactionId
                                                       join i in _contextW.TblItem on pr.IntInventoryTransactionId equals i.IntItemId
                                                       where pr.IsActive == true
                                                       select new TblAccountPayableRow()
                                                       {
                                                           IntAccountReceivablePayableId = detalisAcRP.IntAccountReceivablePayableId,
                                                           StrInvoiceCode = detalisAcRP.StrInvoiceCode,
                                                           IntGrnid = ph.ReferenceId,
                                                           StrGrncode = h.StrInventoryTransactionCode,
                                                           IntPurchaseOrderId = objSI.HeaderData.PurchaseOrderId,
                                                           StrPurchaseOrderCode = objSI.HeaderData.PurchaseOrderNo,
                                                           IntGrnrowId = pr.IntRowId,
                                                           IntItemId = pr.IntItemId,
                                                           StrItemCode = i.StrItemCode,
                                                           StrItemName = i.StrItemName,
                                                           IntUom = pr.IntUoMid,
                                                           StrUom = pr.StrUoMname,
                                                           NumQuantity = pr.NumTransactionQuantity,
                                                           NumGrnvalue = (pr.MonTransactionValue / pr.NumTransactionQuantity),
                                                           IsFreeItem = false,
                                                           IsActive = true
                                                       }).ToList());
                await _contextW.TblAccountPayableRow.AddRangeAsync(accPayRow);
                await _contextW.SaveChangesAsync();

                DataTable dtAdjHCode = objCG.getCodeGenerate(objSI.HeaderData.AccountId, objSI.HeaderData.BusinessUnitId, 7);
                var objADJHeader = new TblAdjustmentJournalHeader
                {
                    StrAdjustmentJournalCode = dtAdjHCode.Rows[0][0].ToString(),
                    DteJournalDate = DateTime.UtcNow,
                    IntAccountId = objSI.HeaderData.AccountId,
                    IntBusinessUnitId = objSI.HeaderData.BusinessUnitId,
                    IntSbuid = objSI.HeaderData.Sbuid,
                    NumAmount = objSI.HeaderData.NetPaymentAmount,
                    StrNarration = "Adjustment Journal. Supplier Invoice  :" + objSI.HeaderData.SupplierInvoiceCode + "For Transaction Amount:" + objSI.HeaderData.NetPaymentAmount.ToString(),
                    IsPosted = true,
                    IntAccountingJournalTypeId = 10,
                    IsDirectPosting = true,
                    IntActionBy = 0,
                    DteLastActionDateTime = DateTime.UtcNow,
                    IsActive = true
                };
                await _contextW.TblAdjustmentJournalHeader.AddAsync(objADJHeader);
                await _contextW.SaveChangesAsync();

                var PartnerPurchase = _contextW.TblBusinessPartnerPurchase.Where(x => x.IntAccountId == objSI.HeaderData.AccountId && x.IntBusinessUnitId == objSI.HeaderData.BusinessUnitId
                                                      && x.IntSbuid == objSI.HeaderData.Sbuid && x.IntBusinessPartnerId == objSI.HeaderData.BusinessPartnerId
                                                      && x.IsActive == true).FirstOrDefault();
                var prtAccruedGL = _contextW.TblGeneralLedger.Where(s => s.IntGeneralLedgerId == PartnerPurchase.IntAccruedPayGlid && s.IsActive == true).FirstOrDefault();
                var prtAccPayGL = _contextW.TblGeneralLedger.Where(s => s.IntGeneralLedgerId == PartnerPurchase.IntAcPayGlid && s.IsActive == true).FirstOrDefault();

                var detalisAJRowDR = new TblAdjustmentJournalRow
                {
                    IntAdjustmentJournalId = objADJHeader.IntAdjustmentJournalId,
                    StrAdjustmentJournalCode = objADJHeader.StrAdjustmentJournalCode,
                    IntGeneralLedgerId = prtAccruedGL.IntGeneralLedgerId,
                    StrGeneralLedgerCode = prtAccruedGL.StrGeneralLedgerCode,
                    StrGeneralLedgerName = prtAccruedGL.StrGeneralLedgerName,
                    NumAmount = (objSI.HeaderData.NetPaymentAmount),
                    StrNarration = "Adjustment Journal For :" + busPartner.StrBusinessPartnerName + "With Amount :" + (objSI.HeaderData.NetPaymentAmount).ToString()
                };
                var detalisAJRowCR = new TblAdjustmentJournalRow
                {
                    IntAdjustmentJournalId = objADJHeader.IntAdjustmentJournalId,
                    StrAdjustmentJournalCode = objADJHeader.StrAdjustmentJournalCode,
                    IntGeneralLedgerId = prtAccPayGL.IntGeneralLedgerId,
                    StrGeneralLedgerCode = prtAccPayGL.StrGeneralLedgerCode,
                    StrGeneralLedgerName = prtAccPayGL.StrGeneralLedgerName,
                    NumAmount = (objSI.HeaderData.NetPaymentAmount * -1),
                    StrNarration = "Adjustment Journal For :" + busPartner.StrBusinessPartnerName + "With Amount : -" + (objSI.HeaderData.NetPaymentAmount).ToString()
                };
                var invoiceAccJrDR = new TblAccountingJournal
                {
                    IntAccountId = objSI.HeaderData.AccountId,
                    IntBusinessUnitId = objSI.HeaderData.BusinessUnitId,
                    IntSbuid = objSI.HeaderData.Sbuid,
                    IntAccountingJournalTypeId = objADJHeader.IntAccountingJournalTypeId,
                    IntAccountingJournalId = objADJHeader.IntAdjustmentJournalId,
                    StrAccountingJournalCode = objADJHeader.StrAdjustmentJournalCode,
                    DteTransactionDate = DateTime.UtcNow,
                    IntGeneralLedgerId = prtAccruedGL.IntGeneralLedgerId,
                    StrGeneralLedgerCode = prtAccruedGL.StrGeneralLedgerCode,
                    StrGeneralLedgerName = prtAccruedGL.StrGeneralLedgerName,
                    NumAmount = objSI.HeaderData.NetPaymentAmount,
                    StrNarration = "Accounting Journal For :" + busPartner.StrBusinessPartnerName + "With Amount :" + objSI.HeaderData.NetPaymentAmount.ToString(),
                    IntActionBy = 0,
                    DteLastActionDateTime = DateTime.UtcNow,
                    IsActive = true
                };
                var invoiceAccJrCR = new TblAccountingJournal
                {
                    IntAccountId = objSI.HeaderData.AccountId,
                    IntBusinessUnitId = objSI.HeaderData.BusinessUnitId,
                    IntSbuid = objSI.HeaderData.Sbuid,
                    IntAccountingJournalTypeId = objADJHeader.IntAccountingJournalTypeId,
                    IntAccountingJournalId = objADJHeader.IntAdjustmentJournalId,
                    StrAccountingJournalCode = objADJHeader.StrAdjustmentJournalCode,
                    DteTransactionDate = DateTime.UtcNow,
                    IntGeneralLedgerId = prtAccPayGL.IntGeneralLedgerId,
                    StrGeneralLedgerCode = prtAccPayGL.StrGeneralLedgerCode,
                    StrGeneralLedgerName = prtAccPayGL.StrGeneralLedgerName,
                    NumAmount = ((-1) * objSI.HeaderData.NetPaymentAmount),
                    StrNarration = "Accounting Journal For :" + busPartner.StrBusinessPartnerName + "With Amount :" + objSI.HeaderData.NetPaymentAmount.ToString(),
                    IntActionBy = 0,
                    DteLastActionDateTime = DateTime.UtcNow,
                    IsActive = true
                };

                await _contextW.TblAdjustmentJournalRow.AddAsync(detalisAJRowDR);
                await _contextW.TblAdjustmentJournalRow.AddAsync(detalisAJRowCR);
                await _contextW.TblAccountingJournal.AddAsync(invoiceAccJrDR);
                await _contextW.TblAccountingJournal.AddAsync(invoiceAccJrCR);
                await _contextW.SaveChangesAsync();

                var BusinessPartner = new TblBusinessPartnerLedger
                {
                    DteTransactionDate = DateTime.UtcNow,
                    IntAccountId = objSI.HeaderData.AccountId,
                    IntBusinessUnitId = objSI.HeaderData.BusinessUnitId,
                    IntSbuid = objSI.HeaderData.Sbuid,
                    IntBusinessPartnerId = objSI.HeaderData.BusinessPartnerId,
                    IntAccountingJournalTypeId = 3,
                    StrAccountingJournalTypeName = "Invoice",
                    NumAmount = ((-1) * objSI.HeaderData.NetPaymentAmount),
                    NumRunningAmount = 0,
                    StrNarration = "Being The Amount Purchase TO " + busPartner.StrBusinessPartnerName + " [" + objSI.HeaderData.BusinessPartnerId + "] . Purchase Order No: " + objSI.HeaderData.PurchaseOrderNo.ToString(),
                    IntAccountingJournalId = objADJHeader.IntAdjustmentJournalId,
                    IntActionBy = 0,
                    DteLastActionDateTime = DateTime.UtcNow
                };
                await _contextW.TblBusinessPartnerLedger.AddAsync(BusinessPartner);
                await _contextW.SaveChangesAsync();

                PartnerPurchase.NumLedgerBalance = PartnerPurchase.NumLedgerBalance + objSI.HeaderData.NetPaymentAmount;
                PartnerPurchase.NumUnbilledAmount = PartnerPurchase.NumUnbilledAmount - objSI.HeaderData.NetPaymentAmount;
                _contextW.TblBusinessPartnerPurchase.Update(PartnerPurchase);
                await _contextW.SaveChangesAsync();

                #endregion

                var msg = new MessageHelper();
                msg.Message = "Create Successfully";
                msg.statuscode = 200;
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<MessageHelper> EditSupplierInvoice(EditSupplierInvoiceCommonDTO objESI)
        {
            try
            {
                TblSupplierInvoiceHeader detalisHeader = _contextW.TblSupplierInvoiceHeader.First(x => x.IntSupplierInvoiceId == objESI.HeaderData.SupplierInvoiceId
                                                                                                  && x.IntAccountId == objESI.HeaderData.AccountId
                                                                                                  && x.IntBusinessUnitId == objESI.HeaderData.BusinessUnitId
                                                                                                  && x.IsActive == true);
                if (detalisHeader == null)
                    throw new Exception("Header Data NOt Found");
                else
                {

                    detalisHeader.NumTotalReferenceAmount = objESI.HeaderData.TotalReferenceAmount;
                    detalisHeader.NumNetPaymentAmount = objESI.HeaderData.NetPaymentAmount;
                    detalisHeader.NumGrossInvoiceAmount = objESI.HeaderData.GrossInvoiceAmount;
                    detalisHeader.NumDeductionAmount = objESI.HeaderData.DeductionAmount;
                    detalisHeader.StrRemarks = objESI.HeaderData.Remarks;
                    detalisHeader.StrAttachmentId = objESI.HeaderData.AttachmentId;

                    _contextW.TblSupplierInvoiceHeader.Update(detalisHeader);
                    await _contextW.SaveChangesAsync();
                }



                var mRows = new List<TblSupplierInvoiceRow>(objESI.RowData.Count);
                foreach (var datas in objESI.RowData)
                {
                    if (datas.RowId == 0)
                    {
                        var detalisrow = new TblSupplierInvoiceRow { };
                        detalisrow.IntSupplierInvoiceId = detalisHeader.IntSupplierInvoiceId;
                        detalisrow.IntReferenceId = datas.ReferenceId;
                        detalisrow.IntReferenceAmount = datas.ReferenceAmount;
                        detalisrow.DteLastActionDateTime = DateTime.UtcNow;
                        detalisrow.IntActionBy = datas.ActionBy;

                        mRows.Add(detalisrow);
                    }
                }

                var innerquery = from c in objESI.RowData
                                 where c.RowId > 0
                                 select c.RowId;
                var inactiveItems = (from p in _contextW.TblSupplierInvoiceRow
                                     where p.IntSupplierInvoiceId == objESI.HeaderData.SupplierInvoiceId && !innerquery.Contains(p.IntRowId)
                                     select p).ToList();
                if (inactiveItems.Count > 0)
                {
                    inactiveItems.ForEach(x => x.IsActive = false);
                    _contextW.TblSupplierInvoiceRow.UpdateRange(inactiveItems);
                    await _contextW.SaveChangesAsync();
                }


                if (mRows.Count > 0)
                {
                    await _contextW.TblSupplierInvoiceRow.AddRangeAsync(mRows);
                    await _contextW.SaveChangesAsync();
                }
                var msg = new MessageHelper();
                msg.Message = "Processing";
                msg.statuscode = 200;

                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<SupplierInvoicePasignation> GetSupplierInvoiceSearchPasignation(string searchTerm, long AccountId, long UnitId, long SbuId, long Plant, long WearHouse, long PurchaseOrganizationId, string viewOrder, long PageNo, long PageSize)
        {
            IQueryable<GetSupplierInvoiceHeaderViewDTO> data = await Task.FromResult(from sih in _contextR.TblSupplierInvoiceHeader
                                                                                     join bp in _contextR.TblBusinessPartner on sih.IntBusinessPartnerId equals bp.IntBusinessPartnerId
                                                                                     where sih.IntAccountId == AccountId && sih.IntBusinessUnitId == UnitId
                                                                                     && sih.IntSbuid == SbuId && sih.IntPlantId == Plant && sih.IntWarehouseId == WearHouse
                                                                                     && sih.IntPurchaseOrganizationId == PurchaseOrganizationId
                                                                                     && sih.IsActive == true
                                                                                     select new GetSupplierInvoiceHeaderViewDTO
                                                                                     {
                                                                                         SupplierInvoiceId = sih.IntSupplierInvoiceId,
                                                                                         SupplierInvoiceCode=sih.IntSupplierInvoiceCode,
                                                                                         TransactionDate=sih.DteTransactionDate,
                                                                                         BillDate = sih.DteInvoiceDate,
                                                                                         BillNumber = sih.StrInvoiceNumber,
                                                                                         GrossInvoiceAmount = sih.NumGrossInvoiceAmount,
                                                                                         BusinessPartnerId = sih.IntBusinessPartnerId,
                                                                                         BusinessPartneName = bp.StrBusinessPartnerName,
                                                                                         PurchaseOrderNo = sih.StrPurchaseOrderNo,
                                                                                         DeductionAmount = sih.NumDeductionAmount,
                                                                                         AdvanceAdjustmentAmount = sih.NumAdvanceAdjustmentAmount,
                                                                                         NetPaymentAmount = sih.NumNetPaymentAmount,
                                                                                         PaymentDueDate = sih.DtePaymentDueDate
                                                                                     });
            var counts = data.Count();

            SupplierInvoicePasignation itm = new SupplierInvoicePasignation();
            
            if (searchTerm != null)
            {
                var countss = from t in data
                    where t.BillNumber.ToLower().Contains(searchTerm.ToString().ToLower()) || t.PurchaseOrderNo.ToLower().Contains(searchTerm.ToString().ToLower())
                              select t;

                IQueryable<GetSupplierInvoiceHeaderViewDTO> test = countss.AsQueryable();

                if (PageNo <= 0)
                    PageNo = 1;
                var itemdata = PagingList<GetSupplierInvoiceHeaderViewDTO>.CreateAsync(test, PageNo, PageSize);
                int indexx = 1;
                foreach (var itms in itemdata)
                {
                    itms.Sl = indexx++;
                }


                itm.Data = itemdata;
                itm.currentPage = PageNo;
                itm.totalCount = test.Count();
                itm.pageSize = PageSize;
            }
            else
            {
                if (data == null)
                    throw new Exception("Data Not Found.");
                else
                {
                    if (viewOrder.ToUpper() == "ASC")
                        data = data.OrderBy(o => o.SupplierInvoiceId);
                    else if (viewOrder.ToUpper() == "DESC")
                        data = data.OrderByDescending(o => o.SupplierInvoiceId);
                }

                if (PageNo <= 0)
                    PageNo = 1;
                var itemdata = PagingList<GetSupplierInvoiceHeaderViewDTO>.CreateAsync(data, PageNo, PageSize);
                int index = 1;
                foreach (var itms in itemdata)
                {
                    itms.Sl = index++;
                }

                itm.Data = itemdata;
                itm.currentPage = PageNo;
                itm.totalCount = data.Count();
                itm.pageSize = PageSize;

            }

            return itm;
        }
    }
}
