﻿using Procurement.DbContexts;
using Procurement.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.Repository
{
    public class ProcurementTest : IProcurement
    {
        public readonly ReadDbContext _contextR;
        public readonly WriteDbContext _contextW;

        public ProcurementTest(ReadDbContext contextR , WriteDbContext contextW)
        {
            _contextR = contextR;
            _contextW = contextW;
        }

    }
}
