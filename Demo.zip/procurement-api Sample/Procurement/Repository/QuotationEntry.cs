﻿
using Procurement.DTO.RequestForQuotation;
using Procurement.Helper;
using Procurement.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.Repository
{
    public class QuotationEntry : IQuotationEntry
    {
        public Task<MessageHelper> QuotationEntrySupplier(QuotationEntryDTO quation)
        {
            throw new NotImplementedException();
        }
    }
}
