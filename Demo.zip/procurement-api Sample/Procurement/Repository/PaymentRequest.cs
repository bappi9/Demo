﻿using Procurement.DbContexts;
using Procurement.DTO;
using Procurement.DTO.PaymentRequest;
using Procurement.Helper;
using Procurement.IRepository;
using Procurement.Models.Write;
using Procurement.StoreProcedure;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.Repository
{
    public class PaymentRequest : IPayemntRequest
    {
        public readonly ReadDbContext _contextR;
        public readonly WriteDbContext _contextW;
        CodeGenerate objCG = new CodeGenerate();

        public PaymentRequest(ReadDbContext contextR, WriteDbContext contextW)
        {
            _contextR = contextR;
            _contextW = contextW;

        }


        public async Task<PaymentRequestLandingPasignation> PaymentRequestLanding(long BusinessUnitId, long PlantId, long UserId, string viewOrder, long PageNo, long PageSize)
        {
            IQueryable<PaymentLandigDTO> data = await Task.FromResult(from a in _contextR.TblSupplierInvoiceHeader
                                                join b in _contextR.TblPurchaseOrderHeader on a.IntPurchaseOrderId equals b.IntPurchaseOrderId
                                                where a.IntBusinessUnitId == BusinessUnitId && a.IntPlantId == PlantId
                                                select new PaymentLandigDTO()
                                                {
                                                    InvoiceId = a.IntPurchaseOrderId,
                                                    InvoiceCode = a.IntSupplierInvoiceCode,
                                                    TransanctionDate=a.DteTransactionDate,
                                                    InvoiceDate = a.DteInvoiceDate,
                                                    SBUId = a.IntSbuid,
                                                    PoAmount = (from p in _contextR.TblPurchaseOrderRow where p.IntPurchaseOrderId == a.IntPurchaseOrderId select p.NumTotalValue).Sum(),
                                                    GrnAmount = (from p in _contextR.TblSupplierInvoiceRow where p.IntSupplierInvoiceId == a.IntSupplierInvoiceId select p.IntReferenceAmount).Sum(),
                                                    InvoiceAmount = a.NumTotalReferenceAmount,
                                                    WareHouseId = a.IntWarehouseId,
                                                    WareHouseName = a.StrWarehouseName,
                                                    LedgerBalance = (from p in _contextR.TblBusinessPartnerPurchase where p.IntBusinessPartnerId == a.IntBusinessPartnerId select p.NumLedgerBalance).FirstOrDefault(),
                                                    PartnerId = a.IntBusinessPartnerId,
                                                    PartnerName = (from p in _contextR.TblBusinessPartner where p.IntBusinessPartnerId == a.IntBusinessPartnerId select p.StrBusinessPartnerName).FirstOrDefault()
                                                });

            var counts = data.Count();
            if (data == null)
                throw new Exception("Data not found.");
            else
            {
                if (viewOrder.ToUpper() == "ASC")
                    data = data.OrderBy(o => o.InvoiceId);
                else if (viewOrder.ToUpper() == "DESC")
                    data = data.OrderByDescending(o => o.InvoiceId);
            }

            if (PageNo <= 0)
                PageNo = 1;
            var itemdata = PagingList<PaymentLandigDTO>.CreateAsync(data, PageNo, PageSize);

            int index = 1;
            foreach (var itms in itemdata)
            {
                itms.Sl = index++;
            }
            PaymentRequestLandingPasignation itm = new PaymentRequestLandingPasignation();
            itm.Data = itemdata;
            itm.currentPage = PageNo;
            itm.totalCount = counts;
            itm.pageSize = PageSize;

            return itm;

        }

        public async Task<InvoiceDetalisDTO> PurchaseInvoiceDetails(long InvoiceId)
        {
            return await Task.FromResult((from a in _contextR.TblSupplierInvoiceHeader
                                          where a.IntPurchaseOrderId == InvoiceId && a.IsActive == true
                                          select new InvoiceDetalisDTO()
                                          {
                                              InvoiceId = a.IntPurchaseOrderId,
                                              InvoiceCode = a.IntSupplierInvoiceCode,
                                              PoAmount = (from p in _contextR.TblPurchaseOrderRow where p.IntPurchaseOrderId == a.IntPurchaseOrderId select p.NumTotalValue).Sum(),
                                              GrnAmount = (from p in _contextR.TblSupplierInvoiceRow where p.IntSupplierInvoiceId == a.IntSupplierInvoiceId select p.IntReferenceAmount).Sum(),
                                              InvoiceAmount = a.NumTotalReferenceAmount
                                              //PurchaseOrder=(from a in _contextR.tblPurc)
                                          }).FirstOrDefault());
        }
        public async Task<List<GetPaymentGLDTO>> GetCPurchaseGridData(long AccountId, long BusinessUnitId, long SBUId, long PartnerId, long CashGLId, decimal CashAmount, long BankAccId)
        {
            List<GetPaymentGLDTO> objList = new List<GetPaymentGLDTO>();

            var PartnerPurchase = _contextW.TblBusinessPartnerPurchase.Where(x => x.IntAccountId == AccountId && x.IntBusinessUnitId == BusinessUnitId
                                                      && x.IntSbuid == SBUId && x.IntBusinessPartnerId == PartnerId
                                                      && x.IsActive == true).FirstOrDefault();

            var data = await Task.FromResult((from h in _contextW.TblBusinessPartnerPurchase
                                              join gl in _contextW.TblGeneralLedger on h.IntAcPayGlid equals gl.IntGeneralLedgerId
                                              where h.IntAccountId == AccountId && h.IsActive == true && h.IntConfigId == PartnerPurchase.IntConfigId
                                              && h.IntBusinessUnitId == BusinessUnitId
                                              select new GetPaymentGLDTO()
                                              {
                                                  GLId = gl.IntGeneralLedgerId,
                                                  GLName = gl.StrGeneralLedgerName,
                                                  GLCode = gl.StrGeneralLedgerCode,
                                                  Amount = CashAmount
                                              }).FirstOrDefault());
            objList.Add(data);

            if (BankAccId == 0)
            {
                var CashGL = _contextW.TblGeneralLedger.Where(s => s.IntGeneralLedgerId == CashGLId && s.IsActive == true).FirstOrDefault();

                GetPaymentGLDTO objCASHGLInfo = new GetPaymentGLDTO()
                {
                    GLId = CashGL.IntGeneralLedgerId,
                    GLName = CashGL.StrGeneralLedgerName,
                    GLCode = CashGL.StrGeneralLedgerCode,
                    Amount = CashAmount * (-1)
                };
                objList.Add(objCASHGLInfo);
            }
            else
            {
                var BankGL = await Task.FromResult((from h in _contextW.TblBankAccount
                                                  join gl in _contextW.TblGeneralLedger on h.IntGeneralLedgerId equals gl.IntGeneralLedgerId
                                                  where h.IntAccountId == AccountId && h.IsActive == true && h.IntBankAccountId == BankAccId
                                                  && h.IntBusinessUnitId == BusinessUnitId
                                                  select new GetPaymentGLDTO()
                                                  {
                                                      GLId = gl.IntGeneralLedgerId,
                                                      GLName = gl.StrGeneralLedgerName,
                                                      GLCode = gl.StrGeneralLedgerCode,
                                                      Amount = CashAmount * (-1)
                                                  }).FirstOrDefault());
                objList.Add(BankGL);
            }

            return objList;

        }
        // Operation In Progress
        public async Task<MessageHelper> CreateCashBankPayment(CreateCashPaymentCommonDTO objCreate)
        {
            try
            {
                long CashJournalID = 0, BankJournalId = 0;

                if (objCreate.objList.Count == 0)
                    throw new Exception("Add Information For CashRow Payment.");

                List<TblAccountingJournal> objListAccJR = new List<TblAccountingJournal>();
                List<TblCashJournalRow> objListROW = new List<TblCashJournalRow>();
                List<TblBankJournalRow> objListBankROW = new List<TblBankJournalRow>();

                DataTable dtCashCode = objCG.getCodeGenerate(objCreate.objPay.AccountId, objCreate.objPay.BusinessUnitId, 2);

                var busPartner = _contextW.TblBusinessPartner.Where(x => x.IntBusinessPartnerId == objCreate.objPay.BusinessPartnerId).FirstOrDefault();
                //CASH JOURNAL ENTRY
                if (objCreate.objPay.PaymentProcessType == 1)
                {
                    var detalis = new TblCashJournalHeader
                    {
                        StrCashJournalCode = dtCashCode.Rows[0][0].ToString(),
                        IntAccountId = objCreate.objPay.AccountId,
                        IntBusinessUnitId = objCreate.objPay.BusinessUnitId,
                        DteJournalDate = DateTime.UtcNow,
                        IntSbuid = objCreate.objPay.Sbuid,
                        StrReceiveFrom = objCreate.objPay.ReceiveFrom,
                        StrTransferTo = objCreate.objPay.TransferTo,
                        StrPaidTo = objCreate.objPay.PaidTo,
                        IntGeneralLedgerId = objCreate.objPay.GeneralLedgerId,
                        StrGeneralLedgerCode = objCreate.objPay.GeneralLedgerCode,
                        StrGeneralLedgerName = objCreate.objPay.GeneralLedgerName,
                        NumAmount = objCreate.objPay.PayAmount,
                        NumInvoiceAdjustAmount = 0,
                        NumAdjustmentPendingAmount = 0,
                        StrNarration = objCreate.objPay.Narration,
                        IsPosted = true,
                        DteCompleteDateTime = DateTime.UtcNow,
                        IntBusinessPartnerId = objCreate.objPay.BusinessPartnerId,
                        StrBusinessPartnerCode = busPartner.StrBusinessPartnerCode,
                        StrBusinessPartnerName = busPartner.StrBusinessPartnerName,
                        IntAccountingJournalTypeId = 2,         //Cash Payments Journal
                        IsDirectPosting = false,
                        IntActionBy = objCreate.objPay.ActionBy,
                        DteLastActionDateTime = DateTime.UtcNow,
                        IsActive = true,
                        IsEmployee = false
                    };
                    await _contextW.TblCashJournalHeader.AddAsync(detalis);
                    await _contextW.SaveChangesAsync();

                    CashJournalID = detalis.IntCashJournalId;

                    foreach (var datas in objCreate.objList)
                    {
                        var detalisrow = new TblCashJournalRow { };

                        detalisrow.IntCashJournalId = detalis.IntCashJournalId;
                        detalisrow.StrCashJournalCode = detalis.StrCashJournalCode;
                        detalisrow.IntBankAccountId = datas.BankAccountId;
                        detalisrow.StrBankAccNo = datas.BankAccNo;
                        detalisrow.IntBusinessTransactionId = datas.BusinessTransactionId;
                        detalisrow.StrBusinessTransactionCode = datas.BusinessTransactionCode;
                        detalisrow.StrBusinessTransactionName = datas.BusinessTransactionName;

                        detalisrow.IntGeneralLedgerId = datas.GeneralLedgerId;
                        detalisrow.StrGeneralLedgerCode = datas.GeneralLedgerName;
                        detalisrow.StrGeneralLedgerName = datas.GeneralLedgerCode;
                        detalisrow.NumAmount = datas.PayAmount;
                        detalisrow.StrNarration = "Cash Payment For " + objCreate.objPay.BusinessPartnerName + " With Amount :" + datas.PayAmount.ToString();

                        detalisrow.IsActive = true;
                        detalisrow.IntActionBy = detalis.IntActionBy;
                        detalisrow.DteLastActionDateTime = DateTime.UtcNow;

                        objListROW.Add(detalisrow);

                        var AccJR = new TblAccountingJournal
                        {
                            IntAccountId = objCreate.objPay.AccountId,
                            IntBusinessUnitId = objCreate.objPay.AccountId,
                            IntSbuid = objCreate.objPay.AccountId,
                            IntAccountingJournalTypeId = detalis.IntAccountingJournalTypeId,
                            IntAccountingJournalId = detalis.IntCashJournalId,
                            StrAccountingJournalCode = detalis.StrCashJournalCode,
                            DteTransactionDate = DateTime.UtcNow,
                            IntGeneralLedgerId = detalisrow.IntGeneralLedgerId,
                            StrGeneralLedgerCode = detalisrow.StrGeneralLedgerCode,
                            StrGeneralLedgerName = detalisrow.StrGeneralLedgerName,
                            NumAmount = detalisrow.NumAmount,
                            StrNarration = "Accounting Journal For :" + objCreate.objPay.BusinessPartnerName + "With Amount :" + detalisrow.ToString(),
                            IntActionBy = 0,
                            DteLastActionDateTime = DateTime.UtcNow,
                            IsActive = true
                        };
                        objListAccJR.Add(AccJR);
                    }

                    await _contextW.TblCashJournalRow.AddRangeAsync(objListROW);
                    await _contextW.TblAccountingJournal.AddRangeAsync(objListAccJR);
                    await _contextW.SaveChangesAsync();
                }
                //BANK JOURNAL ENTRY
                else
                {
                    var detalisBJH = new TblBankJournalHeader
                    {
                        StrBankJournalCode = dtCashCode.Rows[0][0].ToString(),
                        IntAccountId = objCreate.objPay.AccountId,
                        IntBusinessUnitId = objCreate.objPay.BusinessUnitId,
                        DteVoucherDate = DateTime.UtcNow,
                        IntSbuid = objCreate.objPay.Sbuid,
                        IntBankId = objCreate.objPay.Sbuid,
                        StrBankName = objCreate.objPay.ReceiveFrom,
                        IntBankBranchId = objCreate.objPay.Sbuid,
                        StrBankBranchName = objCreate.objPay.ReceiveFrom,
                        IntBankAccountId = objCreate.objPay.Sbuid,
                        StrBankAccountNumber = objCreate.objPay.ReceiveFrom,

                        StrReceiveFrom = objCreate.objPay.ReceiveFrom,
                        StrPaidTo = objCreate.objPay.PaidTo,
                        StrTransferTo = objCreate.objPay.TransferTo,
                        IsPlacedInBank = true,
                        DtePlacingDate = DateTime.UtcNow,
                        IntGeneralLedgerId = objCreate.objPay.GeneralLedgerId,
                        StrGeneralLedgerCode = objCreate.objPay.GeneralLedgerCode,
                        StrGeneralLedgerName = objCreate.objPay.GeneralLedgerName,

                        NumAmount = objCreate.objPay.PayAmount,
                        NumInvoiceAdjustAmount = 0,
                        NumAdjustmentPendingAmount = 0,
                        StrNarration = objCreate.objPay.Narration,
                        IsPosted = true,
                        DteCompleteDateTime = DateTime.UtcNow,
                        IntBusinessPartnerId = objCreate.objPay.BusinessPartnerId,
                        StrBusinessPartnerCode = busPartner.StrBusinessPartnerCode,
                        StrBusinessPartnerName = busPartner.StrBusinessPartnerName,

                        IntInstrumentId = objCreate.objPay.InstrumentId,
                        StrInstrumentName = objCreate.objPay.InstrumentName,
                        StrInstrumentNo = objCreate.objPay.InstrumentName,
                        IntAccountingJournalTypeId = 2,         //Cash Payments Journal
                        IsDirectPosting = false,
                        IntActionBy = objCreate.objPay.ActionBy,
                        DteLastActionDateTime = DateTime.UtcNow,
                        IsActive = true,
                        IsEmployee = false
                    };
                    await _contextW.TblBankJournalHeader.AddAsync(detalisBJH);
                    await _contextW.SaveChangesAsync();

                    BankJournalId = detalisBJH.IntBankJournalId;

                    foreach (var datas in objCreate.objList)
                    {
                        var detalisrow = new TblBankJournalRow { };

                        detalisrow.IntBankJournalId = detalisBJH.IntBankJournalId;
                        detalisrow.StrBankJournalCode = detalisBJH.StrBankJournalCode;
                        detalisrow.IntBankAccountId = datas.BankAccountId;
                        detalisrow.StrBankAccNo = datas.BankAccNo;
                        detalisrow.IntBusinessTransactionId = datas.BusinessTransactionId;
                        detalisrow.StrBusinessTransactionCode = datas.BusinessTransactionCode;
                        detalisrow.StrBusinessTransactionName = datas.BusinessTransactionName;

                        detalisrow.IntGeneralLedgerId = datas.GeneralLedgerId;
                        detalisrow.StrGeneralLedgerCode = datas.GeneralLedgerName;
                        detalisrow.StrGeneralLedgerName = datas.GeneralLedgerCode;
                        detalisrow.NumAmount = datas.PayAmount;
                        detalisrow.StrNarration = "Cash Payment For " + objCreate.objPay.BusinessPartnerName + " With Amount :" + datas.PayAmount.ToString();
                        detalisrow.IsActive = true;

                        objListBankROW.Add(detalisrow);

                        var AccJR = new TblAccountingJournal
                        {
                            IntAccountId = objCreate.objPay.AccountId,
                            IntBusinessUnitId = objCreate.objPay.AccountId,
                            IntSbuid = objCreate.objPay.AccountId,
                            IntAccountingJournalTypeId = detalisBJH.IntAccountingJournalTypeId,
                            IntAccountingJournalId = detalisBJH.IntBankJournalId,
                            StrAccountingJournalCode = detalisBJH.StrBankJournalCode,
                            DteTransactionDate = DateTime.UtcNow,
                            IntGeneralLedgerId = detalisrow.IntGeneralLedgerId,
                            StrGeneralLedgerCode = detalisrow.StrGeneralLedgerCode,
                            StrGeneralLedgerName = detalisrow.StrGeneralLedgerName,
                            NumAmount = detalisrow.NumAmount,
                            StrNarration = "Accounting Journal For :" + objCreate.objPay.BusinessPartnerName + "With Amount :" + detalisrow.ToString(),
                            IntActionBy = 0,
                            DteLastActionDateTime = DateTime.UtcNow,
                            IsActive = true
                        };
                        objListAccJR.Add(AccJR);
                    }

                    await _contextW.TblBankJournalRow.AddRangeAsync(objListBankROW);
                    await _contextW.TblAccountingJournal.AddRangeAsync(objListAccJR);
                    await _contextW.SaveChangesAsync();
                }

                var BusinessPartner = new TblBusinessPartnerLedger
                {
                    DteTransactionDate = DateTime.UtcNow,
                    IntAccountId = objCreate.objPay.AccountId,
                    IntBusinessUnitId = objCreate.objPay.BusinessUnitId,
                    IntSbuid = objCreate.objPay.Sbuid,
                    IntBusinessPartnerId = (long)objCreate.objPay.BusinessPartnerId,
                    IntAccountingJournalTypeId = 3,
                    StrAccountingJournalTypeName = "Invoice",
                    NumAmount = objCreate.objPay.PayAmount,
                    NumRunningAmount = 0,
                    StrNarration = "Being The Amount Pay TO " + objCreate.objPay.BusinessPartnerId + ". Invoice Code: " + objCreate.objPay.InvoiceCode,
                    IntAccountingJournalId = 0,
                    IntActionBy = 0,
                    DteLastActionDateTime = DateTime.UtcNow
                };

                await _contextW.TblBusinessPartnerLedger.AddAsync(BusinessPartner);
                await _contextW.SaveChangesAsync();

                var accRcvPayable = _contextW.TblAccountReceivablePayableHeader.Where(x => x.IntBusinessPartnerId == objCreate.objPay.BusinessPartnerId
                                        && x.IntBusinessUnitId == objCreate.objPay.BusinessUnitId && x.IntAccountId == objCreate.objPay.AccountId
                                        && x.StrInvoiceCode == objCreate.objPay.InvoiceCode).FirstOrDefault();
                accRcvPayable.NumClearedAmount = accRcvPayable.NumClearedAmount + objCreate.objPay.PayAmount;




                var PartnerPurchase = _contextW.TblBusinessPartnerPurchase.Where(x => x.IntAccountId == objCreate.objPay.AccountId && x.IntBusinessUnitId == objCreate.objPay.BusinessUnitId
                                                    && x.IntSbuid == objCreate.objPay.Sbuid && x.IntBusinessPartnerId == objCreate.objPay.BusinessPartnerId
                                                    && x.IsActive == true).FirstOrDefault();

                PartnerPurchase.NumLedgerBalance = PartnerPurchase.NumLedgerBalance - objCreate.objPay.PayAmount;

                _contextW.TblAccountReceivablePayableHeader.Update(accRcvPayable);
                _contextW.TblBusinessPartnerPurchase.Update(PartnerPurchase);
                await _contextW.SaveChangesAsync();

                var msg = new MessageHelper();
                msg.Message = "Create Successfully";
                msg.statuscode = 200;
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



    }
}
