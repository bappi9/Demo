﻿using Procurement.DbContexts;
using Procurement.DTO;
using Procurement.DTO.LandingPasignation;
using Procurement.DTO.PurchaseOrganization;
using Procurement.Helper;
using Procurement.IRepository;
using Procurement.Models.Write;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.Repository
{
    public class PurchaseOrganization : IPurchaseOrganization
    {
        public readonly ReadDbContext _contextR;
        public readonly WriteDbContext _contextW;

        public PurchaseOrganization(ReadDbContext contextR, WriteDbContext contextW)
        {
            _contextR = contextR;
            _contextW = contextW;
        }

        public async Task<MessageHelper> CreatePurchaseOrganization(CreatePurchaseOrganizationDTO objCPO)
        {
            try
            {
                var result = _contextW.TblPurchaseOrganization.Where(x => x.IntAccountId == objCPO.AccountId
                                    && x.StrPurchaseOrganization == objCPO.PurchaseOrganization && x.IsActive == true).FirstOrDefault();

                if (result != null)
                    throw new Exception("Already Purchase Organization Exist.");

                var detalis = new TblPurchaseOrganization
                {
                    IntAccountId = objCPO.AccountId,
                    StrPurchaseOrganization = objCPO.PurchaseOrganization,
                    IsActive = true
                };
                await _contextW.TblPurchaseOrganization.AddAsync(detalis);
                await _contextW.SaveChangesAsync();

                var msg = new MessageHelper();
                msg.Message = "Processing";
                msg.statuscode = 200;
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<MessageHelper> ConfigPurchaseOrganization(List<ConfigPurchaseOrganizationDTO> objConfigCPO)
        {
            var msg = new MessageHelper();
            long? SOId = 0;
            long AId = 0;
            try
            {
                var mRows = new List<TblBusinessUnitPurchaseOrganization>(objConfigCPO.Count);
                if (objConfigCPO.Count != 0)
                {
                    foreach (var datas in objConfigCPO)
                    {
                        if (datas.ConfigId == 0)
                        {
                            var detalisrow = new TblBusinessUnitPurchaseOrganization { };
                            detalisrow.IntAccountId = datas.AccountId;
                            detalisrow.StrAccountName = datas.AccountName;
                            detalisrow.IntBusinessUnitId = datas.BusinessUnitId;
                            detalisrow.StrBusinessUnitName = datas.BusinessUnitName;
                            detalisrow.IntPurchaseOrganizationid = datas.PurchaseOrganizationid;
                            detalisrow.StrPurchaseOrganization = datas.PurchaseOrganization;
                            detalisrow.IntActionBy = datas.ActionBy;
                            detalisrow.DteLastActionDateTime = DateTime.UtcNow;
                            detalisrow.IsActive = true;
                            mRows.Add(detalisrow);
                        }
                        SOId = datas.PurchaseOrganizationid;
                        AId = datas.AccountId;
                    }
                    var innerquery = from c in objConfigCPO
                                     where c.ConfigId > 0
                                     select c.ConfigId;
                    var inactiveItems = (from p in _contextW.TblBusinessUnitPurchaseOrganization
                                         where p.IntAccountId == AId && p.IntPurchaseOrganizationid == SOId && !innerquery.Contains(p.IntConfigId)
                                         select p).ToList();
                    foreach (var a in inactiveItems)
                    {
                        a.IsActive = false;
                    }

                    _contextW.TblBusinessUnitPurchaseOrganization.UpdateRange(inactiveItems);
                    await _contextW.SaveChangesAsync();
                    if (mRows.Count > 0)
                    {
                        await _contextW.TblBusinessUnitPurchaseOrganization.AddRangeAsync(mRows);
                        await _contextW.SaveChangesAsync();
                    }
                    msg.Message = "Processing";
                    msg.statuscode = 200;
                    return msg;
                }
                else
                {
                    throw new Exception("Your are not slect any Row. Please Add at least One Row.");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<MessageHelper> UpdatePurchaseOrganization(UpdatePurchaseOrganizationDTO objUpdateConfigCPO)
        {
            try
            {
                var msg = new MessageHelper();
                var result = _contextW.TblBusinessUnitPurchaseOrganization.Where(x => x.IntPurchaseOrganizationid == objUpdateConfigCPO.PurchaseOrganizationid
                            && x.IntBusinessUnitId != objUpdateConfigCPO.BusinessUnit && x.IntAccountId != objUpdateConfigCPO.AccountId
                            && x.StrPurchaseOrganization != objUpdateConfigCPO.PurchaseOrganization && x.IsActive == true).FirstOrDefault();

                if (result == null)
                {
                    Models.Write.TblBusinessUnitPurchaseOrganization detalisrow = _contextW.TblBusinessUnitPurchaseOrganization.First(x => x.IntConfigId == objUpdateConfigCPO.ConfigId);
                    detalisrow.IntAccountId = objUpdateConfigCPO.AccountId;
                    detalisrow.IntBusinessUnitId = objUpdateConfigCPO.BusinessUnit;
                    detalisrow.StrAccountName = objUpdateConfigCPO.AccountName;
                    detalisrow.StrBusinessUnitName = objUpdateConfigCPO.BusinessUnitName;
                    detalisrow.IntPurchaseOrganizationid = objUpdateConfigCPO.PurchaseOrganizationid;
                    detalisrow.StrPurchaseOrganization = objUpdateConfigCPO.PurchaseOrganization;
                    detalisrow.IsActive = objUpdateConfigCPO.Active;
                    detalisrow.IntActionBy = objUpdateConfigCPO.ActionBy;
                    detalisrow.DteLastActionDateTime = DateTime.UtcNow;

                    _contextW.TblBusinessUnitPurchaseOrganization.Update(detalisrow);
                    await _contextW.SaveChangesAsync();
                }
                else
                    throw new Exception(" Business Unit Purchase Organization Already Exist.");

                msg.Message = "Processing";
                msg.statuscode = 200;
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PurchaseOrganizationPasignation> GetPurchaseOrganizationPasignation(long AccountId, bool status, string viewOrder, long PageNo, long PageSize)
        {
            var counts = _contextR.TblPurchaseOrganization.Where(x => x.IntAccountId == AccountId && x.IsActive == status).Count();
            IQueryable<GetPurchaseOrganizationPasignationDTO> data = (from p in _contextR.TblPurchaseOrganization
                                                                      where p.IsActive == status && p.IntAccountId == AccountId
                                                                      orderby p.StrPurchaseOrganization ascending 
                                                                      select new GetPurchaseOrganizationPasignationDTO
                                                                      {
                                                                          PurchaseOrganizationid = p.IntPurchaseOrganizationid,
                                                                          PurchaseOrganization = p.StrPurchaseOrganization

                                                                      });

            if (data == null)
                throw new Exception("Purchase Organization Not Exist in Database");
            else
            {
                if (viewOrder.ToUpper() == "ASC")
                    data = data.OrderBy(o => o.PurchaseOrganizationid);
                else if (viewOrder.ToUpper() == "DESC")
                    data = data.OrderByDescending(o => o.PurchaseOrganizationid);
            }

            if (PageNo <= 0)
                PageNo = 1;
            var itemdata = PagingList<GetPurchaseOrganizationPasignationDTO>.CreateAsync(data, PageNo, PageSize);
            int index = 1;
            foreach (var itms in itemdata)
            {
                itms.SL = index++;
            }
            PurchaseOrganizationPasignation itm = new PurchaseOrganizationPasignation();
            itm.Data = itemdata;
            itm.currentPage = PageNo;
            itm.totalCount = counts;
            itm.pageSize = PageSize;

            return itm;
        }
        public async Task<ConfigPurchaseOrganizationPasignation> GetConfigPurchaseOrganizationPasignation(long AccountId, bool status, string viewOrder, long PageNo, long PageSize)
        {
            var counts = _contextR.TblBusinessUnitPurchaseOrganization.Where(x => x.IntAccountId == AccountId && x.IsActive == status).Count();
            IQueryable<GetConfigPurchaseOrganizationPasignationDTO> data = (from p in _contextR.TblBusinessUnitPurchaseOrganization
                                                                      where p.IsActive == status && p.IntAccountId == AccountId
                                                                      orderby p.StrPurchaseOrganization ascending 
                                                                      select new GetConfigPurchaseOrganizationPasignationDTO
                                                                      {
                                                                          ConfigId = p.IntConfigId,
                                                                          AccountId = p.IntAccountId,
                                                                          BusinessUnit = p.IntBusinessUnitId,
                                                                          AccountName = p.StrAccountName,
                                                                          BusinessUnitName = p.StrBusinessUnitName,
                                                                          PurchaseOrganizationid = p.IntPurchaseOrganizationid,
                                                                          PurchaseOrganization = p.StrPurchaseOrganization

                                                                      });

            if (data == null)
                throw new Exception("Purchase Organization Not Exist in Database");
            else
            {
                if (viewOrder.ToUpper() == "ASC")
                    data = data.OrderBy(o => o.ConfigId);
                else if (viewOrder.ToUpper() == "DESC")
                    data = data.OrderByDescending(o => o.ConfigId);
            }

            if (PageNo <= 0)
                PageNo = 1;
            var itemdata = PagingList<GetConfigPurchaseOrganizationPasignationDTO>.CreateAsync(data, PageNo, PageSize);
            int index = 1;
            foreach (var itms in itemdata)
            {
                itms.SL = index++;
            }
            ConfigPurchaseOrganizationPasignation itm = new ConfigPurchaseOrganizationPasignation();
            itm.Data = itemdata;
            itm.currentPage = PageNo;
            itm.totalCount = counts;
            itm.pageSize = PageSize;

            return itm;
        }

        public async Task<List<GetPurchaseOrganizationByIdDTO>> GetPurchaseOrganizationById( long POId)
        {
            var data = await Task.FromResult((from bp in _contextR.TblPurchaseOrganization
                                              where  bp.IntPurchaseOrganizationid == POId && bp.IsActive == true
                                              select new GetPurchaseOrganizationByIdDTO()
                                              {
                                                  PurchaseOrganizationid = bp.IntPurchaseOrganizationid,
                                                  PurchaseOrganization = bp.StrPurchaseOrganization

                                              }).ToList());
            if (data == null)
                throw new Exception("Purchase Organization Not Found.");

            return data;
        }

        public async Task<List<GetPOcommonDTO>> GetPurchaseOrganizationViewDataByPOId(long POId)
        {
            GetPurchaseOrganizationByIdDTO header = await Task.FromResult((from t in _contextR.TblPurchaseOrganization

                                                                           where t.IsActive == true && t.IntPurchaseOrganizationid == POId
                                                                           orderby t.IntPurchaseOrganizationid descending
                                                                              select new GetPurchaseOrganizationByIdDTO
                                                                              {
                                                                                  PurchaseOrganizationid = t.IntPurchaseOrganizationid,
                                                                                  PurchaseOrganization = t.StrPurchaseOrganization

                                                                              }).Distinct().FirstOrDefault());
            List<GetPurchaseOrgRowDTO> row = await Task.FromResult((from t in _contextR.TblBusinessUnitPurchaseOrganization
                                                            where t.IsActive == true && t.IntPurchaseOrganizationid == POId
                                                                    select new GetPurchaseOrgRowDTO
                                                                    {
                                                                        ConfigId = t.IntConfigId,
                                                                        POId = t.IntPurchaseOrganizationid,
                                                                        POName = t.StrPurchaseOrganization,
                                                                        BusinessUnitId = t.IntBusinessUnitId,
                                                                        BusinessUnitName = t.StrBusinessUnitName
                                                            }).ToList());

            List<GetPOcommonDTO> objListData = new List<GetPOcommonDTO>();
            GetPOcommonDTO objData = new GetPOcommonDTO()
            {
                objHeader = header,
                objRow = row
            };

            if (objData == null)
                throw new Exception("Purchase Organization Not Exist in Database");
            else
                objListData.Add(objData);

            return objListData;
        }



        public async Task<List<PurchaseOrganizationDTO>> GetPurchaseOrganizationList(long UnitId)
        {
           
            List<PurchaseOrganizationDTO> row = await Task.FromResult((from t in _contextR.TblBusinessUnitPurchaseOrganization
                                                                    where t.IsActive == true && t.IntBusinessUnitId == UnitId
                                                                    select new PurchaseOrganizationDTO
                                                                    {
                                                                          
                                                                        value = t.IntPurchaseOrganizationid,
                                                                        label = t.StrPurchaseOrganization,
                                                                      
                                                                    }).ToList());
 
 

            return row;
        }
    }
}
