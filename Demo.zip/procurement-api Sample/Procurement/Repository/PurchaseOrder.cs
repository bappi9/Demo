﻿using Org.BouncyCastle.Crypto.Digests;
using Procurement.DbContexts;
using Procurement.DTO;
using Procurement.DTO.CCO;
using Procurement.DTO.LandingPasignation;
using Procurement.DTO.POCreate;
using Procurement.DTO.PurchaseOrder;
using Procurement.DTO.PurchaseOrganization;
using Procurement.FunctionalService;
using Procurement.Helper;
using Procurement.IRepository;
using Procurement.Models.Write;
using Procurement.StoreProcedure;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.Repository
{
    public class PurchaseOrder : IPurchaseOrder
    {
        public readonly ReadDbContext _contextR;
        public readonly WriteDbContext _contextW;
        public readonly ApprovalTransections _approval;
        CodeGenerate objCG = new CodeGenerate();

        public PurchaseOrder(ReadDbContext contextR, WriteDbContext contextW, ApprovalTransections approval)
        {
            _contextR = contextR;
            _contextW = contextW;
            _approval = approval;
        }

        public async Task<List<GetOrderTypeDDLDTO>> GetOrderTypeListDDL()
        {
            //throw new NotImplementedException();
            var data = await Task.FromResult((from pot in _contextR.TblPurchaseOrderReffTypeConfig
                                              orderby pot.StrPurchaseOrderTypeName ascending
                                              select new GetOrderTypeDDLDTO
                                              {
                                                  Value = pot.IntPurchaseOrderTypeId,
                                                  Label = pot.StrPurchaseOrderTypeName

                                              }).Distinct().ToList());

            return data;

        }
        public async Task<List<getReferenceTypeDTO>> getPOReferenceType(long PoTypeId)
        {
            //throw new NotImplementedException();
            var data = await Task.FromResult((from rt in _contextR.TblPurchaseOrderReffTypeConfig
                                              where rt.IntPurchaseOrderTypeId == PoTypeId && rt.IsActive == true
                                              orderby rt.StrPoreferenceType ascending
                                              select new getReferenceTypeDTO
                                              {
                                                  Value = rt.IntPoreferenceTypeId,
                                                  Label = rt.StrPoreferenceType

                                              }).ToList());

            return data;
        }
        public async Task<List<GetCommonDDLDTO>> GetPOReferenceNoDDL(long RefTypeId, long WarehouseId)
        {
            List<GetCommonDDLDTO> list = new List<GetCommonDDLDTO>();
            if (RefTypeId == 1)// for purchase Contract.
            {
                var data = await Task.FromResult((from rt in _contextR.TblPurchaseContractHeader
                                                  where rt.IntWarehouseId == WarehouseId
                                                  orderby rt.IntPurchaseContractId ascending
                                                  select new GetCommonDDLDTO
                                                  {
                                                      Value = rt.IntPurchaseContractId,
                                                      Label = rt.StrPurchaseContractNo

                                                  }).ToList());
                list = data.ToList();

            }
            else if (RefTypeId == 2)// for purchase Request.
            {
                var data = await Task.FromResult((from rt in _contextR.TblPurchaseRequestHeader
                                                  where rt.IntWarehouseId == WarehouseId
                                                  orderby rt.IntPurchaseRequestId ascending
                                                  select new GetCommonDDLDTO
                                                  {
                                                      Value = rt.IntPurchaseRequestId,
                                                      Label = string.Concat(rt.IntPurchaseRequestId, "-", rt.StrPurchaseRequestCode)

                                                  }).ToList());
                list = data.ToList();
            }
            else if (RefTypeId == 3)// for without purchase reference.
            {
                var data = "";
            }
            else if (RefTypeId == 4)// for PO reference.
            {
                var data = await Task.FromResult((from rt in _contextR.TblPurchaseOrderHeader
                                                  where rt.IntWarehouseId == WarehouseId
                                                  orderby rt.IntPurchaseOrderId ascending
                                                  select new GetCommonDDLDTO
                                                  {
                                                      Value = rt.IntPurchaseOrderId,
                                                      Label = rt.StrPurchaseOrderNo

                                                  }).ToList());
                list = data.ToList();
            }
            return list;

        }
        public async Task<List<GetSupplierDDLDTO>> GetSupplierListDDL(long AccountId, long UnitId, long SBUId)
        {
            //throw new NotImplementedException();
            var data = await Task.FromResult((from bpp in _contextR.TblBusinessPartnerPurchase
                                              join bp in _contextR.TblBusinessPartner on bpp.IntBusinessPartnerId equals bp.IntBusinessPartnerId
                                              where bpp.IsActive == true && bp.IsActive == true && bpp.IntBusinessUnitId == UnitId && bpp.IntAccountId == AccountId && bp.IntBusinessPartnerTypeId == 1 && bpp.IntSbuid == SBUId
                                              orderby bp.StrBusinessPartnerName ascending
                                              select new GetSupplierDDLDTO
                                              {
                                                  Value = bpp.IntBusinessPartnerId,
                                                  Label = bp.StrBusinessPartnerName,
                                                  SupplierAddress = bp.StrBusinessPartnerAddress,
                                                  SupplierContact = bp.StrContactNumber

                                              }).ToList());

            return data;
        }
        public async Task<List<GetCurrencyDDLDTO>> GetCurrencyListDDL(long AccountId, long UnitId)
        {
            //throw new NotImplementedException();
            var data = await Task.FromResult((from uc in _contextR.TblBusinessUnitCurrency
                                              join c in _contextR.TblCurrency on uc.IntCurrencyId equals c.IntCurrencyId
                                              where uc.IsActive == true && uc.IntBusinessUnitId == UnitId && uc.IntAccountId == AccountId
                                              orderby c.StrCurrencyName ascending
                                              select new GetCurrencyDDLDTO
                                              {
                                                  Value = uc.IntCurrencyId,
                                                  Label = c.StrCurrencyName

                                              }).ToList());

            return data;
        }
        public async Task<MessageHelper> CreateStanderdAssetServicePurchaseOrder(CreatePurchaseOrderCommonDTO objPO)
        {
            try
            {
                if (objPO.objRowListDTO.Count > 0)
                {
                    DataTable PurCode = objCG.getCodeGenerate(objPO.objHeaderDTO.AccountId, objPO.objHeaderDTO.BusinessUnitId, 25);

                    var detalis = new Models.Write.TblPurchaseOrderHeader
                    {
                        StrPurchaseOrderNo = PurCode.Rows[0][0].ToString(),//string.Concat("PO", "-", objPO.objHeaderDTO.AccountId.ToString(), "-", objPO.objHeaderDTO.BusinessUnitId.ToString(), "-", DateTime.Now.ToString("yyyyMMddHHmmssfff")),

                        IntAccountId = objPO.objHeaderDTO.AccountId,
                        IntBusinessUnitId = objPO.objHeaderDTO.BusinessUnitId,
                        IntPlantId = objPO.objHeaderDTO.PlantId,
                        IntSbuid = objPO.objHeaderDTO.SbuId,
                        StrPlantName = objPO.objHeaderDTO.PlantName,
                        IntWarehouseId = objPO.objHeaderDTO.WarehouseId,
                        StrWarehouseName = objPO.objHeaderDTO.WarehouseName,
                        IntSupplyingWarehouseId = objPO.objHeaderDTO.SupplyingWarehouseId,
                        StrSupplyingWarehouseName = objPO.objHeaderDTO.SupplyingWarehouseName,
                        IntPurchaseOrganizationId = objPO.objHeaderDTO.PurchaseOrganizationId,
                        IntBusinessPartnerId = objPO.objHeaderDTO.BusinessPartnerId,
                        StrBusinessPartnerName = (objPO.objHeaderDTO.BusinessPartnerId == 0) ? "" : (from i in _contextW.TblBusinessPartner
                                                                                                     where i.IntBusinessPartnerId == objPO.objHeaderDTO.BusinessPartnerId
                                                                                                     select i.StrBusinessPartnerName).FirstOrDefault(),
                        DtePurchaseOrderDate = objPO.objHeaderDTO.PurchaseOrderDate,
                        IntPurchaseOrderTypeId = objPO.objHeaderDTO.PurchaseOrderTypeId,
                        IntIncotermsId = objPO.objHeaderDTO.IncotermsId,
                        IntCurrencyId = objPO.objHeaderDTO.CurrencyId,
                        StrCurrencyCode = (objPO.objHeaderDTO.CurrencyId == 0) ? "" : (from c in _contextR.TblCurrency
                                                                                       where c.IntCurrencyId == objPO.objHeaderDTO.CurrencyId
                                                                                       select c.StrCurrencyCode).FirstOrDefault(),
                        StrSupplierReference = objPO.objHeaderDTO.SupplierReference,
                        DteReferenceDate = objPO.objHeaderDTO.ReferenceDate,
                        IntReferenceTypeId = objPO.objHeaderDTO.ReferenceTypeId,
                        IntPriceStructureId = objPO.objHeaderDTO.PriceStructureId,
                        IntPaymentTerms = objPO.objHeaderDTO.PaymentTerms,
                        IntCreditPercent = objPO.objHeaderDTO.CreditPercent,
                        IntCashOrAdvancePercent = objPO.objHeaderDTO.CashOrAdvancePercent,
                        StrOtherTerms = objPO.objHeaderDTO.OtherTerms,
                        DtePovalidityDate = objPO.objHeaderDTO.POValidityDate,
                        DteLastShipmentDate = objPO.objHeaderDTO.LastShipmentDate,
                        IntPaymentDaysAfterDelivery = objPO.objHeaderDTO.PaymentDaysAfterDelivery,
                        StrDeliveryAddress = objPO.objHeaderDTO.DeliveryAddress,
                        IntActionBy = objPO.objHeaderDTO.ActionBy,
                        DteLastActionDateTime = DateTime.UtcNow,
                        IsApproved = false,
                        IntApproveBy = 0,
                        DteApproveDatetime = DateTime.UtcNow,
                        DteReturnDateTime = objPO.objHeaderDTO.ReturnDate
                    };
                    var dt = _contextR.TblApprovalConfigHeader.Where(a => a.PredisorActivityId == 2 && a.UnitId == detalis.IntBusinessUnitId && a.IsActive == true).FirstOrDefault();
                    if (dt == null)
                    {
                        detalis.IsApproved = true;
                    }
                    await _contextW.TblPurchaseOrderHeader.AddAsync(detalis);
                    await _contextW.SaveChangesAsync();

                    foreach (var datas in objPO.objRowListDTO)
                    {
                        var detalisrow = new Models.Write.TblPurchaseOrderRow { };

                        detalisrow.IntPurchaseOrderId = detalis.IntPurchaseOrderId;

                        detalisrow.IntReferenceId = datas.ReferenceId;
                        detalisrow.StrReferenceCode = datas.ReferenceCode;

                        detalisrow.NumReferenceQty = datas.ReferenceQty;
                        detalisrow.IntItemId = datas.ItemId;
                        detalisrow.StrItemName = datas.ItemName;
                        detalisrow.IntUoMid = datas.UoMid;
                        detalisrow.StrUoMname = datas.UoMname;
                        detalisrow.IntControllingUnitId = datas.ControllingUnitId;
                        detalisrow.StrControllingUnitName = datas.ControllingUnitName;
                        detalisrow.IntCostCenterId = datas.CostCenterId;
                        detalisrow.StrCostCenterName = datas.CostCenterName;
                        detalisrow.IntCostElementId = datas.CostElementId;
                        detalisrow.StrCostElementName = datas.CostElementName;
                        detalisrow.StrPurchaseDescription = datas.PurchaseDescription;
                        detalisrow.StrPurchaseDescription = datas.PurchaseDescription;
                        detalisrow.NumOrderQty = datas.OrderQty;
                        detalisrow.NumBasePrice = datas.BasePrice;
                        detalisrow.NumFinalPrice = datas.FinalPrice;
                        detalisrow.NumTotalValue = datas.TotalValue;
                        detalisrow.IntActionBy = detalis.IntActionBy;
                        detalisrow.DteLastActionDateTime = DateTime.UtcNow;

                        await _contextW.TblPurchaseOrderRow.AddAsync(detalisrow);
                        await _contextW.SaveChangesAsync();

                        var mPriceRow = new List<Models.Write.TblPurchaseOrderRowPricingDetail>();
                        //datas.objPriceRowListDTO.Count
                        var mRow = new List<Models.Write.TblPurchaseOrderRowPricingDetail>();
                        //datas.objPriceRowListDTO.Count
                        foreach (var datasPriceRow in datas.objPriceRowListDTO)
                        {
                            var detalisrows = new Models.Write.TblPurchaseOrderRowPricingDetail { };
                            detalisrows.IntPurchaseOrderRowId = detalisrow.IntRowId;
                            detalisrows.IntPriceStructureId = datasPriceRow.PriceStructureId;
                            detalisrows.IntBaseComponentId = datasPriceRow.BaseComponentId;
                            detalisrows.IntPriceComponentId = datasPriceRow.PriceComponentId;
                            detalisrows.StrPriceComponentCode = datasPriceRow.PriceComponentCode;
                            detalisrows.StrPriceComponentName = datasPriceRow.PriceComponentName;

                            detalisrows.IntSequence = datasPriceRow.SerialNo;
                            detalisrows.StrValueType = datasPriceRow.ValueType;
                            detalisrows.NumValue = datasPriceRow.Value;
                            detalisrows.NumAmount = datasPriceRow.Amount;
                            detalisrows.IntSumFromSerial = datasPriceRow.SumFromSerial;
                            detalisrows.IntSumToSerial = datasPriceRow.SumToSerial;
                            detalisrows.IsManual = datasPriceRow.Mannual;
                            detalisrows.IsActive = true;
                            detalisrows.NumFactor = datasPriceRow.Factor;


                            mPriceRow.Add(detalisrows);
                        }
                        await _contextW.TblPurchaseOrderRowPricingDetail.AddRangeAsync(mPriceRow);
                        await _contextW.SaveChangesAsync();

                        if (datas.BomId != 0)
                        {
                            var pobomdetail = new Models.Write.TblPurchaseOrderRowBillOfMaterialDetail { };
                            pobomdetail.IntPurchaseOrderRowId = detalisrow.IntRowId;
                            pobomdetail.IntPurchaseOrderRowItemId = datas.ItemId;
                            pobomdetail.IntBillOfMaterialId = datas.BomId;
                            pobomdetail.StrBillOfMaterialName = (from c in _contextR.TblBillOfMaterialHeader
                                                                 where c.IntBillOfMaterialId == datas.BomId
                                                                 select c.StrBillOfMaterialName).FirstOrDefault();
                            pobomdetail.IntBillOfMaterialCode = (from c in _contextR.TblBillOfMaterialHeader
                                                                 where c.IntBillOfMaterialId == datas.BomId
                                                                 select c.StrBillOfMaterialCode).FirstOrDefault();
                            pobomdetail.IntBomitemId = (from c in _contextR.TblBillOfMaterialHeader
                                                        where c.IntBillOfMaterialId == datas.BomId
                                                        select c.IntItemId).FirstOrDefault();
                            pobomdetail.StrBomitemName = (from c in _contextR.TblBillOfMaterialHeader
                                                          join i in _contextR.TblItem on c.IntItemId equals i.IntItemId
                                                          where c.IntBillOfMaterialId == datas.BomId
                                                          select i.StrItemName).FirstOrDefault();
                            pobomdetail.IntBomitemUnitOfMeasureId = (from c in _contextR.TblBillOfMaterialHeader
                                                                     where c.IntBillOfMaterialId == datas.BomId
                                                                     select c.IntBoMuoMid).FirstOrDefault();
                            pobomdetail.NumBomitemQuantity = (from c in _contextR.TblBillOfMaterialHeader
                                                              where c.IntBillOfMaterialId == datas.BomId
                                                              select c.NumLotSize).FirstOrDefault();
                            pobomdetail.NumBomitemNetWeightKg = (from c in _contextR.TblBillOfMaterialHeader
                                                                 where c.IntBillOfMaterialId == datas.BomId
                                                                 select c.NumLotSize).FirstOrDefault();
                            pobomdetail.IntActionBy = detalis.IntActionBy;
                            pobomdetail.DteLastActionDateTime = DateTime.UtcNow;
                            pobomdetail.IsActive = true;

                            await _contextW.TblPurchaseOrderRowBillOfMaterialDetail.AddAsync(pobomdetail);
                            await _contextW.SaveChangesAsync();
                        }


                        //Purchase Order 
                        long POActivityId = _contextR.TblModuleFeature.FirstOrDefault(a => a.StrFeatureName == "Purchase Order").IntFeatureId;
                        await _approval.CreateApproval(detalis.IntPurchaseOrderId, detalis.IntBusinessUnitId, detalis.IntActionBy, detalis.IntAccountId, POActivityId);
                    }



                    var msg = new MessageHelper();
                    msg.Message = "Purchase Order No :" + detalis.StrPurchaseOrderNo;
                    msg.statuscode = 200;
                    return msg;
                }
                else
                {
                    throw new Exception("Please Add Details!!");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<MessageHelper> CreatePurchaseContact(CreatePurchaseContactCommonDTO objPC)
        {
            try
            {
                if (objPC.objListCPCRowDTO.Count > 0)
                {
                    DataTable PCCode = objCG.getCodeGenerate(objPC.objCPCHeaderDTO.AccountId, objPC.objCPCHeaderDTO.BusinessUnitId, 26);

                    var detalis = new Models.Write.TblPurchaseContractHeader
                    {
                        StrPurchaseContractNo = PCCode.Rows[0][0].ToString(),//objPC.objCPCHeaderDTO.PurchaseContractNo,
                        IntAccountId = objPC.objCPCHeaderDTO.AccountId,
                        IntBusinessUnitId = objPC.objCPCHeaderDTO.BusinessUnitId,
                        IntPlantId = objPC.objCPCHeaderDTO.PlantId,
                        StrPlantName = objPC.objCPCHeaderDTO.PlantName,
                        IntWarehouseId = objPC.objCPCHeaderDTO.WarehouseId,
                        StrWarehouseName = objPC.objCPCHeaderDTO.WarehouseName,
                        IntPurchaseOrganizationId = objPC.objCPCHeaderDTO.PurchaseOrganizationId,
                        DtePurchaseContractDate = objPC.objCPCHeaderDTO.PurchaseContractDate,
                        IntCurrencyId = objPC.objCPCHeaderDTO.CurrencyId,
                        StrCurrencyCode = objPC.objCPCHeaderDTO.CurrencyCode,
                        IntReferenceTypeId = objPC.objCPCHeaderDTO.ReferenceTypeId,
                        IntPaymentTerms = objPC.objCPCHeaderDTO.PaymentTerms,
                        IntCreditPercent = objPC.objCPCHeaderDTO.CreditPercent,
                        IntCashOrAdvancePercent = objPC.objCPCHeaderDTO.CashOrAdvancePercent,
                        IntIncotermsId = objPC.objCPCHeaderDTO.IncotermsId,
                        StrSupplierReference = objPC.objCPCHeaderDTO.SupplierReference,
                        DteReferenceDate = objPC.objCPCHeaderDTO.ReferenceDate,
                        StrItemGroupName = objPC.objCPCHeaderDTO.ItemGroupName,
                        StrContractType = objPC.objCPCHeaderDTO.ContractType,
                        DtePcvalidityDate = objPC.objCPCHeaderDTO.PcvalidityDate,
                        StrOtherTerms = objPC.objCPCHeaderDTO.OtherTerms,
                        IntApproveBy = objPC.objCPCHeaderDTO.ApproveBy,
                        DteApproveDatetime = objPC.objCPCHeaderDTO.ApproveDatetime,
                        DteLastShipmentDate = objPC.objCPCHeaderDTO.LastShipmentDate,
                        IntPaymentDaysAfterDelivery = objPC.objCPCHeaderDTO.PaymentDaysAfterDelivery,
                        StrDeliveryAddress = objPC.objCPCHeaderDTO.DeliveryAddress,
                        IntActionBy = objPC.objCPCHeaderDTO.ActionBy,
                        DteLastActionDateTime = objPC.objCPCHeaderDTO.LastActionDateTime,
                        IntSbuId = objPC.objCPCHeaderDTO.SbuId,
                        IntBusinessPartnerId = objPC.objCPCHeaderDTO.BusinessPartnerId,
                        IntPriceStructureId = 0,
                        IntReferenceId = objPC.objCPCHeaderDTO.ReferenceId,
                        StrReferenceCode = objPC.objCPCHeaderDTO.ReferenceCode,
                        IsApproved = false
                    };

                    var dt = _contextR.TblApprovalConfigHeader.Where(a => a.PredisorActivityId == 19 && a.UnitId == detalis.IntBusinessUnitId && a.IsActive == true).FirstOrDefault();
                    if (dt == null)
                    {
                        detalis.IsApproved = true;
                    }
                    await _contextW.TblPurchaseContractHeader.AddAsync(detalis);
                    await _contextW.SaveChangesAsync();

                    foreach (var datas in objPC.objListCPCRowDTO)
                    {
                        var detalisrow = new Models.Write.TblPurchaseContractRow { };

                        detalisrow.IntPurchaseContractId = detalis.IntPurchaseContractId;
                        detalisrow.IntReferenceId = datas.ReferenceId;
                        detalisrow.StrReferenceCode = datas.ReferenceCode;
                        detalisrow.IntItemId = datas.ItemId;
                        detalisrow.StrItemName = datas.ItemName;
                        detalisrow.IntUoMid = datas.UoMid;
                        detalisrow.StrUoMname = datas.UoMname;
                        detalisrow.StrPurchaseDescription = datas.PurchaseDescription;
                        detalisrow.NumReferenceQty = datas.ReferenceQty;
                        detalisrow.NumContractQty = datas.ContractQty;
                        detalisrow.NumBasePrice = datas.BasePrice;
                        detalisrow.NumFinalPrice = datas.FinalPrice;
                        detalisrow.NumTotalValue = datas.TotalValue;
                        detalisrow.IntActionBy = detalis.IntActionBy;
                        detalisrow.DteLastActionDateTime = DateTime.UtcNow;
                        detalisrow.IsActive = true;
                        detalisrow.DteDeliveryDateTime = datas.DeliveryDateTime;

                        await _contextW.TblPurchaseContractRow.AddAsync(detalisrow);
                        await _contextW.SaveChangesAsync();

                        var mRows = new List<Models.Write.TblPurchaseContractRowPricingDetail>(datas.objListCPCPriceingDetailsDTO.Count);
                        foreach (var v in datas.objListCPCPriceingDetailsDTO)
                        {
                            var detalisrows = new Models.Write.TblPurchaseContractRowPricingDetail { };

                            detalisrows.IntPurchaseContractRowId = detalisrow.IntRowId;
                            detalisrows.IntPriceStructureId = v.PriceStructureId;
                            detalisrows.IntPriceComponentId = v.PriceComponentId;
                            detalisrows.IntBaseComponentId = v.BaseComponentId;
                            detalisrows.StrPriceComponentCode = v.PriceComponentCode;
                            detalisrows.StrPriceComponentName = v.PriceComponentName;
                            detalisrows.IntSequence = v.SerialNo;
                            detalisrows.StrValueType = v.ValueType;
                            detalisrows.NumValue = v.Value;
                            detalisrows.NumAmount = v.Amount;
                            detalisrows.IntSumFromSerial = v.SumFromSerial;
                            detalisrows.IntSumToSerial = v.SumToSerial;
                            detalisrows.IsManual = v.Mannual;
                            detalisrows.IsActive = true;
                            detalisrows.NumFactor = v.Factor;
                            mRows.Add(detalisrows);
                        }

                        await _contextW.TblPurchaseContractRowPricingDetail.AddRangeAsync(mRows);
                        await _contextW.SaveChangesAsync();
                    }


                    //Purchase Order Activity Id 19
                    await _approval.CreateApproval(detalis.IntPurchaseContractId, detalis.IntBusinessUnitId, detalis.IntActionBy, detalis.IntAccountId, 19);

                    var msg = new MessageHelper();
                    msg.Message = "Purchase Contract No:" + detalis.StrPurchaseContractNo;
                    msg.statuscode = 200;
                    return msg;
                }
                else
                {
                    throw new Exception("Please Add Details!!");
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<GetItemDropdownWithPriceStructure>> GetPOReferenceNoWiseItemDDL(long AccountId, long BusinessUnitId, /*long SbuId,*/ long PurchaseOrganizationId, long PlantId, long WearhouseId, long PartnerId, long RefTypeId, long RefNoId)
        {

            List<GetCommonDDLDTO> list = new List<GetCommonDDLDTO>();


            var poList = (from pc in _contextR.TblPurchaseOrderHeader
                          join rt in _contextR.TblPurchaseOrderRow on pc.IntPurchaseOrderId equals rt.IntPurchaseOrderId
                          join i in _contextR.TblItem on rt.IntItemId equals i.IntItemId
                          where rt.IntReferenceId == RefNoId && rt.IsActive == true
                          select new { rt.IntItemId, rt.StrItemName, rt.NumOrderQty, pc.IntPurchaseOrderId })
                                        .GroupBy(s => new { s.IntItemId, s.StrItemName })
                                        .Select(e => new
                                        {
                                            e.Key.IntItemId,
                                            e.Key.StrItemName,

                                            total = e.Sum(d => d.NumOrderQty)
                                        }).ToList();



            if (RefTypeId == 1)// for purchase Contract.
            {
                var ta = (from pc in _contextR.TblPurchaseContractHeader
                          join rt in _contextR.TblPurchaseContractRow on pc.IntPurchaseContractId equals rt.IntPurchaseContractId
                          join i in _contextR.TblItem on rt.IntItemId equals i.IntItemId
                          where rt.IntPurchaseContractId == RefNoId && rt.IsActive == true
                          orderby rt.StrItemName ascending
                          select new
                          {
                              rt.IntItemId,
                              rt.StrItemName,
                              i.StrItemCode,
                              rt.NumContractQty,
                              rt.NumTotalValue,
                              rt.IntUoMid,
                              rt.StrUoMname

                          }).ToList();


                return ta.Select(s => new GetItemDropdownWithPriceStructure
                {
                    Value = s.IntItemId,
                    Label = s.StrItemName,
                    Code = s.StrItemCode,
                    RefQty = s.NumContractQty,
                    RestofQty = s.NumContractQty - (from a in poList where a.IntItemId == s.IntItemId select a.total).Sum(),
                    NetValue = s.NumTotalValue,
                    UoMId = s.IntUoMid,
                    UoMName = s.StrUoMname,
                    PriceStructure = (from ps in _contextR.TblPriceStructureHeader
                                      join psr in _contextR.TblPriceStructureRow on ps.IntPriceStructureId equals psr.IntPriceStructureId
                                      join pc in _contextR.TblPriceComponent on psr.IntPriceComponentId equals pc.IntPriceComponentId
                                      join bp in _contextR.TblBusinessPartnerPurchase on ps.IntPriceStructureId equals bp.IntPriceStructureId
                                      where
                                        bp.IntBusinessPartnerId == PartnerId && bp.IntAccountId == AccountId && bp.IntBusinessUnitId == BusinessUnitId
                                      select new GetPriceStructureByPartnerDTO
                                      {
                                          PriceStructureId = ps.IntPriceStructureId,
                                          PriceStructureName = ps.StrPriceStructureName,
                                          PriceComponentId = psr.IntPriceComponentId,
                                          PriceComponentCode = pc.StrPriceComponentCode,
                                          PriceComponentName = pc.StrPriceComponentName,
                                          ValueType = psr.StrValueType,
                                          Value = psr.NumValue,
                                          BaseComponentId = psr.IntBaseComponentId,
                                          SerialNo = psr.IntSerialNo,
                                          SumFromSerial = psr.IntSumFromSerial,
                                          SumToSerial = psr.IntSumToSerial,
                                          Mannual = psr.IsMannual,
                                          Factor = pc.NumFactor
                                      }).ToList()

                }).ToList();

                //var data = await Task.FromResult((from pc in _contextR.TblPurchaseContractHeader
                //                                  join rt in _contextR.TblPurchaseContractRow on pc.IntPurchaseContractId equals rt.IntPurchaseContractId
                //                                  join i in _contextR.TblItem on rt.IntItemId equals i.IntItemId
                //                                  where rt.IntPurchaseContractId == RefNoId && pc.IntAccountId == AccountId && pc.IntBusinessUnitId == BusinessUnitId && rt.IsActive == true
                //                                  && pc.IntPlantId == PlantId && pc.IntWarehouseId == WearhouseId && pc.IntBusinessPartnerId == PartnerId
                //                                  orderby rt.IntItemId ascending
                //                                  select new GetCommonDDLDTO
                //                                  {
                //                                      Value = rt.IntItemId,
                //                                      Label = rt.StrItemName,
                //                                      Code = i.StrItemCode,
                //                                      RefQty = rt.NumContractQty,
                //                                      RestofQty = rt.NumContractQty-(from a in poList where a.IntItemId == rt.IntItemId select a.total).FirstOrDefault() ,
                //                                      NetValue = rt.NumTotalValue,
                //                                      UoMId = rt.IntUoMid,
                //                                      UoMName = rt.StrUoMname

                //                                  }).ToList()) ;
                //(from pr in _contextR.TblPurchaseRequestRow
                // where pr.IntPurchaseRequestId == pc.IntReferenceId && pc.IsActive == true
                // select pr.NumRequestQuantity).FirstOrDefault() - rt.NumReferenceQty,
                //  list = data.ToList();

            }
            else if (RefTypeId == 2)// for purchase Request.
            {
                var dr = _contextR.TblPurchaseRequestRow.Where(c => c.IntPurchaseRequestId == RefNoId && c.IsActive == true).Select(e => new
                {
                    e.IntItemId,
                    e.StrItemName,
                    e.StrItemCode,//StrPurchaseRequestCode,
                    e.NumRequestQuantity,
                    e.IntUoMid,
                    e.StrUoMname

                }).ToList();

                return dr.Select(e => new GetItemDropdownWithPriceStructure
                {
                    Value = e.IntItemId,
                    Label = e.StrItemName,
                    Code = e.StrItemCode,//StrPurchaseRequestCode,
                    RefQty = e.NumRequestQuantity,
                    RestofQty = e.NumRequestQuantity - (from a in poList where a.IntItemId == e.IntItemId select a.total).FirstOrDefault(),
                    UoMId = e.IntUoMid,
                    UoMName = e.StrUoMname,
                    PriceStructure = (from ps in _contextR.TblPriceStructureHeader
                                      join psr in _contextR.TblPriceStructureRow on ps.IntPriceStructureId equals psr.IntPriceStructureId
                                      join pc in _contextR.TblPriceComponent on psr.IntPriceComponentId equals pc.IntPriceComponentId
                                      join bp in _contextR.TblBusinessPartnerPurchase on ps.IntPriceStructureId equals bp.IntPriceStructureId
                                      where
                                        bp.IntBusinessPartnerId == PartnerId && bp.IntAccountId == AccountId && bp.IntBusinessUnitId == BusinessUnitId && ps.IsActive == true
                                      select new GetPriceStructureByPartnerDTO
                                      {
                                          RowId = psr.IntRowId,
                                          PriceStructureId = ps.IntPriceStructureId,
                                          PriceStructureName = ps.StrPriceStructureName,
                                          PriceComponentId = psr.IntPriceComponentId,
                                          PriceComponentCode = pc.StrPriceComponentCode,
                                          PriceComponentName = pc.StrPriceComponentName,
                                          ValueType = psr.StrValueType,
                                          Value = psr.NumValue,
                                          BaseComponentId = psr.IntBaseComponentId,
                                          SerialNo = psr.IntSerialNo,
                                          SumFromSerial = psr.IntSumFromSerial,
                                          SumToSerial = psr.IntSumToSerial,
                                          Mannual = psr.IsMannual,
                                          Factor = pc.NumFactor
                                      }).ToList()

                }).ToList();


            }
            else if (RefTypeId == 3)// for without purchase reference.
            {
                var data = (from rt in _contextR.TblItemPurchase
                            join ipw in _contextR.TblItemPlantWarehouse on rt.IntItemId equals ipw.IntItemId
                            join i in _contextR.TblItem on rt.IntItemId equals i.IntItemId
                            where rt.IntAccountId == AccountId && rt.IntBusinessUnitId == BusinessUnitId
                            && ipw.IntPlantId == PlantId && ipw.IntWarehouseId == WearhouseId
                            orderby ipw.StrItemName ascending
                            select new
                            {
                                ItemId = i.IntItemId,
                                ItemName = i.StrItemName,
                                ItemCode = i.StrItemCode,
                                UoMId = ipw.IntBaseUomid,
                                UoMName = ipw.StrBaseUom,

                            }).GroupBy(y => new
                            {
                                y.ItemId,
                                y.ItemName,
                                y.ItemCode,
                                y.UoMId,
                                y.UoMName
                            }).Select(x => new GetItemDropdownWithPriceStructure
                            {
                                Value = x.Key.ItemId,
                                Label = x.Key.ItemName,
                                Code = x.Key.ItemCode,
                                UoMId = x.Key.UoMId,
                                UoMName = x.Key.UoMName
                            });

                return data.Select(s => new GetItemDropdownWithPriceStructure
                {
                    Value = s.Value,
                    Label = s.Label,
                    Code = s.Code,
                    UoMId = s.UoMId,
                    UoMName = s.UoMName,

                    PriceStructure = (from ps in _contextR.TblPriceStructureHeader
                                      join psr in _contextR.TblPriceStructureRow on ps.IntPriceStructureId equals psr.IntPriceStructureId
                                      join pc in _contextR.TblPriceComponent on psr.IntPriceComponentId equals pc.IntPriceComponentId
                                      join bp in _contextR.TblBusinessPartnerPurchase on ps.IntPriceStructureId equals bp.IntPriceStructureId
                                      where
                                        bp.IntBusinessPartnerId == PartnerId && bp.IntAccountId == AccountId && bp.IntBusinessUnitId == BusinessUnitId
                                      select new GetPriceStructureByPartnerDTO
                                      {
                                          PriceStructureId = ps.IntPriceStructureId,
                                          PriceStructureName = ps.StrPriceStructureName,
                                          PriceComponentId = psr.IntPriceComponentId,
                                          PriceComponentCode = pc.StrPriceComponentCode,
                                          PriceComponentName = pc.StrPriceComponentName,
                                          ValueType = psr.StrValueType,
                                          Value = psr.NumValue,
                                          BaseComponentId = psr.IntBaseComponentId,
                                          SerialNo = psr.IntSerialNo,
                                          SumFromSerial = psr.IntSumFromSerial,
                                          SumToSerial = psr.IntSumToSerial,
                                          Mannual = psr.IsMannual,
                                          Factor = pc.NumFactor
                                      }).ToList()

                }).ToList();

            }
            else if (RefTypeId == 4)// for PO reference return po.
            {

                var data = (from rt in _contextR.TblPurchaseOrderRow
                            where rt.IsActive == true && rt.IntPurchaseOrderId == RefNoId
                            orderby rt.IntItemId ascending
                            select new
                            {
                                rt.IntItemId,
                                rt.StrItemName,
                                rt.StrReferenceCode,
                                rt.NumOrderQty,
                                rt.IntUoMid,
                                rt.StrUoMname,
                                rt.NumTotalValue

                            }).ToList();

                return data.Select(s => new GetItemDropdownWithPriceStructure
                {
                    Value = s.IntItemId,
                    Label = s.StrItemName,
                    RefQty = s.NumOrderQty,
                    RestofQty = s.NumOrderQty - (from a in poList where a.IntItemId == s.IntItemId select a.total).FirstOrDefault(),
                    NetValue = s.NumTotalValue,
                    UoMId = s.IntUoMid,
                    UoMName = s.StrUoMname,
                    PriceStructure = (from ps in _contextR.TblPriceStructureHeader
                                      join psr in _contextR.TblPriceStructureRow on ps.IntPriceStructureId equals psr.IntPriceStructureId
                                      join pc in _contextR.TblPriceComponent on psr.IntPriceComponentId equals pc.IntPriceComponentId
                                      join bp in _contextR.TblBusinessPartnerPurchase on ps.IntPriceStructureId equals bp.IntPriceStructureId
                                      where
                                        bp.IntBusinessPartnerId == PartnerId && bp.IntAccountId == AccountId && bp.IntBusinessUnitId == BusinessUnitId
                                      select new GetPriceStructureByPartnerDTO
                                      {
                                          PriceStructureId = ps.IntPriceStructureId,
                                          PriceStructureName = ps.StrPriceStructureName,
                                          PriceComponentId = psr.IntPriceComponentId,
                                          PriceComponentCode = pc.StrPriceComponentCode,
                                          PriceComponentName = pc.StrPriceComponentName,
                                          ValueType = psr.StrValueType,
                                          Value = psr.NumValue,
                                          BaseComponentId = psr.IntBaseComponentId,
                                          SerialNo = psr.IntSerialNo,
                                          SumFromSerial = psr.IntSumFromSerial,
                                          SumToSerial = psr.IntSumToSerial,
                                          Mannual = psr.IsMannual,
                                          Factor = pc.NumFactor
                                      }).ToList()

                }).ToList();


            }
            else
            {
                throw new Exception("Data not found");
            }

        }
        public async Task<List<getWHAddressDTO>> getWHAddressbyWHId(long WhId)
        {
            //throw new NotImplementedException();
            var data = await Task.FromResult((from wh in _contextR.TblWarehouse
                                              where wh.IntWarehouseId == WhId
                                              select new getWHAddressDTO
                                              {
                                                  Value = wh.IntWarehouseId,
                                                  Label = wh.StrWarehouseName,
                                                  whAddress = wh.StrWarehouseName + "," + wh.StrWarehouseAddress

                                              }).ToList());

            return data;
        }
        public async Task<List<GetIncotermDDLDTO>> GetIncotermListDDL()
        {
            // throw new NotImplementedException();
            var data = await Task.FromResult((from inc in _contextR.TblIncoTerms
                                              where inc.IsActive == true
                                              orderby inc.StrIncotermsName ascending
                                              select new GetIncotermDDLDTO
                                              {
                                                  Value = inc.IntIncotermsId,
                                                  Label = inc.StrIncotermsName

                                              }).ToList());

            return data;
        }
        public async Task<List<GetPaymentTermsDDLDTO>> GetPaymentTermsListDDL()
        {
            // throw new NotImplementedException();
            var data = await Task.FromResult((from pt in _contextR.TblPaymentTermsFino
                                              orderby pt.StrPaymentTermsName ascending
                                              select new GetPaymentTermsDDLDTO
                                              {
                                                  Value = pt.IntPaymentTerms,
                                                  Label = pt.StrPaymentTermsName

                                              }).ToList());

            return data;
        }
        public async Task<List<GetPlantDDLDTO>> GetPlantDDLFromPOH(long AccountId, long BusinessUnitId)
        {
            //throw new NotImplementedException();
            var data = await Task.FromResult((from pt in _contextR.TblItemPlantWarehouse
                                              join p in _contextR.TblPlant on pt.IntPlantId equals p.IntPlantId
                                              where pt.IntAccountId == AccountId && pt.IntBusinessUnitId == BusinessUnitId
                                              orderby pt.StrPlantName ascending
                                              select new GetPlantDDLDTO
                                              {
                                                  Value = pt.IntPlantId,
                                                  Label = p.StrPlantName

                                              }).GroupBy(y => new { y.Value, y.Label })
                                              .Select(x => new GetPlantDDLDTO
                                              {
                                                  Value = x.Key.Value,
                                                  Label = x.Key.Label
                                              }).ToList());

            return data;
        }
        public async Task<List<GetWearHouseDDLDTO>> GetWearHouseDDLFromPOH(long AccountId, long BusinessUnitId, long plantId)
        {
            //throw new NotImplementedException();
            var data = await Task.FromResult((from pt in _contextR.TblItemPlantWarehouse
                                              where pt.IntAccountId == AccountId && pt.IntBusinessUnitId == BusinessUnitId
                                              && pt.IntPlantId == plantId
                                              orderby pt.StrWareHouseName ascending
                                              select new GetWearHouseDDLDTO
                                              {
                                                  Value = pt.IntWarehouseId,
                                                  Label = pt.StrWareHouseName

                                              }).Distinct().ToList());

            return data;
        }
        public async Task<List<GetOrderTypeDDLDTO>> GetOrderTypeDDLFromPOH(long AccountId, long BusinessUnitId, long plantId, long WearhousId)
        {
            //throw new NotImplementedException();
            var data = await Task.FromResult((from pt in _contextR.TblPurchaseOrderHeader
                                              join ot in _contextR.TblPurchaseOrderType on pt.IntPurchaseOrderTypeId equals ot.IntPurchaseOrderTypeId
                                              where pt.IntAccountId == AccountId && pt.IntBusinessUnitId == BusinessUnitId
                                              && pt.IntPlantId == plantId && pt.IntWarehouseId == WearhousId
                                              orderby ot.StrPurchaseOrderTypeName ascending
                                              select new GetOrderTypeDDLDTO
                                              {
                                                  Value = pt.IntPurchaseOrderTypeId,
                                                  Label = ot.StrPurchaseOrderTypeName

                                              }).ToList());

            return data;
        }
        public async Task<purchaseOrderPasignation> GetPurchaseOrderInformationPasignation(long AccountId, long UnitId, long Sbu, long Plant, long WearHouse, long PurchaseOrderTypeId, long PurchaseOrganizationId, long ReferenceTypeId, bool isApproved, string viewOrder, long PageNo, long PageSize)
        {
            //throw new NotImplementedException();

            if (PurchaseOrderTypeId == 2)//for purchase contact type
            {
                IQueryable<GetPurchaseOrderHeaderDTO> data = (from prh in _contextR.TblPurchaseContractHeader
                                                              join porg in _contextR.TblBusinessUnitPurchaseOrganization on prh.IntPurchaseOrganizationId equals porg.IntPurchaseOrganizationid
                                                              where prh.IntAccountId == AccountId && prh.IntBusinessUnitId == UnitId
                                                              && prh.IntPlantId == Plant /*&& prh.sbuid == Sbu*/ && prh.IntWarehouseId == WearHouse
                                                              && prh.IntPurchaseOrganizationId == PurchaseOrganizationId
                                                              && prh.IntReferenceTypeId == ReferenceTypeId
                                                              && prh.IsActive == true
                                                              //&& prh.IntAccountId == prh.IntAccountId && prh.IntBusinessUnitId == prh.IntBusinessUnitId
                                                              && prh.IntAccountId == porg.IntAccountId && prh.IntBusinessUnitId == porg.IntBusinessUnitId
                                                              select new GetPurchaseOrderHeaderDTO
                                                              {
                                                                  PurchaseOrderId = prh.IntPurchaseContractId,
                                                                  PurchaseOrderNo = prh.StrPurchaseContractNo,
                                                                  PurchaseOrderDate = prh.DtePurchaseContractDate,
                                                                  DeliveryAddress = prh.StrDeliveryAddress,
                                                                  CurrencyId = prh.IntCurrencyId,
                                                                  CurrencyName = (from t in _contextR.TblCurrency
                                                                                  where t.IntCurrencyId == prh.IntCurrencyId
                                                                                  select t.StrCurrencyName).FirstOrDefault(),
                                                                  PaymentTerms = (long)prh.IntPaymentTerms,
                                                                  PaymentTermsName = (from t in _contextR.TblPaymentTermsFino
                                                                                      where t.IntPaymentTerms == prh.IntPaymentTerms
                                                                                      select t.StrPaymentTermsName).FirstOrDefault(),
                                                                  ValidityDate = (DateTime)prh.DtePcvalidityDate,
                                                                  PurchaseOrganizationId = prh.IntPurchaseOrganizationId,
                                                                  PurchaseOrganizationName = porg.StrPurchaseOrganization,
                                                                  SupplierId = prh.IntBusinessPartnerId,
                                                                  SupplierName = (prh.IntBusinessPartnerId == 0) ? "" : (from i in _contextR.TblBusinessPartner
                                                                                                                         where i.IntBusinessPartnerId == prh.IntBusinessPartnerId
                                                                                                                         select i.StrBusinessPartnerName).FirstOrDefault(),
                                                                  SupplierAddress = (prh.IntBusinessPartnerId == 0) ? "" : (from i in _contextR.TblBusinessPartner
                                                                                                                            where i.IntBusinessPartnerId == prh.IntBusinessPartnerId
                                                                                                                            select i.StrBusinessPartnerAddress).FirstOrDefault(),
                                                                  NumberOfShipments = 0,
                                                              });

                var countQ = data.Count();

                if (data == null)
                    throw new Exception("Purchase Request Header Not Exist in Database");
                else
                {
                    if (viewOrder.ToUpper() == "ASC")
                        data = data.OrderBy(o => o.PurchaseOrderId);
                    else if (viewOrder.ToUpper() == "DESC")
                        data = data.OrderByDescending(o => o.PurchaseOrderId);
                }

                if (PageNo <= 0)
                    PageNo = 1;
                var itemdata = PagingList<GetPurchaseOrderHeaderDTO>.CreateAsync(data, PageNo, PageSize);

                int index = 1;
                foreach (var itms in itemdata)
                {
                    itms.Sl = index++;
                }
                purchaseOrderPasignation itm = new purchaseOrderPasignation();
                itm.Data = itemdata;
                itm.currentPage = PageNo;
                itm.totalCount = countQ;
                itm.pageSize = PageSize;

                return itm;
            }
            else
            {
                IQueryable<GetPurchaseOrderHeaderDTO> data = (from prh in _contextR.TblPurchaseOrderHeader
                                                              join porg in _contextR.TblBusinessUnitPurchaseOrganization on prh.IntPurchaseOrganizationId equals porg.IntPurchaseOrganizationid
                                                              where prh.IntAccountId == AccountId && prh.IntBusinessUnitId == UnitId
                                                              && prh.IntPlantId == Plant && prh.IntSbuid == Sbu && prh.IntWarehouseId == WearHouse
                                                              && prh.IntPurchaseOrderTypeId == PurchaseOrderTypeId && prh.IntPurchaseOrganizationId == PurchaseOrganizationId
                                                              && prh.IntReferenceTypeId == ReferenceTypeId
                                                              && prh.IsActive == true /*&& prh.IsApproved == isApproved*/
                                                              //&& prh.IntAccountId == prh.IntAccountId && prh.IntBusinessUnitId == prh.IntBusinessUnitId
                                                              && prh.IntAccountId == porg.IntAccountId && prh.IntBusinessUnitId == porg.IntBusinessUnitId

                                                              select new GetPurchaseOrderHeaderDTO
                                                              {
                                                                  PurchaseOrderId = prh.IntPurchaseOrderId,
                                                                  PurchaseOrderNo = prh.StrPurchaseOrderNo,
                                                                  PurchaseOrderDate = prh.DtePurchaseOrderDate,
                                                                  DeliveryAddress = prh.StrDeliveryAddress,
                                                                  CurrencyId = prh.IntCurrencyId,
                                                                  CurrencyName = (from t in _contextR.TblCurrency
                                                                                  where t.IntCurrencyId == prh.IntCurrencyId
                                                                                  select t.StrCurrencyName).FirstOrDefault(),
                                                                  PaymentTerms = prh.IntPaymentTerms,
                                                                  PaymentTermsName = (from t in _contextR.TblPaymentTermsFino
                                                                                      where t.IntPaymentTerms == prh.IntPaymentTerms
                                                                                      select t.StrPaymentTermsName).FirstOrDefault(),
                                                                  ValidityDate = prh.DtePovalidityDate,
                                                                  PurchaseOrganizationId = prh.IntPurchaseOrganizationId,
                                                                  PurchaseOrganizationName = porg.StrPurchaseOrganization,
                                                                  SupplierId = prh.IntBusinessPartnerId,
                                                                  SupplierName = (prh.IntBusinessPartnerId == 0) ? "" : (from i in _contextR.TblBusinessPartner
                                                                                                                         where i.IntBusinessPartnerId == prh.IntBusinessPartnerId
                                                                                                                         select i.StrBusinessPartnerName).FirstOrDefault(),
                                                                  SupplierAddress = (prh.IntBusinessPartnerId == 0) ? "" : (from i in _contextR.TblBusinessPartner
                                                                                                                            where i.IntBusinessPartnerId == prh.IntBusinessPartnerId
                                                                                                                            select i.StrBusinessPartnerAddress).FirstOrDefault(),
                                                                  NumberOfShipments = 0,
                                                                  IsApprove = prh.IsApproved

                                                              });

                var countQ = data.Count();

                if (data == null)
                    throw new Exception("Purchase Request Header Not Exist in Database");
                else
                {
                    if (viewOrder.ToUpper() == "ASC")
                        data = data.OrderBy(o => o.PurchaseOrderId);
                    else if (viewOrder.ToUpper() == "DESC")
                        data = data.OrderByDescending(o => o.PurchaseOrderId);
                }

                if (PageNo <= 0)
                    PageNo = 1;
                var itemdata = PagingList<GetPurchaseOrderHeaderDTO>.CreateAsync(data, PageNo, PageSize);

                int index = 1;
                foreach (var itms in itemdata)
                {
                    itms.Sl = index++;
                }
                purchaseOrderPasignation itm = new purchaseOrderPasignation();
                itm.Data = itemdata;
                itm.currentPage = PageNo;
                itm.totalCount = countQ;
                itm.pageSize = PageSize;

                return itm;
            }

        }
        public async Task<List<GetPurchaseOrderCommonDTObyId>> GetPurchaseOrderInformationByPO_Id(long PurchaseOrderId)
        {
            //throw new NotImplementedException();
            try
            {
                GetPurchaseOrderHeaderByIdDTO header = await Task.FromResult((from prh in _contextR.TblPurchaseOrderHeader
                                                                              join porg in _contextR.TblBusinessUnitPurchaseOrganization on prh.IntPurchaseOrganizationId equals porg.IntPurchaseOrganizationid
                                                                              join potype in _contextR.TblPurchaseOrderType on prh.IntPurchaseOrderTypeId equals potype.IntPurchaseOrderTypeId
                                                                              join rtype in _contextR.TblPoreferenceType on prh.IntReferenceTypeId equals rtype.IntPoreferenceTypeId
                                                                              join ba in _contextR.TblBusinessArea on prh.IntSbuid equals ba.IntSbuid
                                                                              where prh.IsActive == true && prh.IntPurchaseOrderId == PurchaseOrderId
                                                                              select new GetPurchaseOrderHeaderByIdDTO
                                                                              {
                                                                                  PurchaseOrderId = prh.IntPurchaseOrderId,
                                                                                  PurchaseOrderNo = prh.StrPurchaseOrderNo,
                                                                                  AccountId = prh.IntAccountId,
                                                                                  BusinessUnitId = prh.IntBusinessUnitId,
                                                                                  PurchaseOrganizationId = prh.IntPurchaseOrganizationId,
                                                                                  PurchaseOrganizationName = porg.StrPurchaseOrganization,
                                                                                  PlantId = prh.IntPlantId,
                                                                                  PlantName = prh.StrPlantName,
                                                                                  WarehouseId = prh.IntWarehouseId,
                                                                                  WarehouseName = prh.StrWarehouseName,
                                                                                  SupplyingWarehouseId = prh.IntSupplyingWarehouseId,
                                                                                  SupplyingWarehouseName = prh.StrSupplyingWarehouseName,
                                                                                  DeliveryAddress = prh.StrDeliveryAddress,
                                                                                  BusinessPartnerId = prh.IntBusinessPartnerId,
                                                                                  SupplierName = (prh.IntBusinessPartnerId == 0) ? "" : (from i in _contextR.TblBusinessPartner
                                                                                                                                         where i.IntBusinessPartnerId == prh.IntBusinessPartnerId
                                                                                                                                         select i.StrBusinessPartnerName).FirstOrDefault(),
                                                                                  SupplierAddress = (prh.IntBusinessPartnerId == 0) ? "" : (from i in _contextR.TblBusinessPartner
                                                                                                                                            where i.IntBusinessPartnerId == prh.IntBusinessPartnerId
                                                                                                                                            select i.StrBusinessPartnerAddress).FirstOrDefault(),
                                                                                  PurchaseOrderDate = prh.DtePurchaseOrderDate,
                                                                                  PurchaseOrderTypeId = prh.IntPurchaseOrderTypeId,
                                                                                  PurchaseOrderTypeName = potype.StrPurchaseOrderTypeName,
                                                                                  IncotermsId = prh.IntIncotermsId,
                                                                                  IncotermsName = (prh.IntIncotermsId == 0) ? "" : (from t in _contextR.TblIncoTerms
                                                                                                                                    where t.IntIncotermsId == prh.IntIncotermsId
                                                                                                                                    select t.StrIncotermsName).FirstOrDefault(),
                                                                                  CurrencyId = prh.IntCurrencyId,
                                                                                  CurrencyCode = prh.StrCurrencyCode,
                                                                                  SupplierReference = prh.StrSupplierReference,
                                                                                  ReferenceDate = prh.DteReferenceDate,
                                                                                  ReferenceTypeId = prh.IntReferenceTypeId,
                                                                                  ReferenceTypeName = rtype.StrPoreferenceType,
                                                                                  PaymentTerms = prh.IntPaymentTerms,
                                                                                  PaymentTermsName = (prh.IntPaymentTerms == 0) ? "" : (from t in _contextR.TblPaymentTermsFino
                                                                                                                                        where t.IntPaymentTerms == prh.IntPaymentTerms
                                                                                                                                        select t.StrPaymentTermsName).FirstOrDefault(),
                                                                                  CreditPercent = prh.IntCreditPercent,
                                                                                  CashOrAdvancePercent = prh.IntCashOrAdvancePercent,
                                                                                  OtherTerms = prh.StrOtherTerms,
                                                                                  YsnPartialShipment = true,
                                                                                  NumberOfShipments = 0,
                                                                                  LastShipmentDate = prh.DteLastShipmentDate,
                                                                                  ValidityDate = prh.DtePovalidityDate,
                                                                                  PaymentDaysAfterDelivery = prh.IntPaymentDaysAfterDelivery,
                                                                                  ActionBy = prh.IntActionBy,
                                                                                  SBUId = prh.IntSbuid,
                                                                                  SBUName = ba.StrSbuname,
                                                                                  ReturnDate = prh.DteReturnDateTime

                                                                              }).FirstOrDefault());

                List<GetPurchaseOrderRowDTO> row = await Task.FromResult((from t in _contextR.TblPurchaseOrderRow
                                                                          where t.IntPurchaseOrderId == PurchaseOrderId && t.IsActive == true
                                                                          select new GetPurchaseOrderRowDTO
                                                                          {
                                                                              RowId = t.IntRowId,
                                                                              PurchaseOrderId = t.IntPurchaseOrderId,
                                                                              ReferenceId = t.IntReferenceId,
                                                                              ReferenceCode = t.StrReferenceCode,
                                                                              ReferenceQty = t.NumReferenceQty,
                                                                              OrderQty = t.NumOrderQty,
                                                                              BasePrice = t.NumBasePrice,
                                                                              FinalPrice = t.NumFinalPrice,
                                                                              TotalValue = t.NumTotalValue,
                                                                              PurchaseDescription = t.StrPurchaseDescription,
                                                                              ItemId = t.IntItemId,
                                                                              ItemName = t.StrItemName,
                                                                              UomId = t.IntUoMid,
                                                                              UomName = t.StrUoMname,
                                                                              //NetValue 
                                                                              RestofQty = (from pr in _contextR.TblPurchaseRequestRow
                                                                                           where pr.IntPurchaseRequestId == t.IntReferenceId && t.IsActive == true && pr.IntItemId == t.IntItemId
                                                                                           select pr.NumRequestQuantity).Sum() - t.NumReferenceQty,
                                                                              ItemCode = (from c in _contextR.TblItem
                                                                                          where c.IntItemId == t.IntItemId && c.IsActive == true
                                                                                          select c.StrItemCode).FirstOrDefault(),
                                                                              PriceStructure = (from a in _contextR.TblPurchaseOrderRowPricingDetail
                                                                                                where a.IntPurchaseOrderRowId == t.IntRowId
                                                                                                orderby a.IntSequence ascending
                                                                                                select new GetPriceStructureByPartnerDTO
                                                                                                {
                                                                                                    PriceStructureId = (long)a.IntPriceStructureId,
                                                                                                    PriceStructureName = "",
                                                                                                    PriceComponentId = (long)a.IntPriceComponentId,
                                                                                                    PriceComponentCode = a.StrPriceComponentCode,
                                                                                                    PriceComponentName = a.StrPriceComponentName,
                                                                                                    ValueType = a.StrValueType,
                                                                                                    Value = (decimal)a.NumValue,
                                                                                                    Amount = (decimal)a.NumAmount,
                                                                                                    BaseComponentId = a.IntBaseComponentId,
                                                                                                    SerialNo = (long)a.IntSequence,
                                                                                                    SumFromSerial = (long)a.IntSumFromSerial,
                                                                                                    SumToSerial = (long)a.IntSumToSerial,
                                                                                                    Factor = (decimal)a.NumFactor,
                                                                                                    RowId = (long)a.IntRowId,
                                                                                                    Mannual = a.IsManual
                                                                                                }).ToList()
                                                                          }).ToList());

                List<GetPurchaseOrderCommonDTObyId> objListData = new List<GetPurchaseOrderCommonDTObyId>();
                GetPurchaseOrderCommonDTObyId objData = new GetPurchaseOrderCommonDTObyId()
                {
                    objHeaderDTO = header,
                    objRowListDTO = row
                };


                if (objData == null)
                    throw new Exception("Purchase Request Information Not Exist in Database");
                else
                    objListData.Add(objData);

                return objListData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<ReferanceNoDTO>> getReferanceNoByPR(long AccountId, long UnitId, long referenceTypeId)
        {
            //throw new NotImplementedException();
            try
            {
                if (referenceTypeId == 1)
                {
                    var data = await Task.FromResult((from prh in _contextR.TblPurchaseContractHeader
                                                      where prh.IntAccountId == AccountId && prh.IntBusinessUnitId == UnitId
                                                      select new ReferanceNoDTO
                                                      {
                                                          Value = prh.IntPurchaseContractId,
                                                          Label = prh.StrPurchaseContractNo

                                                      }).GroupBy(y => new { y.Value, y.Label })
                        .Select(x => new ReferanceNoDTO
                        {
                            Value = x.Key.Value,
                            Label = x.Key.Label
                        }).ToList());

                    return data;
                }
                else if (referenceTypeId == 2)
                {
                    var data = await Task.FromResult((from prh in _contextR.TblPurchaseRequestPending
                                                      where prh.IntAccountId == AccountId && prh.IntBusinessUnitId == UnitId
                                                      select new ReferanceNoDTO
                                                      {
                                                          Value = prh.IntPurchaseRequestId,
                                                          Label = prh.StrPurchaseRequestCode

                                                      }).GroupBy(y => new { y.Value, y.Label })
                        .Select(x => new ReferanceNoDTO
                        {
                            Value = x.Key.Value,
                            Label = x.Key.Label
                        }).ToList());

                    return data;
                }
                else
                {
                    var data = await Task.FromResult((from prh in _contextR.TblPurchaseOrderHeader
                                                      where prh.IntAccountId == AccountId && prh.IntBusinessUnitId == UnitId
                                                      select new ReferanceNoDTO
                                                      {
                                                          Value = prh.IntPurchaseOrderId,
                                                          Label = prh.StrPurchaseOrderNo

                                                      }).GroupBy(y => new { y.Value, y.Label })
                        .Select(x => new ReferanceNoDTO
                        {
                            Value = x.Key.Value,
                            Label = x.Key.Label
                        }).ToList());

                    return data;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<PurchaseRequestItemDTO>> getPRItemList(long RequestId, long ReferanceTypeId)
        {
            //throw new NotImplementedException();
            if (ReferanceTypeId == 1)
            {
                var data = await Task.FromResult((from pt in _contextR.TblPurchaseContractRow
                                                  join i in _contextR.TblItemPurchase
                                                     on pt.IntItemId equals i.IntItemId
                                                  where pt.IntPurchaseContractId == RequestId
                                                  orderby pt.StrItemName ascending
                                                  select new PurchaseRequestItemDTO
                                                  {
                                                      Value = pt.IntItemId,
                                                      Label = pt.StrItemName,
                                                      Description = i.StrPurchaseDescription,
                                                      RestofQty = 0,
                                                      refQty = pt.NumReferenceQty,
                                                      UOM = pt.IntUoMid,
                                                      UOMName = pt.StrUoMname
                                                  }).ToList());

                return data;
            }
            else if (ReferanceTypeId == 2)
            {
                var data = await Task.FromResult((from pt in _contextR.TblPurchaseRequestPending
                                                  join i in _contextR.TblItemPurchase
                                                     on pt.IntItemId equals i.IntItemId
                                                  where pt.IntPurchaseRequestId == RequestId
                                                  orderby pt.StrItemName ascending
                                                  select new PurchaseRequestItemDTO
                                                  {
                                                      Value = pt.IntItemId,
                                                      Label = pt.StrItemName,
                                                      Description = i.StrPurchaseDescription,
                                                      RestofQty = pt.NumPendingQuantity,
                                                      refQty = pt.NumApprovedQuantity,
                                                      UOM = pt.IntUoMid,
                                                      UOMName = pt.StrUoMname
                                                  }).ToList());

                return data;
            }
            else
            {
                var data = await Task.FromResult((from pt in _contextR.TblPurchaseOrderRow
                                                  join i in _contextR.TblItemPurchase
                                                     on pt.IntItemId equals i.IntItemId
                                                  where pt.IntPurchaseOrderId == RequestId
                                                  orderby pt.StrItemName ascending
                                                  select new PurchaseRequestItemDTO
                                                  {
                                                      Value = pt.IntItemId,
                                                      Label = pt.StrItemName,
                                                      Description = i.StrPurchaseDescription,
                                                      RestofQty = pt.NumOrderQty,
                                                      refQty = pt.NumReferenceQty,
                                                      UOM = pt.IntUoMid,
                                                      UOMName = pt.StrUoMname
                                                  }).ToList());

                return data;
            }
        }
        public async Task<List<PurchaseRequestItemDTO>> getPRItemByItemId(long RequestId, long ReferanceTypeId, long ItemId)
        {
            if (ReferanceTypeId == 1)
            {
                var data = await Task.FromResult((from pt in _contextR.TblPurchaseContractRow
                                                  join i in _contextR.TblItemPurchase on pt.IntItemId equals i.IntItemId
                                                  where pt.IntPurchaseContractId == RequestId && pt.IntItemId == ItemId
                                                  orderby pt.StrItemName ascending
                                                  select new PurchaseRequestItemDTO
                                                  {
                                                      Value = pt.IntItemId,
                                                      Label = pt.StrItemName,
                                                      Description = i.StrPurchaseDescription,
                                                      RestofQty = 0,
                                                      refQty = pt.NumReferenceQty,
                                                      UOM = pt.IntUoMid,
                                                      UOMName = pt.StrUoMname
                                                  }).ToList());


                //foreach (var RequestDTO in data)
                //{
                //    var qty = _contextR.TblPurchaseOrderRow.Where(x => x.IntReferenceId == RequestId && x.IntItemId == RequestDTO.Value).Select(x => x.NumReferenceQty).Sum();
                //    RequestDTO.RestofQty = RequestDTO.refQty - qty;
                //}

                return data;
            }
            else if (ReferanceTypeId == 2)
            {
                var data = await Task.FromResult((from pt in _contextR.TblPurchaseRequestPending
                                                  join i in _contextR.TblItemPurchase on pt.IntItemId equals i.IntItemId
                                                  where pt.IntPurchaseRequestId == RequestId && pt.IntItemId == ItemId
                                                  orderby pt.StrItemName ascending
                                                  select new PurchaseRequestItemDTO
                                                  {
                                                      Value = pt.IntItemId,
                                                      Label = pt.StrItemName,
                                                      Description = i.StrPurchaseDescription,
                                                      RestofQty = pt.NumPendingQuantity,
                                                      refQty = pt.NumApprovedQuantity,
                                                      UOM = pt.IntUoMid,
                                                      UOMName = pt.StrUoMname
                                                  }).ToList());
                //foreach (var RequestDTO in data)
                //{
                //    var qty = _contextR.TblPurchaseOrderRow.Where(x => x.IntReferenceId == RequestId && x.IntItemId == RequestDTO.Value).Select(x => x.NumReferenceQty).Sum();
                //    RequestDTO.RestofQty = RequestDTO.refQty - qty;
                //}
                return data;
            }
            else
            {
                var data = await Task.FromResult((from pt in _contextR.TblPurchaseOrderRow
                                                  join i in _contextR.TblItemPurchase on pt.IntItemId equals i.IntItemId
                                                  where pt.IntPurchaseOrderId == RequestId && pt.IntItemId == ItemId
                                                  orderby pt.StrItemName ascending
                                                  select new PurchaseRequestItemDTO
                                                  {
                                                      Value = pt.IntItemId,
                                                      Label = pt.StrItemName,
                                                      Description = i.StrPurchaseDescription,
                                                      RestofQty = pt.NumOrderQty,
                                                      refQty = pt.NumReferenceQty,
                                                      UOM = pt.IntUoMid,
                                                      UOMName = pt.StrUoMname
                                                  }).ToList());
                //foreach (var RequestDTO in data)
                //{
                //    var qty = _contextR.TblPurchaseOrderRow.Where(x => x.IntReferenceId == RequestId && x.IntItemId == RequestDTO.Value).Select(x => x.NumReferenceQty).Sum();
                //    RequestDTO.RestofQty = RequestDTO.refQty - qty;
                //}
                return data;
            }
        }
        public async Task<List<getBOMDTO>> getBOM(long AccountId, long UnitId, long PlantId, long ItemId)
        {
            var data = await Task.FromResult((from bom in _contextR.TblBillOfMaterialHeader
                                              join i in _contextR.TblItem on
                                              bom.IntItemId equals i.IntItemId
                                              where bom.IntAccountId == AccountId && bom.IntBusinessUnitId == UnitId && bom.IntPlantId == PlantId && bom.IntItemId == ItemId && bom.IsActive == true
                                              select new getBOMDTO
                                              {
                                                  BOMId = bom.IntBillOfMaterialId,
                                                  BOMCode = bom.StrBillOfMaterialCode,
                                                  BOMName = bom.StrBillOfMaterialName,
                                                  ItemId = bom.IntItemId,
                                                  ItemName = i.StrItemName,
                                                  OutUnitOfMesurement = bom.IntBoMuoMid,
                                                  LotSize = bom.NumLotSize,
                                                  NetWeight = bom.NumLotSize,
                                                  Value = bom.IntBillOfMaterialId,
                                                  Label = bom.StrBillOfMaterialName,
                                                  Code = bom.StrBillOfMaterialCode
                                              }).ToList());
            return data;
        }
        public async Task<List<getControllingUnitDTO>> GetControllingUnit(long AccountId, long UnitId)
        {
            var data = await Task.FromResult((from cu in _contextR.TblControllingUnit
                                              where cu.IntAccountId == AccountId && cu.IntBusinessUnitId == UnitId && cu.IsActive == true
                                              select new getControllingUnitDTO
                                              {
                                                  Value = cu.IntControllingUnitId,
                                                  Label = cu.StrControllingUnitName,
                                                  Code = cu.StrControllingUnitCode,
                                              }).ToList());
            return data;
        }
        public async Task<List<getCostElementDTO>> GetCostElement(long AccountId, long UnitId, long ControllingUnitId)
        {
            var data = await Task.FromResult((from ce in _contextR.TblCostElement
                                              where ce.IntAccountId == AccountId && ce.IntBusinessUnitId == UnitId && ce.IsActive == true && ce.IntControllingUnitId == ControllingUnitId
                                              select new getCostElementDTO
                                              {
                                                  Value = ce.IntCostElementId,
                                                  Label = ce.StrCostElementName,
                                                  Code = ce.StrCostElementCode,
                                              }).ToList());
            return data;
        }
        public async Task<List<getCostCenterDTO>> GetCostCenter(long AccountId, long UnitId)
        {
            var data = await Task.FromResult((from cc in _contextR.TblCostCenter
                                              where cc.IntAccountId == AccountId && cc.IntBusinessUnitId == UnitId && cc.IsActive == true
                                              select new getCostCenterDTO
                                              {
                                                  Value = cc.IntCostCenterId,
                                                  Label = cc.StrCostCenterName,
                                                  Code = cc.StrCostCenterCode,
                                              }).ToList());
            return data;
        }
        public async Task<List<getPurchaseContractHeaderDTO>> getPurchaseContactHeaderInfo(long PurchaseContractId)
        {
            var headerData = await Task.FromResult((from pc in _contextR.TblPurchaseContractHeader
                                                        //join it in _contextR.TblIncoTerms on pc.IntIncotermsId equals it.IntIncotermsId
                                                        //join pt in _contextR.TblPaymentTerms on pc.IntPaymentTerms equals pt.IntPaymentTerms
                                                        //join rt in _contextR.TblPoreferenceType on pc.IntReferenceTypeId equals rt.IntPoreferenceTypeId
                                                    where pc.IntPurchaseContractId == PurchaseContractId && pc.IsActive == true
                                                    select new GetPurchaseContactHeaderDataDTO
                                                    {
                                                        PurchaseOrderTypeId = 2, //this is for purchase contract
                                                        PurchaseContractId = pc.IntPurchaseContractId,
                                                        PurchaseContractNo = pc.StrPurchaseContractNo,
                                                        PurchaseContractDate = pc.DtePurchaseContractDate,
                                                        CurrencyId = pc.IntCurrencyId,
                                                        CurrencyCode = pc.StrCurrencyCode,
                                                        ReferenceTypeId = pc.IntReferenceTypeId,
                                                        ReferenceType = (from i in _contextR.TblPoreferenceType
                                                                         where i.IntPoreferenceTypeId == pc.IntReferenceTypeId
                                                                         select i.StrPoreferenceType).FirstOrDefault(),
                                                        PaymentTermsId = pc.IntPaymentTerms,
                                                        PaymentTerms = (from i in _contextR.TblPaymentTerms
                                                                        where i.IntPaymentTerms == pc.IntPaymentTerms
                                                                        select i.StrPaymentTermsName).FirstOrDefault(),
                                                        IncotermsId = pc.IntIncotermsId,
                                                        Incoterms = (from i in _contextR.TblIncoTerms
                                                                     where i.IntIncotermsId == pc.IntIncotermsId
                                                                     select i.StrIncotermsName).FirstOrDefault(),
                                                        ReferenceDate = pc.DteReferenceDate,
                                                        LastShipmentDate = pc.DteLastShipmentDate,
                                                        DeliveryAddress = pc.StrDeliveryAddress,
                                                        OtherTerms = pc.StrOtherTerms,
                                                        SupplierReference = pc.StrSupplierReference,
                                                        ValidityDate = pc.DtePcvalidityDate,
                                                        SbuId = pc.IntSbuId,
                                                        BusinessPartnerId = pc.IntBusinessPartnerId,
                                                        BusinessPartnerName = (from t in _contextR.TblBusinessPartner
                                                                               where pc.IntBusinessPartnerId == t.IntBusinessPartnerId
                                                                               select t.StrBusinessPartnerName).FirstOrDefault(),
                                                        cashOrAdvancePercent = pc.IntCashOrAdvancePercent,
                                                        paymentDaysAfterDelivery = pc.IntPaymentDaysAfterDelivery,
                                                        ContractTypeName = pc.StrContractType,
                                                        ItemGroupName = pc.StrItemGroupName,
                                                        PlantId = pc.IntPlantId,
                                                        PlantName = pc.StrPlantName,
                                                        WarehouseId = pc.IntWarehouseId,
                                                        WarehouseName = pc.StrWarehouseName,
                                                        PurchaseOrgId = pc.IntPurchaseOrganizationId
                                                    }).FirstOrDefault());

            var row = await Task.FromResult((from t in _contextR.TblPurchaseContractRow
                                             where t.IntPurchaseContractId == PurchaseContractId && t.IsActive == true
                                             select new GetPurchaseContactRowDTO
                                             {
                                                 RowId = t.IntRowId,
                                                 PurchaseContractId = t.IntPurchaseContractId,
                                                 ReferenceId = t.IntReferenceId,
                                                 ReferenceCode = t.StrReferenceCode,
                                                 ItemId = t.IntItemId,
                                                 ItemName = t.StrItemName,
                                                 ItemCode = (from i in _contextR.TblItem
                                                             where i.IntItemId == t.IntItemId
                                                             select i.StrItemCode).FirstOrDefault(),
                                                 UoMid = t.IntUoMid,
                                                 UoMname = t.StrUoMname,
                                                 PurchaseDescription = t.StrPurchaseDescription,
                                                 ReferenceQty = t.NumReferenceQty,
                                                 RestofQuantiy = (from pr in _contextR.TblPurchaseRequestRow
                                                                  where pr.IntPurchaseRequestId == t.IntReferenceId && t.IsActive == true && pr.IntItemId == t.IntItemId
                                                                  select pr.NumRequestQuantity).Sum() - t.NumReferenceQty,
                                                 ContractQty = t.NumContractQty,
                                                 BasePrice = t.NumBasePrice,
                                                 FinalPrice = t.NumFinalPrice,
                                                 TotalValue = t.NumTotalValue,
                                                 DeliveryDate = t.DteDeliveryDateTime,
                                                 PriceStructure = (from a in _contextR.TblPurchaseContractRowPricingDetail
                                                                   where a.IntPurchaseContractRowId == t.IntRowId
                                                                   orderby a.IntSequence ascending
                                                                   select new GetPriceStructureByPartnerDTO
                                                                   {
                                                                       PriceStructureId = (long)a.IntPriceStructureId,
                                                                       PriceStructureName = "",
                                                                       PriceComponentId = (long)a.IntPriceComponentId,
                                                                       PriceComponentCode = a.StrPriceComponentCode,
                                                                       PriceComponentName = a.StrPriceComponentName,
                                                                       ValueType = a.StrValueType,
                                                                       Value = (decimal)a.NumValue,
                                                                       Amount = (decimal)a.NumAmount,
                                                                       BaseComponentId = a.IntBaseComponentId,
                                                                       SerialNo = (long)a.IntSequence,
                                                                       SumFromSerial = (long)a.IntSumFromSerial,
                                                                       SumToSerial = (long)a.IntSumToSerial,
                                                                       Factor = (decimal)a.NumFactor,
                                                                       RowId = (long)a.IntRowId,
                                                                       Mannual = (bool)a.IsManual

                                                                   }).ToList()
                                             }).ToList());

            List<getPurchaseContractHeaderDTO> objListData = new List<getPurchaseContractHeaderDTO>();
            getPurchaseContractHeaderDTO objData = new getPurchaseContractHeaderDTO()
            {
                objHeaderDTO = headerData,
                objRowListDTO = row
            };

            if (objData == null)
                throw new Exception("Does Not Exist in Database");
            else
                objListData.Add(objData);

            return objListData;
        }

        public async Task<List<getPriceStructureDTO>> getPriceStructure(long AccountId, long UnitId)
        {
            var data = await Task.FromResult((from ps in _contextR.TblPriceStructureHeader
                                              join psr in _contextR.TblPriceStructureRow on ps.IntPriceStructureId equals psr.IntPriceStructureId
                                              join pc in _contextR.TblPriceComponent on psr.IntPriceComponentId equals pc.IntPriceComponentId
                                              where ps.IntAccountId == AccountId && ps.IntBusinessUnitId == UnitId
                                              select new getPriceStructureDTO
                                              {
                                                  PriceStructureId = ps.IntPriceStructureId,
                                                  PriceStructureName = ps.StrPriceStructureName,
                                                  PriceComponentId = psr.IntPriceComponentId,
                                                  PriceComponentCode = pc.StrPriceComponentCode,
                                                  PriceComponentName = pc.StrPriceComponentName,
                                                  ValueType = psr.StrValueType,
                                                  Value = psr.NumValue,
                                                  BaseComponentId = psr.IntBaseComponentId,
                                                  SerialNo = psr.IntSerialNo,
                                                  SumFromSerial = psr.IntSumFromSerial,
                                                  SumToSerial = psr.IntSumToSerial,
                                                  Mannual = psr.IsMannual,
                                              }).ToList());
            return data;
        }
        public async Task<List<GetPriceStructureCommonDTO>> GetPriceStructureList(long AccountId, long BusinessUnitId, long PriceStructureId)
        {
            try
            {
                GetPriceStructureHeaderDTO header = await Task.FromResult((from psh in _contextR.TblPriceStructureHeader
                                                                           where psh.IsActive == true && psh.IntPriceStructureId == PriceStructureId && psh.IsActive == true
                                                                           select new GetPriceStructureHeaderDTO
                                                                           {
                                                                               PriceStructureId = psh.IntPriceStructureId,
                                                                               PriceStructureCode = psh.StrPriceStructureCode,
                                                                               PriceStructureName = psh.StrPriceStructureName,
                                                                               PriceStructureTypeId = psh.IntPriceStructureTypeId

                                                                           }).FirstOrDefault());

                List<GetPriceStructureRowDTO> row = await Task.FromResult((from t in _contextR.TblPriceStructureRow
                                                                           where t.IntPriceStructureId == PriceStructureId && t.IsActive == true
                                                                           select new GetPriceStructureRowDTO
                                                                           {
                                                                               RowId = t.IntRowId,
                                                                               PriceStructureId = t.IntPriceStructureId,
                                                                               PriceComponentId = t.IntPriceComponentId,
                                                                               PriceComponentCode = t.StrPriceComponentCode,
                                                                               Value = t.NumValue,
                                                                               ValueType = t.StrValueType,
                                                                               BaseComponentId = t.IntBaseComponentId,
                                                                               SerialNo = t.IntSerialNo,
                                                                               SumFromSerial = t.IntSumFromSerial,
                                                                               SumToSerial = t.IntSumToSerial,
                                                                               Mannual = t.IsMannual,
                                                                               Active = t.IsActive

                                                                           }).ToList());

                List<GetPriceStructureCommonDTO> objListData = new List<GetPriceStructureCommonDTO>();
                GetPriceStructureCommonDTO objData = new GetPriceStructureCommonDTO()
                {
                    objHeaderDTO = header,
                    objRowListDTO = row
                };


                if (objData == null)
                    throw new Exception("Price Structure Information Not Exist.");
                else
                    objListData.Add(objData);

                return objListData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<GetBillOfMaterialCommonDTO>> GetBillOfMaterialList(long AccountId, long BusinessUnitId, long BillOfMaterialId)
        {
            try
            {
                GetBillOfMaterialHeaderDTO header = await Task.FromResult((from bom in _contextR.TblBillOfMaterialHeader
                                                                           join bomr in _contextR.TblBillOfMaterialRow on bom.IntBillOfMaterialId equals bomr.IntBillOfMaterialId
                                                                           join p in _contextR.TblPlant on bom.IntPlantId equals p.IntPlantId
                                                                           join i in _contextR.TblItem on bom.IntItemId equals i.IntItemId
                                                                           where bom.IsActive == true && bom.IntBillOfMaterialId == BillOfMaterialId
                                                                           select new GetBillOfMaterialHeaderDTO
                                                                           {
                                                                               BillOfMaterialId = bom.IntBillOfMaterialId,
                                                                               BillOfMaterialCode = bom.StrBillOfMaterialCode,
                                                                               BillOfMaterialName = bom.StrBillOfMaterialName,
                                                                               PlantName = p.StrPlantName,
                                                                               ItemName = i.StrItemName,
                                                                               OutUnitOfMeasure = bom.IntBoMuoMid,
                                                                               Quantity = bomr.NumQuantity,
                                                                               NetWeightKg = bom.NumLotSize

                                                                           }).FirstOrDefault());

                List<GetBillOfMaterialRowDTO> row = await Task.FromResult((from t in _contextR.TblBillOfMaterialRow
                                                                           where t.IntBillOfMaterialId == BillOfMaterialId
                                                                           select new GetBillOfMaterialRowDTO
                                                                           {
                                                                               RowId = t.IntBoMrowId,
                                                                               BillOfMaterialId = t.IntBillOfMaterialId,
                                                                               ItemId = t.IntItemId,
                                                                               UnitOfMeasureId = t.IntUomid,
                                                                               Quantity = t.NumQuantity,
                                                                               NetWeightKg = t.NumQuantity

                                                                           }).ToList());

                List<GetBillOfMaterialCommonDTO> objListData = new List<GetBillOfMaterialCommonDTO>();
                GetBillOfMaterialCommonDTO objData = new GetBillOfMaterialCommonDTO()
                {
                    objHeaderDTO = header,
                    objRowListDTO = row
                };


                if (objData == null)
                    throw new Exception("Bill Of Material Information Not Exist.");
                else
                    objListData.Add(objData);

                return objListData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<MessageHelper> EditPurchaseOrder(EditPurchaseOrderCommonDTO objPO)
        {
            try
            {
                if (objPO.objRowListDTO.Count > 0)
                {
                    Models.Write.TblPurchaseOrderHeader detalisHeader = _contextW.TblPurchaseOrderHeader.First(x => x.IntPurchaseOrderId == objPO.objHeaderDTO.PurchaseOrderId
                                                                           && x.IsApproved == false && x.IsActive == true
                                                                           && x.IntAccountId == objPO.objHeaderDTO.AccountId && x.IntBusinessUnitId == objPO.objHeaderDTO.BusinessUnitId);

                    detalisHeader.StrPurchaseOrderNo = objPO.objHeaderDTO.PurchaseOrderNo;
                    detalisHeader.IntPlantId = objPO.objHeaderDTO.PlantId;
                    detalisHeader.IntSbuid = objPO.objHeaderDTO.SbuId;
                    detalisHeader.StrPlantName = objPO.objHeaderDTO.PlantName;
                    detalisHeader.IntWarehouseId = objPO.objHeaderDTO.WarehouseId;
                    detalisHeader.StrWarehouseName = objPO.objHeaderDTO.WarehouseName;
                    detalisHeader.IntPurchaseOrganizationId = objPO.objHeaderDTO.PurchaseOrganizationId;
                    detalisHeader.IntBusinessPartnerId = objPO.objHeaderDTO.BusinessPartnerId;
                    detalisHeader.StrBusinessPartnerName = (objPO.objHeaderDTO.BusinessPartnerId == 0) ? "" : (from i in _contextW.TblBusinessPartner
                                                                                                               where i.IntBusinessPartnerId == objPO.objHeaderDTO.BusinessPartnerId
                                                                                                               select i.StrBusinessPartnerName).FirstOrDefault();

                    detalisHeader.DtePurchaseOrderDate = objPO.objHeaderDTO.PurchaseOrderDate;
                    detalisHeader.IntPurchaseOrderTypeId = objPO.objHeaderDTO.PurchaseOrderTypeId;
                    detalisHeader.IntIncotermsId = objPO.objHeaderDTO.IncotermsId;
                    detalisHeader.IntCurrencyId = objPO.objHeaderDTO.CurrencyId;
                    detalisHeader.StrCurrencyCode = (objPO.objHeaderDTO.CurrencyId == 0) ? "" : (from c in _contextR.TblCurrency
                                                                                                 where c.IntCurrencyId == objPO.objHeaderDTO.CurrencyId
                                                                                                 select c.StrCurrencyCode).FirstOrDefault();
                    detalisHeader.StrSupplierReference = objPO.objHeaderDTO.SupplierReference;
                    detalisHeader.DteReferenceDate = objPO.objHeaderDTO.ReferenceDate;
                    detalisHeader.IntReferenceTypeId = objPO.objHeaderDTO.ReferenceTypeId;
                    detalisHeader.IntPriceStructureId = objPO.objHeaderDTO.PriceStructureId;

                    detalisHeader.IntPaymentTerms = objPO.objHeaderDTO.PaymentTerms;
                    detalisHeader.IntCreditPercent = objPO.objHeaderDTO.CreditPercent;
                    detalisHeader.IntCashOrAdvancePercent = objPO.objHeaderDTO.CashOrAdvancePercent;
                    detalisHeader.StrOtherTerms = objPO.objHeaderDTO.OtherTerms;
                    detalisHeader.DtePovalidityDate = objPO.objHeaderDTO.POValidityDate;
                    detalisHeader.DteLastShipmentDate = objPO.objHeaderDTO.LastShipmentDate;
                    detalisHeader.IntPaymentDaysAfterDelivery = objPO.objHeaderDTO.PaymentDaysAfterDelivery;
                    detalisHeader.StrDeliveryAddress = objPO.objHeaderDTO.DeliveryAddress;
                    detalisHeader.IntActionBy = objPO.objHeaderDTO.ActionBy;
                    detalisHeader.DteLastActionDateTime = DateTime.UtcNow;
                    detalisHeader.IntSupplyingWarehouseId = objPO.objHeaderDTO.SupplyingWarehouseId;
                    detalisHeader.StrSupplyingWarehouseName = objPO.objHeaderDTO.SupplyingWarehouseName;
                    detalisHeader.DteReturnDateTime = objPO.objHeaderDTO.ReturnDate;

                    _contextW.TblPurchaseOrderHeader.Update(detalisHeader);
                    await _contextW.SaveChangesAsync();


                    var innerquery = from c in objPO.objRowListDTO
                                     where c.RowId > 0
                                     select c.RowId;
                    var inactiveItems = (from p in _contextW.TblPurchaseOrderRow
                                         where p.IntPurchaseOrderId == detalisHeader.IntPurchaseOrderId// && innerquery.Contains(p.IntRowId)
                                         select p).ToList();

                    inactiveItems.ForEach(x => x.IsActive = false);
                    _contextW.TblPurchaseOrderRow.UpdateRange(inactiveItems);
                    await _contextW.SaveChangesAsync();

                    List<TblPurchaseOrderRowPricingDetail> RowPricingDetailList = new List<TblPurchaseOrderRowPricingDetail>();
                    foreach (var a in inactiveItems)
                    {
                        var POrderRowPricingDetail = _contextW.TblPurchaseOrderRowPricingDetail.Where(x => x.IntPurchaseOrderRowId == a.IntRowId).ToList();
                        POrderRowPricingDetail.ForEach(x => x.IsActive = false);
                        _contextW.TblPurchaseOrderRowPricingDetail.UpdateRange(POrderRowPricingDetail);
                        await _contextW.SaveChangesAsync();
                    }


                    foreach (var datas in objPO.objRowListDTO)
                    {
                        //if (datas.RowId == 0)
                        //{
                        var detalisrow = new Models.Write.TblPurchaseOrderRow { };

                        detalisrow.IntPurchaseOrderId = detalisHeader.IntPurchaseOrderId;
                        detalisrow.IntReferenceId = datas.ReferenceId;
                        detalisrow.StrReferenceCode = datas.ReferenceCode;
                        detalisrow.NumReferenceQty = datas.ReferenceQty;
                        detalisrow.IntItemId = datas.ItemId;
                        detalisrow.StrItemName = datas.ItemName;
                        detalisrow.IntUoMid = datas.UoMid;
                        detalisrow.StrUoMname = datas.UoMname;
                        detalisrow.IntControllingUnitId = datas.ControllingUnitId;
                        detalisrow.StrControllingUnitName = datas.ControllingUnitName;
                        detalisrow.IntCostCenterId = datas.CostCenterId;
                        detalisrow.StrCostCenterName = datas.CostCenterName;
                        detalisrow.IntCostElementId = datas.CostElementId;
                        detalisrow.StrCostElementName = datas.CostElementName;
                        detalisrow.StrPurchaseDescription = datas.PurchaseDescription;
                        detalisrow.StrPurchaseDescription = datas.PurchaseDescription;
                        detalisrow.NumOrderQty = datas.OrderQty;
                        detalisrow.NumBasePrice = datas.BasePrice;
                        detalisrow.NumFinalPrice = datas.FinalPrice;
                        detalisrow.NumTotalValue = datas.TotalValue;
                        detalisrow.IntActionBy = detalisHeader.IntActionBy;
                        detalisrow.DteLastActionDateTime = DateTime.UtcNow;

                        await _contextW.TblPurchaseOrderRow.AddAsync(detalisrow);
                        await _contextW.SaveChangesAsync();


                        var mPriceRow = new List<Models.Write.TblPurchaseOrderRowPricingDetail>(datas.objPriceRowListDTO.Count);
                        foreach (var datasPriceRow in datas.objPriceRowListDTO)
                        {
                            var detalisrows = new Models.Write.TblPurchaseOrderRowPricingDetail { };
                            detalisrows.IntPurchaseOrderRowId = detalisrow.IntRowId;
                            detalisrows.IntPriceStructureId = datasPriceRow.PriceStructureId;
                            detalisrows.IntBaseComponentId = datasPriceRow.BaseComponentId;


                            detalisrows.IntPriceComponentId = datasPriceRow.PriceComponentId;
                            detalisrows.StrPriceComponentCode = datasPriceRow.PriceComponentCode;
                            detalisrows.StrPriceComponentName = datasPriceRow.PriceComponentName;
                            detalisrows.IntSequence = datasPriceRow.SerialNo;
                            detalisrows.StrValueType = datasPriceRow.ValueType;
                            detalisrows.NumValue = datasPriceRow.Value;
                            detalisrows.NumAmount = datasPriceRow.Amount;
                            detalisrows.IntSumFromSerial = datasPriceRow.SumFromSerial;
                            detalisrows.IntSumToSerial = datasPriceRow.SumToSerial;
                            detalisrows.IsManual = datasPriceRow.Mannual;
                            detalisrows.NumFactor = datasPriceRow.Factor;
                            detalisrows.IsActive = true;
                            mPriceRow.Add(detalisrows);
                        }
                        await _contextW.TblPurchaseOrderRowPricingDetail.AddRangeAsync(mPriceRow);
                        await _contextW.SaveChangesAsync();
                        //}

                        //else
                        //{
                        //    //var mRows = new List<TblPurchaseOrderRow>();
                        //    Models.Write.TblPurchaseOrderRow data = _contextW.TblPurchaseOrderRow.
                        //        Where(x => x.IntRowId == datas.RowId).FirstOrDefault();
                        //    if (data != null)
                        //    {
                        //        data.NumBasePrice = datas.BasePrice;
                        //        data.NumFinalPrice = datas.FinalPrice;
                        //        data.NumTotalValue = datas.TotalValue;
                        //        data.NumOrderQty = datas.OrderQty;
                        //        data.StrPurchaseDescription = datas.PurchaseDescription;
                        //        data.IntUoMid = datas.UoMid;
                        //        data.StrUoMname = datas.UoMname;
                        //    }
                        //     _contextW.TblPurchaseOrderRow.Update(data);
                        //    await _contextW.SaveChangesAsync();
                        //}

                    }


                    var msg = new MessageHelper();
                    msg.Message = "Processing";
                    msg.statuscode = 200;
                    return msg;
                }
                else
                    throw new Exception("Please Add Details!");

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<MessageHelper> EditPurchaseContact(EditPurchaseContactCommonDTO objPO)
        {
            try
            {
                if (objPO.RowListDTO.Count > 0)
                {
                    Models.Write.TblPurchaseContractHeader detalisHeader = _contextW.TblPurchaseContractHeader.First(x => x.IntPurchaseContractId == objPO.HeaderDTO.PurchaseContractId
                                                                            && x.IsActive == true);

                    detalisHeader.StrPurchaseContractNo = objPO.HeaderDTO.PurchaseContractNo;
                    detalisHeader.IntAccountId = objPO.HeaderDTO.AccountId;
                    detalisHeader.IntBusinessUnitId = objPO.HeaderDTO.BusinessUnitId;
                    detalisHeader.IntPlantId = objPO.HeaderDTO.PlantId;
                    detalisHeader.StrPlantName = objPO.HeaderDTO.PlantName;
                    detalisHeader.IntWarehouseId = objPO.HeaderDTO.WarehouseId;
                    detalisHeader.StrWarehouseName = objPO.HeaderDTO.WarehouseName;
                    detalisHeader.IntPurchaseOrganizationId = objPO.HeaderDTO.PurchaseOrganizationId;
                    detalisHeader.IntBusinessPartnerId = objPO.HeaderDTO.BusinessPartnerId;
                    detalisHeader.DtePurchaseContractDate = objPO.HeaderDTO.PurchaseContractDate;
                    detalisHeader.IntCurrencyId = objPO.HeaderDTO.CurrencyId;
                    detalisHeader.StrCurrencyCode = objPO.HeaderDTO.CurrencyCode;
                    detalisHeader.IntReferenceTypeId = objPO.HeaderDTO.ReferenceTypeId;
                    detalisHeader.IntPaymentTerms = objPO.HeaderDTO.PaymentTerms;
                    detalisHeader.IntCreditPercent = objPO.HeaderDTO.CreditPercent;
                    detalisHeader.IntCashOrAdvancePercent = objPO.HeaderDTO.CashOrAdvancePercent;
                    detalisHeader.IntPaymentTerms = objPO.HeaderDTO.PaymentTerms;
                    detalisHeader.IntCreditPercent = objPO.HeaderDTO.CreditPercent;
                    detalisHeader.IntCashOrAdvancePercent = objPO.HeaderDTO.CashOrAdvancePercent;
                    detalisHeader.IntIncotermsId = objPO.HeaderDTO.IncotermsId;
                    detalisHeader.StrSupplierReference = objPO.HeaderDTO.SupplierReference;
                    detalisHeader.DteReferenceDate = objPO.HeaderDTO.ReferenceDate;
                    detalisHeader.StrItemGroupName = objPO.HeaderDTO.ItemGroupName;
                    detalisHeader.StrContractType = objPO.HeaderDTO.ContractType;
                    detalisHeader.DtePcvalidityDate = objPO.HeaderDTO.PcvalidityDate;
                    detalisHeader.StrOtherTerms = objPO.HeaderDTO.OtherTerms;
                    detalisHeader.IntApproveBy = objPO.HeaderDTO.ApproveBy;
                    detalisHeader.DteApproveDatetime = objPO.HeaderDTO.ApproveDatetime;
                    detalisHeader.DteLastShipmentDate = objPO.HeaderDTO.LastShipmentDate;
                    detalisHeader.IntPaymentDaysAfterDelivery = objPO.HeaderDTO.PaymentDaysAfterDelivery;
                    detalisHeader.StrDeliveryAddress = objPO.HeaderDTO.DeliveryAddress;
                    detalisHeader.IntActionBy = objPO.HeaderDTO.ActionBy;
                    detalisHeader.DteLastActionDateTime = DateTime.UtcNow;
                    detalisHeader.IntSbuId = objPO.HeaderDTO.SbuId;

                    _contextW.TblPurchaseContractHeader.Update(detalisHeader);
                    await _contextW.SaveChangesAsync();

                    var innerquery = from c in objPO.RowListDTO
                                     where c.RowId > 0
                                     select c.RowId;
                    var inactiveItems = (from p in _contextW.TblPurchaseContractRow
                                         where p.IntPurchaseContractId == detalisHeader.IntPurchaseContractId// && innerquery.Contains(p.IntRowId)
                                         select p).ToList();

                    inactiveItems.ForEach(x => x.IsActive = false);
                    _contextW.TblPurchaseContractRow.UpdateRange(inactiveItems);
                    await _contextW.SaveChangesAsync();

                    List<TblPurchaseContractRowPricingDetail> RowPricingDetailList = new List<TblPurchaseContractRowPricingDetail>();
                    foreach (var a in inactiveItems)
                    {
                        var POrderRowPricingDetail = _contextW.TblPurchaseContractRowPricingDetail.Where(x => x.IntPurchaseContractRowId == a.IntRowId).ToList();
                        POrderRowPricingDetail.ForEach(x => x.IsActive = false);
                        _contextW.TblPurchaseContractRowPricingDetail.UpdateRange(POrderRowPricingDetail);
                        await _contextW.SaveChangesAsync();
                    }

                    foreach (var datas in objPO.RowListDTO)
                    {
                        //if (datas.RowId == 0)
                        //{
                        var detalisrow = new Models.Write.TblPurchaseContractRow { };

                        detalisrow.IntPurchaseContractId = detalisHeader.IntPurchaseContractId;
                        //string[] separatingStrings = { "Id:", ",", "Code:" };
                        //String[] word = datas.ReferenceCode.Split(separatingStrings, System.StringSplitOptions.RemoveEmptyEntries);

                        detalisrow.IntReferenceId = datas.ReferenceId;
                        detalisrow.StrReferenceCode = datas.ReferenceCode;
                        detalisrow.NumReferenceQty = datas.ReferenceQty;
                        detalisrow.IntItemId = datas.ItemId;
                        detalisrow.StrItemName = datas.ItemName;
                        detalisrow.IntUoMid = datas.UoMid;
                        detalisrow.StrUoMname = datas.UoMname;
                        detalisrow.StrPurchaseDescription = datas.PurchaseDescription;
                        detalisrow.NumContractQty = datas.ContractQty;
                        detalisrow.NumBasePrice = datas.BasePrice;
                        detalisrow.NumFinalPrice = datas.FinalPrice;
                        detalisrow.NumTotalValue = datas.TotalValue;
                        detalisrow.IntActionBy = datas.ActionBy;
                        detalisrow.DteLastActionDateTime = DateTime.UtcNow;
                        detalisrow.DteDeliveryDateTime = datas.DeliveryDateTime;

                        await _contextW.TblPurchaseContractRow.AddAsync(detalisrow);
                        await _contextW.SaveChangesAsync();

                        var mPriceRow = new List<Models.Write.TblPurchaseContractRowPricingDetail>(datas.objListCPCPriceingDetailsDTO.Count);
                        foreach (var v in datas.objListCPCPriceingDetailsDTO)
                        {
                            var detalisrows = new Models.Write.TblPurchaseContractRowPricingDetail { };
                            detalisrows.IntPurchaseContractRowId = detalisrow.IntRowId;
                            detalisrows.IntPriceStructureId = v.PriceStructureId;
                            detalisrows.IntBaseComponentId = v.BaseComponentId;
                            detalisrows.IntPriceComponentId = v.PriceComponentId;
                            detalisrows.StrPriceComponentCode = v.PriceComponentCode;
                            detalisrows.StrPriceComponentName = v.PriceComponentName;
                            detalisrows.IntSequence = v.SerialNo;
                            detalisrows.StrValueType = v.ValueType;
                            detalisrows.NumValue = v.Value;
                            detalisrows.NumAmount = v.Amount;
                            detalisrows.IntSumFromSerial = v.SumFromSerial;
                            detalisrows.IntSumToSerial = v.SumToSerial;
                            detalisrows.IsManual = v.Mannual;
                            detalisrows.NumFactor = v.Factor;
                            detalisrows.IsActive = true;

                            mPriceRow.Add(detalisrows);
                        }
                        await _contextW.TblPurchaseContractRowPricingDetail.AddRangeAsync(mPriceRow);
                        await _contextW.SaveChangesAsync();
                        //}
                    }

                    var msg = new MessageHelper();
                    msg.Message = "Edit Purchase Contract is Processing";
                    msg.statuscode = 200;
                    return msg;
                }
                else
                    throw new Exception("Please Add Details!");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<PurchaseRequestItemDTO>> GetPOItemByItemId(long RequestId, long ReferanceTypeId, long ItemId, string ReferanceTypeName)
        {
            List<PurchaseRequestItemDTO> objList = new List<PurchaseRequestItemDTO>();
            if (ReferanceTypeId == 1 || ReferanceTypeName == "Purchase Contract")
            {
                objList = await Task.FromResult((from pc in _contextR.TblPurchaseContractHeader
                                                 join pt in _contextR.TblPurchaseContractRow on pc.IntPurchaseContractId equals pt.IntPurchaseContractId
                                                 where pt.IntPurchaseContractId == RequestId && pt.IntItemId == ItemId
                                                 orderby pt.StrItemName ascending
                                                 select new PurchaseRequestItemDTO
                                                 {
                                                     Value = pt.IntItemId,
                                                     Label = pt.StrItemName,
                                                     Description = "",
                                                     RestofQty = 0,
                                                     refQty = pt.NumReferenceQty,
                                                     UOM = pt.IntUoMid,
                                                     UOMName = pt.StrUoMname
                                                 }).ToList());


                foreach (var RequestDTO in objList)
                {
                    var qty = _contextR.TblPurchaseOrderRow.Where(x => x.IntReferenceId == RequestId && x.IntItemId == RequestDTO.Value).Select(x => x.NumReferenceQty).Sum();
                    RequestDTO.RestofQty = RequestDTO.refQty - qty;
                }
            }
            else if (ReferanceTypeId == 2 || ReferanceTypeName == "Purchase Request")
            {
                objList = await Task.FromResult((from pH in _contextR.TblPurchaseRequestHeader
                                                 join pt in _contextR.TblPurchaseRequestRow on pH.IntPurchaseRequestId equals pt.IntPurchaseRequestId
                                                 where pt.IntPurchaseRequestId == RequestId && pt.IntItemId == ItemId
                                                 orderby pt.StrItemName ascending
                                                 select new PurchaseRequestItemDTO
                                                 {
                                                     Value = pt.IntItemId,
                                                     Label = pt.StrItemName,
                                                     Description = "",
                                                     RestofQty = 0,
                                                     refQty = (decimal)pt.NumRfqquantity,
                                                     UOM = pt.IntUoMid,
                                                     UOMName = pt.StrUoMname
                                                 }).ToList());

                foreach (var RequestDTO in objList)
                {
                    var qty = _contextR.TblPurchaseOrderRow.Where(x => x.IntReferenceId == RequestId && x.IntItemId == RequestDTO.Value).Select(x => x.NumReferenceQty).Sum();
                    RequestDTO.RestofQty = RequestDTO.refQty - qty;
                }
            }
            else if (ReferanceTypeId == 4 || ReferanceTypeName == "PO Reference")
            {
                objList = await Task.FromResult((from prt in _contextR.TblPurchaseRequestHeader
                                                 join pt in _contextR.TblPurchaseRequestRow on prt.IntPurchaseRequestId equals pt.IntPurchaseRequestId
                                                 where pt.IntPurchaseRequestId == RequestId && pt.IntItemId == ItemId
                                                 orderby pt.StrItemName ascending
                                                 select new PurchaseRequestItemDTO
                                                 {
                                                     Value = pt.IntItemId,
                                                     Label = pt.StrItemName,
                                                     Description = "",
                                                     RestofQty = 0,
                                                     refQty = (decimal)pt.NumRfqquantity,
                                                     UOM = pt.IntUoMid,
                                                     UOMName = pt.StrUoMname
                                                 }).ToList());
                foreach (var RequestDTO in objList)
                {
                    var qty = _contextR.TblPurchaseOrderRow.Where(x => x.IntReferenceId == RequestId && x.IntItemId == RequestDTO.Value).Select(x => x.NumReferenceQty).Sum();
                    RequestDTO.RestofQty = RequestDTO.refQty - qty;
                }
            }

            return objList;
        }
        public async Task<List<PurchaseRequestItemDTO>> GetPOItemListInfo(long RequestId, long ReferanceTypeId, string ReferanceTypeName)
        {
            List<PurchaseRequestItemDTO> objList = new List<PurchaseRequestItemDTO>();
            if (ReferanceTypeId == 1 || ReferanceTypeName == "Purchase Contract")
            {
                objList = await Task.FromResult((from pc in _contextR.TblPurchaseContractHeader
                                                 join pt in _contextR.TblPurchaseContractRow on pc.IntPurchaseContractId equals pt.IntPurchaseContractId
                                                 where pt.IntPurchaseContractId == RequestId
                                                 orderby pt.StrItemName ascending
                                                 select new PurchaseRequestItemDTO
                                                 {
                                                     Value = pt.IntItemId,
                                                     Label = pt.StrItemName,
                                                     Description = "",
                                                     RestofQty = 0,
                                                     refQty = pt.NumReferenceQty,
                                                     UOM = pt.IntUoMid,
                                                     UOMName = pt.StrUoMname
                                                 }).ToList());


                foreach (var RequestDTO in objList)
                {
                    var qty = _contextR.TblPurchaseOrderRow.Where(x => x.IntReferenceId == RequestId && x.IntItemId == RequestDTO.Value).Select(x => x.NumReferenceQty).Sum();
                    RequestDTO.RestofQty = RequestDTO.refQty - qty;
                }
            }
            else if (ReferanceTypeId == 2 || ReferanceTypeName == "Purchase Request")
            {
                objList = await Task.FromResult((from pH in _contextR.TblPurchaseRequestHeader
                                                 join pt in _contextR.TblPurchaseRequestRow on pH.IntPurchaseRequestId equals pt.IntPurchaseRequestId
                                                 where pt.IntPurchaseRequestId == RequestId
                                                 orderby pt.StrItemName ascending
                                                 select new PurchaseRequestItemDTO
                                                 {
                                                     Value = pt.IntItemId,
                                                     Label = pt.StrItemName,
                                                     Description = "",
                                                     RestofQty = 0,
                                                     refQty = (decimal)pt.NumRfqquantity,
                                                     UOM = pt.IntUoMid,
                                                     UOMName = pt.StrUoMname
                                                 }).ToList());

                foreach (var RequestDTO in objList)
                {
                    var qty = _contextR.TblPurchaseOrderRow.Where(x => x.IntReferenceId == RequestId && x.IntItemId == RequestDTO.Value).Select(x => x.NumReferenceQty).Sum();
                    RequestDTO.RestofQty = RequestDTO.refQty - qty;
                }
            }
            else if (ReferanceTypeId == 4 || ReferanceTypeName == "PO Reference")
            {
                objList = await Task.FromResult((from prt in _contextR.TblPurchaseRequestHeader
                                                 join pt in _contextR.TblPurchaseRequestRow on prt.IntPurchaseRequestId equals pt.IntPurchaseRequestId
                                                 where pt.IntPurchaseRequestId == RequestId
                                                 orderby pt.StrItemName ascending
                                                 select new PurchaseRequestItemDTO
                                                 {
                                                     Value = pt.IntItemId,
                                                     Label = pt.StrItemName,
                                                     Description = "",
                                                     RestofQty = 0,
                                                     refQty = (decimal)pt.NumRfqquantity,
                                                     UOM = pt.IntUoMid,
                                                     UOMName = pt.StrUoMname
                                                 }).ToList());
                foreach (var RequestDTO in objList)
                {
                    var qty = _contextR.TblPurchaseOrderRow.Where(x => x.IntReferenceId == RequestId && x.IntItemId == RequestDTO.Value).Select(x => x.NumReferenceQty).Sum();
                    RequestDTO.RestofQty = RequestDTO.refQty - qty;
                }
            }

            return objList;
        }
        public async Task<List<GetPurchaseOrderDDLDTO>> GetPurchaseOrderDDL(long AccountId, long BusinessUnitId, long SBUId, long PurchaseOrganizationId, long PlantId, long WarehouseId, long SupplierId)
        {
            var data = await Task.FromResult((from pro in _contextR.TblPurchaseOrderHeader
                                              where pro.IsActive == true && pro.IntAccountId == AccountId && pro.IntBusinessUnitId == BusinessUnitId
                                              && pro.IntSbuid == SBUId && pro.IntPurchaseOrganizationId == PurchaseOrganizationId && pro.IntPlantId == PlantId
                                              && pro.IntWarehouseId == WarehouseId && pro.IntBusinessPartnerId == SupplierId
                                              && pro.IsApproved == true && pro.IsClosed == false
                                              orderby pro.StrPurchaseOrderNo ascending
                                              select new GetPurchaseOrderDDLDTO
                                              {
                                                  Value = pro.IntPurchaseOrderId,
                                                  Label = pro.StrPurchaseOrderNo
                                              }).Distinct().ToList()); ;
            if (data == null)
                throw new Exception("Purchase Order Data Not Found.");

            return data;

        }
        public async Task<List<GetPriceStructureByPartnerDTO>> GetPriceStructureByPartnerId(long AccountId, long UnitId, long PartnerId)
        {
            var PriceStructureData = await Task.FromResult((from ps in _contextR.TblPriceStructureHeader
                                                            join psr in _contextR.TblPriceStructureRow on ps.IntPriceStructureId equals psr.IntPriceStructureId
                                                            join pc in _contextR.TblPriceComponent on psr.IntPriceComponentId equals pc.IntPriceComponentId
                                                            join bp in _contextR.TblBusinessPartnerPurchase on ps.IntPriceStructureId equals bp.IntPriceStructureId
                                                            where ps.IntAccountId == AccountId && ps.IntBusinessUnitId == UnitId
                                                            && bp.IntBusinessPartnerId == PartnerId && bp.IntAccountId == AccountId && bp.IntBusinessUnitId == UnitId
                                                            select new GetPriceStructureByPartnerDTO
                                                            {
                                                                PriceStructureId = ps.IntPriceStructureId,
                                                                PriceStructureName = ps.StrPriceStructureName,
                                                                PriceComponentId = psr.IntPriceComponentId,
                                                                PriceComponentCode = pc.StrPriceComponentCode,
                                                                PriceComponentName = pc.StrPriceComponentName,
                                                                ValueType = psr.StrValueType,
                                                                Value = psr.NumValue,
                                                                BaseComponentId = psr.IntBaseComponentId,
                                                                SerialNo = psr.IntSerialNo,
                                                                SumFromSerial = psr.IntSumFromSerial,
                                                                SumToSerial = psr.IntSumToSerial,
                                                                Mannual = psr.IsMannual
                                                            }).ToList());
            return PriceStructureData;
        }

        public async Task<List<GetPurchaseOrderPIDDLDTO>> GetPurchaseOrderPIDDL(long AccountId, long BusinessUnitId, long SBUId)
        {
            //throw new NotImplementedException();

            var data = await Task.FromResult((from pro in _contextR.TblPurchaseOrderHeader
                                              join por in _contextR.TblPurchaseOrganization on pro.IntPurchaseOrganizationId equals por.IntPurchaseOrganizationid
                                              join p in _contextR.TblPlant on pro.IntPlantId equals p.IntPlantId
                                              join w in _contextR.TblWarehouse on pro.IntWarehouseId equals w.IntWarehouseId
                                              join bp in _contextR.TblBusinessPartner on pro.IntBusinessPartnerId equals bp.IntBusinessPartnerId
                                              where pro.IntAccountId == AccountId && pro.IntBusinessUnitId == BusinessUnitId
                                              && pro.IntSbuid == SBUId && pro.IsApproved == true && pro.IsClosed == false && pro.IsActive == true
                                              orderby pro.StrPurchaseOrderNo ascending
                                              select new GetPurchaseOrderPIDDLDTO
                                              {
                                                  IntPurchaseOrderId = pro.IntPurchaseOrderId,
                                                  IntPurchaseOrderNumber = pro.StrPurchaseOrderNo,
                                                  TotalPOAmount = (from i in _contextR.TblPurchaseOrderRow
                                                                   where i.IntPurchaseOrderId == pro.IntPurchaseOrderId
                                                                   select i.NumTotalValue).Sum(),
                                                  PurchaseOrganizationId = pro.IntPurchaseOrganizationId,
                                                  PurchaseOrganizationName = por.StrPurchaseOrganization,
                                                  PlantId = pro.IntPlantId,
                                                  Plant = p.StrPlantName,
                                                  WarehouseId = pro.IntWarehouseId,
                                                  WarehouseName = w.StrWarehouseName,
                                                  SupplierId = pro.IntBusinessPartnerId,
                                                  SupplierName = bp.StrBusinessPartnerName + "[" + bp.StrBusinessPartnerCode + "]"



                                              }).Distinct().ToList()); ;
            if (data == null)

                throw new Exception("Purchase Order Data Not Found.");

            return data;
        }

        public async Task<List<GetPurchaseOrderDDLDTO>> GetPONoDDL(long AccountId, long BusinessUnitId, long WarehouseId)
        {
            var data = await Task.FromResult((from pro in _contextR.TblPurchaseOrderHeader
                                              where pro.IsActive == true && pro.IntAccountId == AccountId && pro.IntBusinessUnitId == BusinessUnitId
                                              && pro.IntWarehouseId == WarehouseId
                                              && pro.IsApproved == true && pro.IsClosed == false
                                              orderby pro.StrPurchaseOrderNo ascending
                                              select new GetPurchaseOrderDDLDTO
                                              {
                                                  Value = pro.IntPurchaseOrderId,
                                                  Label = pro.StrPurchaseOrderNo
                                              }).ToList()); ;
            if (data == null)
                throw new Exception("Purchase Order Data Not Found.");

            return data;
        }

        public async Task<purchaseOrderPasignation> GetPurchaseOrderInformationSearchPasignation(string searchTerm, long AccountId, long UnitId, long Sbu, long Plant, long WearHouse, long PurchaseOrderTypeId, long PurchaseOrganizationId, long ReferenceTypeId, bool isApproved, string viewOrder, long PageNo, long PageSize)
        {
            // throw new NotImplementedException();

            if (PurchaseOrderTypeId == 2)//for purchase contact type
            {
                IQueryable<GetPurchaseOrderHeaderDTO> data = (from prh in _contextR.TblPurchaseContractHeader
                                                              join porg in _contextR.TblBusinessUnitPurchaseOrganization on prh.IntPurchaseOrganizationId equals porg.IntPurchaseOrganizationid
                                                              where prh.IntAccountId == AccountId && prh.IntBusinessUnitId == UnitId
                                                              && prh.IntPlantId == Plant && prh.IntWarehouseId == WearHouse
                                                              && prh.IntPurchaseOrganizationId == PurchaseOrganizationId
                                                              && prh.IntReferenceTypeId == ReferenceTypeId
                                                              && prh.IsActive == true && prh.IntAccountId == porg.IntAccountId && prh.IntBusinessUnitId == porg.IntBusinessUnitId
                                                              select new GetPurchaseOrderHeaderDTO
                                                              {
                                                                  PurchaseOrderId = prh.IntPurchaseContractId,
                                                                  PurchaseOrderNo = prh.StrPurchaseContractNo,
                                                                  PurchaseOrderDate = prh.DtePurchaseContractDate,
                                                                  DeliveryAddress = prh.StrDeliveryAddress,
                                                                  CurrencyId = prh.IntCurrencyId,
                                                                  CurrencyName = (from t in _contextR.TblCurrency
                                                                                  where t.IntCurrencyId == prh.IntCurrencyId
                                                                                  select t.StrCurrencyName).FirstOrDefault(),
                                                                  PaymentTerms = (long)prh.IntPaymentTerms,
                                                                  PaymentTermsName = (from t in _contextR.TblPaymentTermsFino
                                                                                      where t.IntPaymentTerms == prh.IntPaymentTerms
                                                                                      select t.StrPaymentTermsName).FirstOrDefault(),
                                                                  ValidityDate = (DateTime)prh.DtePcvalidityDate,
                                                                  PurchaseOrganizationId = prh.IntPurchaseOrganizationId,
                                                                  PurchaseOrganizationName = porg.StrPurchaseOrganization,
                                                                  SupplierId = prh.IntBusinessPartnerId,
                                                                  SupplierName = (prh.IntBusinessPartnerId == 0) ? "" : (from i in _contextR.TblBusinessPartner
                                                                                                                         where i.IntBusinessPartnerId == prh.IntBusinessPartnerId
                                                                                                                         select i.StrBusinessPartnerName).FirstOrDefault(),
                                                                  SupplierAddress = (prh.IntBusinessPartnerId == 0) ? "" : (from i in _contextR.TblBusinessPartner
                                                                                                                            where i.IntBusinessPartnerId == prh.IntBusinessPartnerId
                                                                                                                            select i.StrBusinessPartnerAddress).FirstOrDefault(),
                                                                  NumberOfShipments = 0,
                                                              });


                purchaseOrderPasignation itm = new purchaseOrderPasignation();

                if (searchTerm != null)
                {
                    var countss = from t in data
                                  where t.PurchaseOrderNo.ToLower().Contains(searchTerm.ToString().ToLower())
                                  select t;
                    IQueryable<GetPurchaseOrderHeaderDTO> test = countss.AsQueryable();


                    var countQ = data.Count();

                    if (PageNo <= 0)
                        PageNo = 1;
                    var itemdataa = PagingList<GetPurchaseOrderHeaderDTO>.CreateAsync(test, PageNo, PageSize);
                    int indexx = 1;
                    foreach (var itms in itemdataa)
                    {
                        itms.Sl = indexx++;
                    }


                    itm.Data = itemdataa;
                    itm.currentPage = PageNo;
                    itm.totalCount = test.Count();
                    itm.pageSize = PageSize;
                }
                else
                {
                    if (data == null)
                        throw new Exception("Data Not Found.");
                    else
                    {
                        if (viewOrder.ToUpper() == "ASC")
                            data = data.OrderBy(o => o.PurchaseOrderId);
                        else if (viewOrder.ToUpper() == "DESC")
                            data = data.OrderByDescending(o => o.PurchaseOrderId);
                    }

                    if (PageNo <= 0)
                        PageNo = 1;
                    var itemdata = PagingList<GetPurchaseOrderHeaderDTO>.CreateAsync(data, PageNo, PageSize);
                    int index = 1;
                    foreach (var itms in itemdata)
                    {
                        itms.Sl = index++;
                    }

                    itm.Data = itemdata;
                    itm.currentPage = PageNo;
                    itm.totalCount = data.Count();
                    itm.pageSize = PageSize;
                }
                return itm;
            }

            else
            {
                IQueryable<GetPurchaseOrderHeaderDTO> data1 = (from prh in _contextR.TblPurchaseOrderHeader
                                                               join porg in _contextR.TblBusinessUnitPurchaseOrganization on prh.IntPurchaseOrganizationId equals porg.IntPurchaseOrganizationid
                                                               join por in _contextR.TblPurchaseOrderRow on prh.IntPurchaseOrganizationId equals por.IntPurchaseOrderId
                                                               where prh.IntAccountId == AccountId && prh.IntBusinessUnitId == UnitId
                                                               && prh.IntPlantId == Plant && prh.IntSbuid == Sbu && prh.IntWarehouseId == WearHouse
                                                               && prh.IntPurchaseOrderTypeId == PurchaseOrderTypeId && prh.IntPurchaseOrganizationId == PurchaseOrganizationId
                                                               && prh.IntReferenceTypeId == ReferenceTypeId
                                                               && prh.IsActive == true && prh.IntAccountId == porg.IntAccountId && prh.IntBusinessUnitId == porg.IntBusinessUnitId

                                                               select new GetPurchaseOrderHeaderDTO
                                                               {
                                                                   PurchaseOrderId = prh.IntPurchaseOrderId,
                                                                   PurchaseOrderNo = prh.StrPurchaseOrderNo,
                                                                   PurchaseOrderDate = prh.DtePurchaseOrderDate,
                                                                   DeliveryAddress = prh.StrDeliveryAddress,
                                                                   CurrencyId = prh.IntCurrencyId,
                                                                   CurrencyName = (from t in _contextR.TblCurrency
                                                                                   where t.IntCurrencyId == prh.IntCurrencyId
                                                                                   select t.StrCurrencyName).FirstOrDefault(),
                                                                   PaymentTerms = prh.IntPaymentTerms,
                                                                   PaymentTermsName = (from t in _contextR.TblPaymentTermsFino
                                                                                       where t.IntPaymentTerms == prh.IntPaymentTerms
                                                                                       select t.StrPaymentTermsName).FirstOrDefault(),
                                                                   ValidityDate = prh.DtePovalidityDate,
                                                                   PurchaseOrganizationId = prh.IntPurchaseOrganizationId,
                                                                   PurchaseOrganizationName = porg.StrPurchaseOrganization,
                                                                   SupplierId = prh.IntBusinessPartnerId,
                                                                   SupplierName = (prh.IntBusinessPartnerId == 0) ? "" : (from i in _contextR.TblBusinessPartner
                                                                                                                          where i.IntBusinessPartnerId == prh.IntBusinessPartnerId
                                                                                                                          select i.StrBusinessPartnerName).FirstOrDefault(),
                                                                   SupplierAddress = (prh.IntBusinessPartnerId == 0) ? "" : (from i in _contextR.TblBusinessPartner
                                                                                                                             where i.IntBusinessPartnerId == prh.IntBusinessPartnerId
                                                                                                                             select i.StrBusinessPartnerAddress).FirstOrDefault(),
                                                                   NumberOfShipments = 0,
                                                                   IsApprove = prh.IsApproved

                                                               });

                //var countQ = data.Count();

                purchaseOrderPasignation itm = new purchaseOrderPasignation();

                if (searchTerm != null)
                {
                    var countss = from t in data1
                                  where t.SupplierName.ToLower().Contains(searchTerm.ToString().ToLower())
                                  select t;
                    IQueryable<GetPurchaseOrderHeaderDTO> test = countss.AsQueryable();


                    var countQ = data1.Count();

                    if (PageNo <= 0)
                        PageNo = 1;
                    var itemdataa = PagingList<GetPurchaseOrderHeaderDTO>.CreateAsync(test, PageNo, PageSize);
                    int indexx = 1;
                    foreach (var itms in itemdataa)
                    {
                        itms.Sl = indexx++;
                    }


                    itm.Data = itemdataa;
                    itm.currentPage = PageNo;
                    itm.totalCount = test.Count();
                    itm.pageSize = PageSize;
                }
                else
                {
                    if (data1 == null)
                        throw new Exception("Data Not Found.");
                    else
                    {
                        if (viewOrder.ToUpper() == "ASC")
                            data1 = data1.OrderBy(o => o.PurchaseOrderId);
                        else if (viewOrder.ToUpper() == "DESC")
                            data1 = data1.OrderByDescending(o => o.PurchaseOrderId);
                    }

                    if (PageNo <= 0)
                        PageNo = 1;
                    var itemdata = PagingList<GetPurchaseOrderHeaderDTO>.CreateAsync(data1, PageNo, PageSize);
                    int index = 1;
                    foreach (var itms in itemdata)
                    {
                        itms.Sl = index++;
                    }

                    itm.Data = itemdata;
                    itm.currentPage = PageNo;
                    itm.totalCount = data1.Count();
                    itm.pageSize = PageSize;
                }
                return itm;
            }


        }

        public async Task<List<GetSupplierDDLDTO>> GetSupplierDDL(long AccountId, long UnitId)
        {
            var data = await Task.FromResult((from bpp in _contextR.TblBusinessPartnerPurchase
                                              join bp in _contextR.TblBusinessPartner on bpp.IntBusinessPartnerId equals bp.IntBusinessPartnerId
                                              where bpp.IsActive == true && bp.IsActive == true && bpp.IntBusinessUnitId == UnitId && bpp.IntAccountId == AccountId && bp.IntBusinessPartnerTypeId == 1
                                              orderby bp.StrBusinessPartnerName ascending
                                              select new GetSupplierDDLDTO
                                              {
                                                  Value = bpp.IntBusinessPartnerId,
                                                  Label = bp.StrBusinessPartnerName,
                                                  SupplierAddress = bp.StrBusinessPartnerAddress,
                                                  SupplierContact = bp.StrContactNumber

                                              }).ToList());

            return data;

            throw new NotImplementedException();
        }
    }
}






//throw new NotImplementedException();



