﻿using Procurement.DbContexts;
using Procurement.DTO.LandingPasignation;
using Procurement.DTO.PurchaseRequestApproval;
using Procurement.Helper;
using Procurement.IRepository;
using Procurement.Models.Write;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.Repository
{
    public class PurchaseRequestApproval : IPurchaseRequestApproval
    {
        public readonly ReadDbContext _contextR;
        public readonly WriteDbContext _contextW;

        public PurchaseRequestApproval(ReadDbContext contextR, WriteDbContext contextW)
        {
            _contextR = contextR;
            _contextW = contextW;
        }

        public async Task<GetPurchaseRequestApproveLandingPagination> GetPurchaseRequestApproveLandingPagination(long accountId, long businessUnitId, long plantId, long warehouseId, long PageNo, long PageSize, string viewOrder)
        {
            var counts = _contextR.TblPurchaseRequestHeader.Where(x => x.IntAccountId == accountId && x.IntBusinessUnitId == businessUnitId
                                && x.IntPlantId == plantId && x.IntWarehouseId == warehouseId && x.IsApproved == false && x.IsActive == true).Count();

            IQueryable<GetPurchaseReqHeaderAppLandingDTO> data = await Task.FromResult(from prh in _contextR.TblPurchaseRequestHeader
                                                                                       where prh.IntAccountId == accountId && prh.IntBusinessUnitId == businessUnitId && prh.IntPlantId == plantId
                                                                                       && prh.IntWarehouseId == warehouseId && prh.IsApproved == false && prh.IsActive == true
                                                                                       select new GetPurchaseReqHeaderAppLandingDTO
                                                                                       {
                                                                                           PurchaseRequestId = prh.IntPurchaseRequestId,
                                                                                           PurchaseRequestCode = prh.StrPurchaseRequestCode,
                                                                                           ReffNo = prh.StrReffNo,
                                                                                           PurchaseRequestTypeName = prh.StrPurchaseRequestTypeName,
                                                                                           Sbuname = prh.StrSbuname,
                                                                                           PurchaseOrganizationName = prh.StrPurchaseOrganizationName,
                                                                                           PlantName = prh.StrPlantName,
                                                                                           WarehouseName = prh.StrWarehouseName,
                                                                                           DeliveryAddress = prh.StrDeliveryAddress,
                                                                                           //SupplyingWarehouseName = prh.StrSupplyingWarehouseName,
                                                                                           RequestDate = prh.DteRequestDate,
                                                                                           IsActive = prh.IsActive
                                                                                       });
            if (data == null)
                throw new Exception("Purchase Request Approval Not Found.");
            else
            {
                if (viewOrder.ToUpper() == "ASC")
                    data = data.OrderBy(o => o.PurchaseRequestId);
                else if (viewOrder.ToUpper() == "DESC")
                    data = data.OrderByDescending(o => o.PurchaseRequestId);
            }

            if (PageNo <= 0)
                PageNo = 1;
            var getData = PagingList<GetPurchaseReqHeaderAppLandingDTO>.CreateAsync(data, PageNo, PageSize);
            long index = 1;
            foreach (var oData in getData)
                oData.Sl = index++;

            GetPurchaseRequestApproveLandingPagination objInfo = new GetPurchaseRequestApproveLandingPagination();
            objInfo.Data = getData;
            objInfo.currentPage = PageNo;
            objInfo.totalCount = counts;
            objInfo.pageSize = PageSize;

            return objInfo;
        }

        public async Task<List<GetPurchaseRequestHeaderAppDTO>> GetPurchaseRequestApproveList(long accountId, long businessUnitId, long plantId, long warehouseId)
        {

            var data = await Task.FromResult((from prh in _contextR.TblPurchaseRequestHeader
                                              where prh.IntAccountId == accountId && prh.IntBusinessUnitId == businessUnitId && prh.IntPlantId == plantId
                                              && prh.IntWarehouseId == warehouseId && prh.IsApproved == false && prh.IsActive == true
                                              orderby prh.IntPurchaseRequestId ascending
                                              select new GetPurchaseRequestHeaderAppDTO
                                              {
                                                  PurchaseRequestId = prh.IntPurchaseRequestId,
                                                  PurchaseRequestCode = prh.StrPurchaseRequestCode,
                                                  ReffNo = prh.StrReffNo,
                                                  PurchaseRequestTypeId = prh.IntPurchaseRequestTypeId,
                                                  PurchaseRequestTypeName = prh.StrPurchaseRequestTypeName,
                                                  AccountId = prh.IntAccountId,
                                                  AccountName = prh.StrAccountName,
                                                  BusinessUnitId = prh.IntBusinessUnitId,
                                                  BusinessUnitName = prh.StrBusinessUnitName,
                                                  Sbuid = prh.IntSbuid,
                                                  Sbuname = prh.StrSbuname,
                                                  PurchaseOrganizationId = prh.IntPurchaseOrganizationId,
                                                  PurchaseOrganizationName = prh.StrPurchaseOrganizationName,
                                                  PlantId = prh.IntPlantId,
                                                  PlantName = prh.StrPlantName,
                                                  WarehouseId = prh.IntWarehouseId,
                                                  WarehouseName = prh.StrWarehouseName,
                                                  DeliveryAddress = prh.StrDeliveryAddress,
                                                  SupplyingWarehouseId = prh.IntSupplyingWarehouseId,
                                                  SupplyingWarehouseName = prh.StrSupplyingWarehouseName,
                                                  RequestDate = prh.DteRequestDate,
                                                  IsApproved = prh.IsApproved,
                                                  ApprovedBy = prh.IntApprovedBy,
                                                  ApprovedByName = prh.StrApprovedBy,
                                                  ApprovedDateTime = prh.DteApprovedDateTime,
                                                  IsComplete = prh.IsComplete,
                                                  IsClosed = prh.IsClosed,
                                                  ClosedBy = prh.IntClosedBy,
                                                  ClosedByName = prh.StrClosedBy,
                                                  ClosedDateTime = prh.DteClosedDateTime,
                                                  ActionBy = prh.IntActionBy,
                                                  IsActive = prh.IsActive
                                              }).ToList());
            if (data == null)
                throw new Exception("Purchase Request Approval Not Found.");

            long index = 1;
            foreach (var oData in data)
                oData.Sl = index++;

            return data;
        }

        public async Task<GetPurchaseRequestApproveCommonDTO> GetPurchaseRequestInformationByRequestId(long PurchaseRequestId)
        {
            try
            {
                GetPurchaseRequestApproveCommonDTO objData = new GetPurchaseRequestApproveCommonDTO();

                objData.objHeaderDTO = await Task.FromResult((from prh in _contextR.TblPurchaseRequestHeader
                                                              where prh.IsActive == true && prh.IntPurchaseRequestId == PurchaseRequestId
                                                              select new GetPurchaseRequestHeaderAppDTO
                                                              {
                                                                  PurchaseRequestId = prh.IntPurchaseRequestId,
                                                                  PurchaseRequestCode = prh.StrPurchaseRequestCode,
                                                                  ReffNo = prh.StrReffNo,
                                                                  PurchaseRequestTypeId = prh.IntPurchaseRequestTypeId,
                                                                  PurchaseRequestTypeName = prh.StrPurchaseRequestTypeName,
                                                                  AccountId = prh.IntAccountId,
                                                                  AccountName = prh.StrAccountName,
                                                                  BusinessUnitId = prh.IntBusinessUnitId,
                                                                  BusinessUnitName = prh.StrBusinessUnitName,
                                                                  Sbuid = prh.IntSbuid,
                                                                  Sbuname = prh.StrSbuname,
                                                                  PurchaseOrganizationId = prh.IntPurchaseOrganizationId,
                                                                  PurchaseOrganizationName = prh.StrPurchaseOrganizationName,
                                                                  PlantId = prh.IntPlantId,
                                                                  PlantName = prh.StrPlantName,
                                                                  WarehouseId = prh.IntWarehouseId,
                                                                  WarehouseName = prh.StrWarehouseName,
                                                                  DeliveryAddress = prh.StrDeliveryAddress,
                                                                  SupplyingWarehouseId = prh.IntSupplyingWarehouseId,
                                                                  SupplyingWarehouseName = prh.StrSupplyingWarehouseName,
                                                                  RequestDate = prh.DteRequestDate,
                                                                  IsApproved = prh.IsApproved,
                                                                  ApprovedBy = prh.IntApprovedBy,
                                                                  ApprovedByName = prh.StrApprovedBy,
                                                                  ApprovedDateTime = prh.DteApprovedDateTime,
                                                                  IsComplete = prh.IsComplete,
                                                                  IsClosed = prh.IsClosed,
                                                                  ClosedBy = prh.IntClosedBy,
                                                                  ClosedByName = prh.StrClosedBy,
                                                                  ClosedDateTime = prh.DteClosedDateTime,
                                                                  ActionBy = prh.IntActionBy,
                                                                  IsActive = prh.IsActive
                                                              }).FirstOrDefault());

                objData.objRowListDTO = await Task.FromResult((from t in _contextR.TblPurchaseRequestRow
                                                               where t.IntPurchaseRequestId == PurchaseRequestId
                                                               select new GetPurchaseRequestRowAppDTO
                                                               {
                                                                   RowId = t.IntRowId,
                                                                   PurchaseRequestId = t.IntPurchaseRequestId,
                                                                   PurchaseRequestCode  = t.StrPurchaseRequestCode,
                                                                   ItemId = t.IntItemId,
                                                                   ItemName = t.StrItemName,
                                                                   ItemCode = t.StrItemCode,
                                                                   UoMid = t.IntUoMid,
                                                                   UoMname = t.StrUoMname,
                                                                   NumRequestQuantity = t.NumRequestQuantity,
                                                                   NumApprovedQuantity = t.NumApprovedQuantity,
                                                                   NumRfqquantity = t.NumRfqquantity,
                                                                   NumPurchaseOrderQuantity = t.NumPurchaseOrderQuantity,
                                                                   DteRequiredDate = t.DteRequiredDate,
                                                                   CostElementId = t.IntCostElementId,
                                                                   CostElementName = t.StrCostElementName,
                                                                   BillOfMaterialId = t.IntBillOfMaterialId,
                                                                   Remarks = t.StrRemarks
                                                               }).ToList());


                if (objData == null)
                    throw new Exception("Purchase Request Information Not Exist in Database");

                //List<GetPurchaseRequestApproveCommonDTO> objListData = new List<GetPurchaseRequestApproveCommonDTO>();
                //objListData.Add(objData);

                return objData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<MessageHelper> EditPurchaseRequestApprove(EditPurchaseRequestApproveCommonDTO editPurchaseRequestCommonDTO)
        {
            try
            {
                TblPurchaseRequestHeader dataParent = _contextW.TblPurchaseRequestHeader.First(x => x.IntPurchaseRequestId == editPurchaseRequestCommonDTO.objEditHeaderDTO.PurchaseRequestId);
                
                if (editPurchaseRequestCommonDTO.objEditHeaderDTO.IsApproved == true)
                {
                    dataParent.IsApproved = editPurchaseRequestCommonDTO.objEditHeaderDTO.IsApproved;
                    dataParent.IntApprovedBy = editPurchaseRequestCommonDTO.objEditHeaderDTO.ApprovedBy;
                    dataParent.StrApprovedBy = editPurchaseRequestCommonDTO.objEditHeaderDTO.ApprovedByName;
                    dataParent.DteApprovedDateTime = DateTime.UtcNow;
                    dataParent.IntActionBy = editPurchaseRequestCommonDTO.objEditHeaderDTO.ActionBy;

                    _contextW.TblPurchaseRequestHeader.Update(dataParent);
                    await _contextW.SaveChangesAsync();
                }
                var removeDataList = (from a in _contextW.TblPurchaseRequestRow
                                      where a.IntPurchaseRequestId == dataParent.IntPurchaseRequestId
                                      select a).ToList();

                _contextW.TblPurchaseRequestRow.RemoveRange(removeDataList);
                await _contextW.SaveChangesAsync();

                var mRows = new List<TblPurchaseRequestRow>(editPurchaseRequestCommonDTO.objListRowD.Count);

                foreach (var datas in editPurchaseRequestCommonDTO.objListRowD)
                {
                    var detalisrow = new TblPurchaseRequestRow { };
                    detalisrow.IntPurchaseRequestId = dataParent.IntPurchaseRequestId;
                    detalisrow.StrPurchaseRequestCode = dataParent.StrPurchaseRequestCode;
                    detalisrow.IntItemId = datas.ItemId;
                    detalisrow.StrItemName = datas.ItemName;
                    detalisrow.StrItemCode = datas.ItemCode;
                    detalisrow.IntUoMid = datas.UoMid;
                    detalisrow.StrUoMname = datas.UoMname;
                    detalisrow.NumRequestQuantity = datas.NumRequestQuantity;
                    detalisrow.NumApprovedQuantity = datas.NumApprovedQuantity;
                    detalisrow.NumRfqquantity = datas.NumRfqquantity;
                    detalisrow.NumPurchaseOrderQuantity = datas.NumPurchaseOrderQuantity;
                    detalisrow.DteRequiredDate = datas.DteRequiredDate;
                    detalisrow.IntCostElementId = datas.CostElementId;
                    detalisrow.StrCostElementName = datas.CostElementName;
                    detalisrow.IntBillOfMaterialId = datas.BillOfMaterialId;
                    detalisrow.StrRemarks = datas.Remarks;

                    mRows.Add(detalisrow);
                }

                await _contextW.TblPurchaseRequestRow.AddRangeAsync(mRows);
                await _contextW.SaveChangesAsync();

                var msg = new MessageHelper();
                msg.Message = "Processing";
                msg.statuscode = 200;
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<MessageHelper> UpdateStatusPurchaseRequestApprove(UpdateStatusPurchaseRequestHeaderApprDTO objDTO)
        {
            try
            {
                TblPurchaseRequestHeader dataParent = _contextW.TblPurchaseRequestHeader.First(x => x.IntPurchaseRequestId == objDTO.PurchaseRequestId);

                dataParent.IsActive = objDTO.IsActive;
                dataParent.IntActionBy = objDTO.ActionBy;
                dataParent.DteLastActionDateTime = DateTime.UtcNow;

                _contextW.TblPurchaseRequestHeader.Update(dataParent);
                await _contextW.SaveChangesAsync();

                var msg = new MessageHelper();
                msg.Message = "Processing";
                msg.statuscode = 200;
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
