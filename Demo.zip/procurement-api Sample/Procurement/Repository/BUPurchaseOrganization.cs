﻿using Procurement.DbContexts;
using Procurement.DTO.BusinessUnitPurchaseOrganization;
using Procurement.Helper;
using Procurement.IRepository;
using Procurement.Models.Write;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.Repository
{
    public class BUPurchaseOrganization : IBUPurchaseOrganization
    {
        public readonly ReadDbContext _contextR;
        public readonly WriteDbContext _contextW;

        public BUPurchaseOrganization(ReadDbContext contextR, WriteDbContext contextW)
        {
            _contextR = contextR;
            _contextW = contextW;
        }

        public async Task<MessageHelper> CreateBusinessUnitPurchaseOrganization(CreateBusinessUnitPurchaseOrganizationDTO objCreateBUPO)
        {
            try
            {
                var result = _contextW.TblBusinessUnitPurchaseOrganization.Where(x => x.IntBusinessUnitId == objCreateBUPO.BusinessUnit
                                    && x.IntAccountId == objCreateBUPO.AccountId && x.IntPurchaseOrganizationid == objCreateBUPO.PurchaseOrganizationid
                                    && x.IsActive == true).FirstOrDefault();

                if (result != null)
                    throw new Exception("Already Exist Business Unit Purchase Organization.");

                var detalis = new TblBusinessUnitPurchaseOrganization
                {
                    IntAccountId = objCreateBUPO.AccountId,
                    IntBusinessUnitId = objCreateBUPO.BusinessUnit,
                    StrBusinessUnitName = objCreateBUPO.BusinessUnitName,
                    StrAccountName = objCreateBUPO.AccountName,
                    IntPurchaseOrganizationid = objCreateBUPO.PurchaseOrganizationid,
                    StrPurchaseOrganization = objCreateBUPO.PurchaseOrganization,
                    IntActionBy = objCreateBUPO.ActionBy,
                    DteLastActionDateTime = DateTime.UtcNow,
                    IsActive = true
                };
                await _contextW.TblBusinessUnitPurchaseOrganization.AddAsync(detalis);
                await _contextW.SaveChangesAsync();

                var msg = new MessageHelper();
                msg.Message = "Processing";
                msg.statuscode = 200;
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<MessageHelper> EditBusinessUnitPurchaseOrganization(EditBusinessUnitPurchaseOrganizationDTO objEditBUPO)
        {
            try
            {
                var msg = new MessageHelper();

                TblBusinessUnitPurchaseOrganization detalisrow = _contextW.TblBusinessUnitPurchaseOrganization.First(x => x.IntConfigId == objEditBUPO.ConfigId && x.IsActive == true);

                var result = _contextW.TblBusinessUnitPurchaseOrganization.Where(x => x.IntBusinessUnitId == detalisrow.IntBusinessUnitId
                                    && x.IntAccountId == detalisrow.IntAccountId && x.IntPurchaseOrganizationid == objEditBUPO.PurchaseOrganizationid
                                    && x.IntConfigId != objEditBUPO.ConfigId && x.IsActive == true).FirstOrDefault();

                if (result == null)
                {
                    detalisrow.IntPurchaseOrganizationid = objEditBUPO.PurchaseOrganizationid;
                    detalisrow.StrPurchaseOrganization = objEditBUPO.PurchaseOrganization;
                    detalisrow.IntActionBy = objEditBUPO.ActionBy;
                    detalisrow.DteLastActionDateTime = DateTime.UtcNow;

                    _contextW.TblBusinessUnitPurchaseOrganization.Update(detalisrow);
                    await _contextW.SaveChangesAsync();
                }
                else
                    throw new Exception("Already Exist Business Unit Purchase Organization.");

                msg.Message = "Processing";
                msg.statuscode = 200;
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public async Task<List<GetBusinessUnitPurchaseOrganizationDTO>> GetBUPurchaseOrganizationById(long ConfigID)
        {
            var data = await Task.FromResult((from c in _contextR.TblBusinessUnitPurchaseOrganization
                                              where c.IsActive == true && c.IntConfigId == ConfigID
                                              select new GetBusinessUnitPurchaseOrganizationDTO
                                              {
                                                  ConfigId = c.IntConfigId,
                                                  AccountId = c.IntAccountId,
                                                  BusinessUnit = c.IntBusinessUnitId,
                                                  BusinessUnitName = c.StrBusinessUnitName,
                                                  AccountName = c.StrAccountName,
                                                  PurchaseOrganizationid = c.IntPurchaseOrganizationid,
                                                  PurchaseOrganization = c.StrPurchaseOrganization,
                                                  IsActive = c.IsActive
                                              }).ToList());
            if (data == null)
                throw new Exception("BU Purchase Organization Information Not Found.");

            return data;
        }
        public async Task<List<GetBusinessUnitPurchaseOrganizationDTO>> GetBUPurchaseOrganization(long AccountId, long BusinessUnitId)
        {
            var data = await Task.FromResult((from c in _contextR.TblBusinessUnitPurchaseOrganization
                                              where c.IsActive == true && c.IntAccountId == AccountId && c.IntBusinessUnitId== BusinessUnitId
                                              select new GetBusinessUnitPurchaseOrganizationDTO
                                              {
                                                  ConfigId = c.IntConfigId,
                                                  AccountId = c.IntAccountId,
                                                  BusinessUnit = c.IntBusinessUnitId,
                                                  BusinessUnitName = c.StrBusinessUnitName,
                                                  AccountName = c.StrAccountName,
                                                  PurchaseOrganizationid = c.IntPurchaseOrganizationid,
                                                  PurchaseOrganization = c.StrPurchaseOrganization,
                                                  IsActive = c.IsActive
                                              }).ToList());
            if (data == null)
                throw new Exception("BU Purchase Organization Information Not Found.");

            return data;
        }

        public async Task<List<CommonDDLDTO>> GetBUPurchaseOrganizationDDL (long AccountId, long BusinessUnitId)
        { 
            var data = await Task.FromResult((from c in _contextR.TblBusinessUnitPurchaseOrganization
                                              where c.IsActive == true && c.IntAccountId == AccountId  && c.IntBusinessUnitId == BusinessUnitId
                                              select new CommonDDLDTO
                                              {
                                                  Value= c.IntPurchaseOrganizationid,
                                                  Label = c.StrPurchaseOrganization,
                                              }).ToList());

            if (data == null)
                throw new Exception("BU Purchase Organization Information Not Found.");

            return data;
        }

        public async Task<GetBUPurchaseOrganizationPaginationDTO> GetBUPurchaseOrganizationLandingPagination(long AccountId, long BusinessUnitId, bool status, long PageNo, long PageSize, string viewOrder)
        {
            var counts = _contextR.TblBusinessUnitPurchaseOrganization.Where(x => x.IntAccountId == AccountId && x.IntBusinessUnitId == BusinessUnitId && x.IsActive == status).Count();

            IQueryable<GetBusinessUnitPurchaseOrganizationDTO> data = await Task.FromResult(from c in _contextR.TblBusinessUnitPurchaseOrganization
                                                                                             where c.IsActive == status && c.IntAccountId == AccountId 
                                                                                             && c.IntBusinessUnitId == BusinessUnitId
                                                                                             select new GetBusinessUnitPurchaseOrganizationDTO
                                                                                             {
                                                                                                 ConfigId = c.IntConfigId,
                                                                                                 AccountId = c.IntAccountId,
                                                                                                 BusinessUnit = c.IntBusinessUnitId,
                                                                                                 BusinessUnitName = c.StrBusinessUnitName,
                                                                                                 AccountName = c.StrAccountName,
                                                                                                 PurchaseOrganizationid = c.IntPurchaseOrganizationid,
                                                                                                 PurchaseOrganization = c.StrPurchaseOrganization,
                                                                                                 IsActive = c.IsActive
                                                                                             });
            if (data == null)
                throw new Exception("BU GL Purchase Organization Not Found.");
            else
            {
                if (viewOrder.ToUpper() == "ASC")
                    data = data.OrderBy(o => o.ConfigId);
                else if (viewOrder.ToUpper() == "DESC")
                    data = data.OrderByDescending(o => o.ConfigId);
            }

            if (PageNo <= 0)
                PageNo = 1;
            var getData = PagingList<GetBusinessUnitPurchaseOrganizationDTO>.CreateAsync(data, PageNo, PageSize);

            long index = 1;
            foreach (var oData in getData)
                oData.Sl = index++;

            GetBUPurchaseOrganizationPaginationDTO objInfo = new GetBUPurchaseOrganizationPaginationDTO();

            objInfo.Data = getData;
            objInfo.currentPage = PageNo;
            objInfo.totalCount = counts;
            objInfo.pageSize = PageSize;

            return objInfo;
        }

        public async Task<MessageHelper> UpdateStatusBUPurchaseOrganization(UpdateStatusBUPurchaseOrganizationDTO objUpdateStatusBUPO)
        {
            try
            {
                var msg = new MessageHelper();

                TblBusinessUnitPurchaseOrganization detalisrow = _contextW.TblBusinessUnitPurchaseOrganization.First(x => x.IntConfigId == objUpdateStatusBUPO.ConfigId && x.IsActive == true);

                detalisrow.IsActive = objUpdateStatusBUPO.IsActive;
                detalisrow.IntActionBy = objUpdateStatusBUPO.ActionBy;
                detalisrow.DteLastActionDateTime = DateTime.UtcNow;

                _contextW.TblBusinessUnitPurchaseOrganization.Update(detalisrow);
                await _contextW.SaveChangesAsync();

                msg.Message = "Processing";
                msg.statuscode = 200;
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
