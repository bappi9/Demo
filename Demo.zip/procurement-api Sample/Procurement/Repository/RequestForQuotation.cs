﻿using Microsoft.CodeAnalysis.CSharp.Syntax;
using Procurement.DbContexts;
using Procurement.DTO;
using Procurement.DTO.LandingPasignation;
using Procurement.DTO.RequestForQuotation;
using Procurement.DTO.RequestForQuotation.RFQEdit;
using Procurement.DTO.RequestForQuotation.RFQEntryPage;
using Procurement.Helper;
using Procurement.IRepository;
using Procurement.Models.Read;
using Procurement.Models.Write;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;

namespace Procurement.Repository
{
    public class RequestForQuotation : IRequestForQuotation
    {
        public readonly ReadDbContext _contextR;
        public readonly WriteDbContext _contextW;

        public RequestForQuotation(ReadDbContext contextR, WriteDbContext contextW)
        {
            _contextR = contextR;
            _contextW = contextW;
        }

        public async Task<MessageHelper> CreateRequestForQuotation(CreateRequestForQuotationCommonDTO objRFQ)
        {
           // TblBusinessPartnerRequestForQuotationHeader quaHeader = new TblBusinessPartnerRequestForQuotationHeader();

            var qheader = new Models.Write.TblRequestForQuotationHeader
            {
                StrRequestForQuotationCode = string.Concat("RFQ-", objRFQ.objHeader.AccountId.ToString(),"-", objRFQ.objHeader.BusinessUnitId.ToString(),"-", DateTime.Now.ToString("yyyyMMddHHmmss")),
                DteRfqdate = objRFQ.objHeader.Rfqdate,
                IntAccountId = objRFQ.objHeader.AccountId,
                StrAccountName = objRFQ.objHeader.AccountName,
                IntBusinessUnitId = objRFQ.objHeader.BusinessUnitId,
                StrBusinessUnitName = objRFQ.objHeader.BusinessUnitName,
                IntSbuid = objRFQ.objHeader.Sbuid,
                StrSbuname = objRFQ.objHeader.Sbuname,
                IntPurchaseOrganizationId = objRFQ.objHeader.PurchaseOrganizationId,
                StrPurchaseOrganizationName = objRFQ.objHeader.PurchaseOrganizationName,
                IntPlantId = objRFQ.objHeader.PlantId,
                StrPlantName = objRFQ.objHeader.PlantName,
                IntWarehouseId = objRFQ.objHeader.WarehouseId,
                StrWarehouseName = objRFQ.objHeader.WarehouseName,
                IntRequestTypeId = objRFQ.objHeader.RequestTypeId,
                StrRequestTypeName = objRFQ.objHeader.RequestTypeName,
                StrReferenceTypeName = objRFQ.objHeader.ReferenceTypeName,
                IntCurrencyId = objRFQ.objHeader.CurrencyId,
                StrCurrencyCode = (from c in _contextR.TblCurrency where c.IntCurrencyId == objRFQ.objHeader.CurrencyId select c.StrCurrencyCode).FirstOrDefault(),
                DteValidTillDate =objRFQ.objHeader.ValidTillDate,
                IsApproved = false,
                IntApprovedBy = -1,
                StrApprovedBy = "",
                DteApprovedDateTime = DateTime.UtcNow,
                IntActionBy = objRFQ.objHeader.ActionBy,
                DteLastActionDateTime = DateTime.UtcNow,
                IsActive = true
            };

            _contextW.TblRequestForQuotationHeader.Add(qheader);
            _contextW.SaveChanges();

            var rfqRow = new List<Models.Write.TblRequestForQuotationRow>(objRFQ.objRow.Count);

            foreach (var datas in objRFQ.objRow)
            {
                var qrow = new Models.Write.TblRequestForQuotationRow { };
                qrow.IntRequestForQuotationId = qheader.IntRequestForQuotationId;
                qrow.StrRequestForQuotationCode = qheader.StrRequestForQuotationCode;
                qrow.IntItemId = datas.ItemId;
                qrow.StrItemCode = datas.ItemCode;
                qrow.StrItemName = datas.ItemName;
                qrow.IntUoMid = datas.UoMid;
                qrow.StrUoMname = datas.UoMname;
                qrow.NumRfqquantity = datas.Reqquantity;
                qrow.IntReferenceId = datas.ReferenceId;
                qrow.StrReferenceCode = datas.ReferenceCode;
                qrow.NumReferenceQuantity = datas.ReferenceQuantity;
                qrow.StrDescription = datas.Description;

                rfqRow.Add(qrow);
            }
            _contextW.TblRequestForQuotationRow.AddRange(rfqRow);
            _contextW.SaveChanges();


            foreach (var sup in objRFQ.SupplierRow)
            {
                var supqheader = new Models.Write.TblBusinessPartnerRequestForQuotationHeader
                {
                    IntRequestForQuotationId = qheader.IntRequestForQuotationId,
                    StrRequestForQuotationCode = qheader.StrRequestForQuotationCode,
                    IntAccountId = qheader.IntAccountId,
                    IntBusinessUnitId = qheader.IntBusinessUnitId,
                    IntBusinessPartnerId = sup.BusinessPartnerId,
                    StrBusinessPartnerName = sup.BusinessPartnerName,
                    StrBusinessPartnerAddress = sup.BusinessPartnerAddress,
                    StrBusinessPartnerCode = "",
                    StrSupplierRefNo = "",
                    DteSupplierRefDate = DateTime.UtcNow,
                    StrEmail = sup.Email,
                    StrContactNumber = sup.ContactNumber,
                    DteIssueDate = DateTime.UtcNow,
                    DteReleaseDate = DateTime.UtcNow,
                    StrDocAttachmentLink = "",
                    IsQuotationReceived = false,
                    IsEmailSend = sup.IsEmailSend ,
                    IntLastActionBy = qheader.IntActionBy,
                    DteLastActionDateTime = DateTime.UtcNow,
                    IsActive = true
                };
                _contextW.TblBusinessPartnerRequestForQuotationHeader.Add(supqheader);
                _contextW.SaveChanges();

                var supplierRow = new List<Models.Write.TblBusinessPartnerRequestForQuotationRow>(objRFQ.objRow.Count);

                foreach (var suprow in objRFQ.objRow)
                {
                    var suprowlist = new Models.Write.TblBusinessPartnerRequestForQuotationRow { };
                    suprowlist.IntPartnerRfqid = supqheader.IntPartnerRfqid;
                    suprowlist.IntItemId = suprow.ItemId;
                    suprowlist.StrItemCode = suprow.ItemCode;
                    suprowlist.StrItemName = suprow.ItemName;
                    suprowlist.IntUoMid = suprow.UoMid;
                    suprowlist.StrUoMname = suprow.UoMname;
                    suprowlist.NumRequestQuantity = suprow.Reqquantity;
                    suprowlist.NumRate =0;
                    suprowlist.NumValue = 0;
                    suprowlist.IsSelected = false;
                    suprowlist.StrSelectionComments = "";
                    suprowlist.StrRemarks = suprow.Description;
                    suprowlist.IntActionBy = qheader.IntActionBy;
                    suprowlist.DteLastActionDateTime = DateTime.UtcNow;
                    suprowlist.IsActive = true;

                    supplierRow.Add(suprowlist);

                }
                _contextW.TblBusinessPartnerRequestForQuotationRow.AddRange(supplierRow);
                _contextW.SaveChanges();
            }

            var msg = new MessageHelper();
            msg.Message = "Create Successfully.";
            msg.statuscode = 200;
            return msg;
        }

        public async Task<MessageHelper> EditRequestForQuotation(RFQEditCommonDTO objRFQ)
        {
            //throw new NotImplementedException();
            try
            {

                var msg = new MessageHelper();
                var result = _contextW.TblRequestForQuotationHeader.Where(x => x.IntRequestForQuotationId == objRFQ.objHeader.RequestForQuotationId
                            && x.IntBusinessUnitId == objRFQ.objHeader.BusinessUnitId && x.IntAccountId == objRFQ.objHeader.AccountId
                            && x.IsActive == true).FirstOrDefault();
                if (result != null)
                {
                    Models.Write.TblRequestForQuotationHeader detalisrow = _contextW.TblRequestForQuotationHeader.First(x => x.IntRequestForQuotationId == objRFQ.objHeader.RequestForQuotationId);

                    detalisrow.IntRequestTypeId = objRFQ.objHeader.RequestTypeId;
                    detalisrow.StrRequestTypeName = objRFQ.objHeader.RequestTypeName;
                    detalisrow.IntActionBy = objRFQ.objHeader.ActionBy;
                    detalisrow.DteLastActionDateTime = DateTime.UtcNow;

                    _contextW.TblRequestForQuotationHeader.Update(detalisrow);
                    await _contextW.SaveChangesAsync();

                    
                    var rfqRow = new List<Models.Write.TblRequestForQuotationRow>(objRFQ.objRow.Count);
                    var innerquery = from c in objRFQ.objRow
                                     where c.RowId > 0
                                     select c.RowId;
                    var inactiveItems = (from p in _contextW.TblRequestForQuotationRow
                                         where p.IntRequestForQuotationId == objRFQ.objHeader.RequestForQuotationId && !innerquery.Contains(p.IntRowId)
                                         select p).ToList();
                    foreach (var a in inactiveItems)
                    {
                        a.IsActive = false;
                    }

                    _contextW.TblRequestForQuotationRow.UpdateRange(inactiveItems);
                    await _contextW.SaveChangesAsync();


                    foreach (var datas in objRFQ.objRow)
                    {
                        if(datas.RowId == 0)
                        {
                            var qrow = new Models.Write.TblRequestForQuotationRow { };
                            qrow.IntRequestForQuotationId = detalisrow.IntRequestForQuotationId;
                            qrow.StrRequestForQuotationCode = detalisrow.StrRequestForQuotationCode;
                            qrow.IntItemId = datas.ItemId;
                            qrow.StrItemCode = datas.ItemCode;
                            qrow.StrItemName = datas.ItemName;
                            qrow.IntUoMid = datas.UoMid;
                            qrow.StrUoMname = datas.UoMname;
                            qrow.NumRfqquantity = datas.NumRfqquantity;
                            qrow.IntReferenceId = datas.ReferenceId;
                            qrow.StrReferenceCode = datas.ReferenceCode;
                            qrow.NumReferenceQuantity = datas.NumReferenceQuantity;
                            qrow.StrDescription = datas.Description;
                            qrow.IsActive = datas.IsActive;

                            rfqRow.Add(qrow);
                        }
                        else if(datas.RowId > 0)
                        {
                            Models.Write.TblRequestForQuotationRow detalisrfqrow = _contextW.TblRequestForQuotationRow.First(x => x.IntRowId == datas.RowId);

                            detalisrfqrow.IntUoMid = datas.UoMid;
                            detalisrfqrow.StrUoMname = datas.UoMname;
                            detalisrfqrow.NumRfqquantity = datas.NumRfqquantity;
                            detalisrfqrow.StrDescription = datas.Description;

                            _contextW.TblRequestForQuotationRow.Update(detalisrfqrow);
                            await _contextW.SaveChangesAsync();
                        }
                    }
                   
                    if (rfqRow.Count > 0)
                    {
                        await _contextW.TblRequestForQuotationRow.AddRangeAsync(rfqRow);
                        await _contextW.SaveChangesAsync();
                    }


                    var innerqueryy = from c in objRFQ.objSuppliers
                                      where c.PartnerRfqid > 0
                                      select c.PartnerRfqid;
                    var inactiveItemss = (from p in _contextW.TblBusinessPartnerRequestForQuotationHeader
                                          where p.IntRequestForQuotationId == objRFQ.objHeader.RequestForQuotationId && !innerqueryy.Contains(p.IntPartnerRfqid)
                                          select p).ToList();
                    foreach (var a in inactiveItemss)
                    {
                        a.IsActive = false;
                    }

                    _contextW.TblBusinessPartnerRequestForQuotationHeader.UpdateRange(inactiveItemss);
                    await _contextW.SaveChangesAsync();

                    foreach (var sup in objRFQ.objSuppliers)
                    {
                        if (sup.PartnerRfqid == 0)
                        {
                            var supqheader = new Models.Write.TblBusinessPartnerRequestForQuotationHeader();
                            supqheader.IntRequestForQuotationId = detalisrow.IntRequestForQuotationId;
                            supqheader.StrRequestForQuotationCode = detalisrow.StrRequestForQuotationCode;
                            supqheader.IntAccountId = detalisrow.IntAccountId;
                            supqheader.IntBusinessUnitId = detalisrow.IntBusinessUnitId;
                            supqheader.IntBusinessPartnerId = sup.BusinessPartnerId;
                            supqheader.StrBusinessPartnerName = sup.BusinessPartnerName;
                            supqheader.StrBusinessPartnerAddress = sup.BusinessPartnerAddress;
                            supqheader.StrBusinessPartnerCode = "";
                            supqheader.StrSupplierRefNo = "";
                            supqheader.DteSupplierRefDate = DateTime.UtcNow;
                            supqheader.StrEmail = sup.Email;
                            supqheader.StrContactNumber = sup.ContactNumber;
                            supqheader.DteIssueDate = DateTime.UtcNow;
                            supqheader.DteReleaseDate = DateTime.UtcNow;
                            supqheader.StrDocAttachmentLink = "";
                            supqheader.IsQuotationReceived = false;
                            supqheader.IsEmailSend = sup.IsEmailSend;
                            supqheader.IntLastActionBy = detalisrow.IntActionBy;
                            supqheader.DteLastActionDateTime = DateTime.UtcNow;
                            supqheader.IsActive = true;

                            _contextW.TblBusinessPartnerRequestForQuotationHeader.Add(supqheader);
                            _contextW.SaveChanges();


                            var supplierRow = new List<Models.Write.TblBusinessPartnerRequestForQuotationRow>(objRFQ.objRow.Count);

                            foreach (var suprow in objRFQ.objRow)
                            {
                                var suprowlist = new Models.Write.TblBusinessPartnerRequestForQuotationRow { };
                                suprowlist.IntPartnerRfqid = supqheader.IntPartnerRfqid;
                                suprowlist.IntItemId = suprow.ItemId;
                                suprowlist.StrItemCode = suprow.ItemCode;
                                suprowlist.StrItemName = suprow.ItemName;
                                suprowlist.IntUoMid = suprow.UoMid;
                                suprowlist.StrUoMname = suprow.UoMname;
                                suprowlist.NumRequestQuantity = suprow.NumRfqquantity;
                                suprowlist.NumRate = 0;
                                suprowlist.NumValue = 0;
                                suprowlist.IsSelected = false;
                                suprowlist.StrSelectionComments = "";
                                suprowlist.StrRemarks = suprow.Description;
                                suprowlist.IntActionBy = detalisrow.IntActionBy;
                                suprowlist.DteLastActionDateTime = DateTime.UtcNow;
                                suprowlist.IsActive = true;

                                supplierRow.Add(suprowlist);

                            }
                            _contextW.TblBusinessPartnerRequestForQuotationRow.AddRange(supplierRow);
                            _contextW.SaveChanges();
                        }

                    }

                    msg.Message = "Successfully.";
                    msg.statuscode = 200;
                    
                }
                else
                    throw new Exception(" Request For Quotation not found .");

                return msg;
            }
            catch(Exception ex)
            {
                throw ex;
            }

        }
        public async Task<MessageHelper> CreateRFQEntryPage(CreateCommonRFQEntryPage postRFQ)
        {
            Models.Write.TblBusinessPartnerRequestForQuotationHeader qheader = _contextW.TblBusinessPartnerRequestForQuotationHeader.FirstOrDefault(X => X.IntPartnerRfqid == postRFQ.objHeader.PartnerRFQId);

            qheader.IntRequestForQuotationId = postRFQ.objHeader.RequestForQuotationId; 
            qheader.IntAccountId = postRFQ.objHeader.AccountId;
            qheader.IntBusinessUnitId = postRFQ.objHeader.BusinessUnitId;
            qheader.IntBusinessPartnerId = postRFQ.objHeader.BusinessPartnerId;
            qheader.StrSupplierRefNo = postRFQ.objHeader.SupplierRefNo;
            qheader.DteSupplierRefDate = postRFQ.objHeader.SupplierRefDate;

            _contextW.TblBusinessPartnerRequestForQuotationHeader.Update(qheader);
            _contextW.SaveChanges();

            var rfqRow = new List<Models.Write.TblBusinessPartnerRequestForQuotationRow>(postRFQ.objRow.Count);

            foreach (var datas in postRFQ.objRow)
            {
                Models.Write.TblBusinessPartnerRequestForQuotationRow qrow = _contextW.TblBusinessPartnerRequestForQuotationRow.FirstOrDefault(X => X.IntRowId == datas.RowId );
                qrow.IntPartnerRfqid = qheader.IntPartnerRfqid;
                qrow.NumRate = datas.NumRate;
                qrow.StrRemarks = datas.Remarks;

                //rfqRow.Add(qrow);
                _contextW.TblBusinessPartnerRequestForQuotationRow.Update(qrow);
                _contextW.SaveChanges();
            }
            
            var msg = new MessageHelper();
            msg.Message = "Create Successfully.";
            msg.statuscode = 200;
            return msg;
        }

        public async Task<MessageHelper> CreateRFQCSpage(CreateRFQCSPage createRFQCSPage)
        {
            throw new NotImplementedException();
        }


        public async Task<List<GetCommonDDLDTO>> GetPRReferrenceNoDDL(long AccountId, long BusinessUnitId, long SBUId, long PurchaseOrganizationId, long PlantId, long WearHouseId)
        {
            var data = await Task.FromResult((from b in _contextR.TblPurchaseRequestHeader
                                              join r in _contextR.TblPurchaseRequestRow on b.IntPurchaseRequestId equals r.IntPurchaseRequestId
                                              where b.IsActive == true && b.IntAccountId == AccountId && b.IntBusinessUnitId == BusinessUnitId
                                              && b.IntSbuid == SBUId && b.IntPurchaseOrganizationId == PurchaseOrganizationId && b.IntPlantId == PlantId
                                              && b.IntWarehouseId == WearHouseId
                                              select new GetCommonDDLDTO
                                              {
                                                  Value = b.IntPurchaseRequestId,
                                                  Label = b.StrReffNo,
                                                  RefQty = r.NumRfqquantity

                                              }).ToList());
            if (data == null)
                throw new Exception("Referrence No Not Exist in Database");
            return data;
        }

        public async Task<List<GetRequestForQuotationCommonByIdDTO>> GetRequestForQuotationById(long RequestForQuotationId)
        {
            try
            {
                GetRequestForQuotationHeaderByIdDTO getRFQHeader = await Task.FromResult((from rfqh in _contextR.TblRequestForQuotationHeader
                                                                                          where rfqh.IsActive == true && rfqh.IntRequestForQuotationId == RequestForQuotationId
                                                                                          orderby rfqh.IntRequestForQuotationId descending
                                                                                          select new GetRequestForQuotationHeaderByIdDTO
                                                                                          {
                                                                                              RequestForQuotationId = rfqh.IntRequestForQuotationId,
                                                                                              RequestForQuotationCode = rfqh.StrRequestForQuotationCode,
                                                                                              DteRfqdate = rfqh.DteRfqdate,
                                                                                              AccountId = rfqh.IntAccountId,
                                                                                              AccountName = rfqh.StrAccountName,
                                                                                              BusinessUnitId = rfqh.IntBusinessUnitId,
                                                                                              BusinessUnitName = rfqh.StrBusinessUnitName,
                                                                                              Sbuid = rfqh.IntSbuid,
                                                                                              Sbuname = rfqh.StrSbuname,
                                                                                              PurchaseOrganizationId = rfqh.IntPurchaseOrganizationId,
                                                                                              PurchaseOrganizationName = rfqh.StrPurchaseOrganizationName,
                                                                                              PlantId = rfqh.IntPlantId,
                                                                                              PlantName = rfqh.StrPlantName,
                                                                                              WarehouseId = rfqh.IntWarehouseId,
                                                                                              WarehouseName = rfqh.StrWarehouseName,
                                                                                              RequestTypeId = rfqh.IntRequestTypeId,
                                                                                              RequestTypeName = rfqh.StrRequestTypeName,
                                                                                              ReferenceTypeName = rfqh.StrReferenceTypeName,
                                                                                              CurrencyId = rfqh.IntCurrencyId,
                                                                                              CurrencyCode = rfqh.StrCurrencyCode,
                                                                                              ValidTillDate = rfqh.DteValidTillDate,

                                                                                          }).FirstOrDefault());

                List<GetRequestForQuotationRowDTO> getRFQRow = await Task.FromResult((from rfqh in _contextR.TblRequestForQuotationRow
                                                                                      where rfqh.IntRequestForQuotationId == RequestForQuotationId && rfqh.IsActive == true
                                                                                      orderby rfqh.IntRequestForQuotationId descending
                                                                                      select new GetRequestForQuotationRowDTO
                                                                                      {
                                                                                          RowId = rfqh.IntRowId,
                                                                                          RequestForQuotationId = rfqh.IntRequestForQuotationId,
                                                                                          RequestForQuotationCode = rfqh.StrRequestForQuotationCode,
                                                                                          ItemId = rfqh.IntItemId,
                                                                                          ItemCode = rfqh.StrItemCode,
                                                                                          ItemName = rfqh.StrItemName,
                                                                                          UoMid = rfqh.IntUoMid,
                                                                                          UoMname = rfqh.StrUoMname,
                                                                                          Reqquantity = rfqh.NumRfqquantity,
                                                                                          ReferenceId = rfqh.IntReferenceId,
                                                                                          ReferenceCode = rfqh.StrReferenceCode,
                                                                                          ReferenceQuantity = rfqh.NumReferenceQuantity,
                                                                                          Description = rfqh.StrDescription,

                                                                                      }).ToList());
                List<GetSupplierListDTO> getRFQSupplierRow = await Task.FromResult((from rfqh in _contextR.TblBusinessPartnerRequestForQuotationHeader
                                                                                    where rfqh.IntRequestForQuotationId == RequestForQuotationId && rfqh.IsEmailSend == false && rfqh.IsActive == true
                                                                                    orderby rfqh.IntRequestForQuotationId descending
                                                                                    select new GetSupplierListDTO
                                                                                    {
                                                                                        PartnerRFQId = rfqh.IntPartnerRfqid,
                                                                                        RequestForQuotationId = rfqh.IntRequestForQuotationId,
                                                                                        BusinessPartnerId = rfqh.IntBusinessPartnerId,
                                                                                        BusinessPartnerName = rfqh.StrBusinessPartnerName,
                                                                                        BusinessPartnerAddress = rfqh.StrBusinessPartnerAddress,
                                                                                        Email = rfqh.StrEmail,
                                                                                        ContactNumber = rfqh.StrContactNumber,

                                                                                    }).ToList());


                List<GetRequestForQuotationCommonByIdDTO> objListData = new List<GetRequestForQuotationCommonByIdDTO>();
                GetRequestForQuotationCommonByIdDTO objData = new GetRequestForQuotationCommonByIdDTO()
                {
                    objHeader = getRFQHeader,
                    objRow = getRFQRow,
                    objSuplier = getRFQSupplierRow
                };


                if (objData == null)
                    throw new Exception("R.F.Q  Information Not Exist in Database");
                else
                    objListData.Add(objData);

                return objListData;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<RequestForQuotationPasignation> GetRequestForQuotationPasignation(long AccountId, long UnitId, long RequestTypeId, long SBUId, long PurchaseOrganizationId, long PlantId, long WearHouseId, bool status, string viewOrder, long PageNo, long PageSize)
        {
            var counts = _contextR.TblRequestForQuotationHeader.Where(x => x.IntAccountId == AccountId && x.IsActive == status).Count();
            IQueryable<GetRequestForQuotationPasignationDTO> data = (from rfqh in _contextR.TblRequestForQuotationHeader
                                                                      where rfqh.IsActive == status && rfqh.IntAccountId == AccountId && rfqh.IntBusinessUnitId == UnitId
                                                                      && rfqh.IntRequestTypeId == RequestTypeId && rfqh.IntSbuid == SBUId && rfqh.IntPurchaseOrganizationId == PurchaseOrganizationId
                                                                      && rfqh.IntPlantId == PlantId && rfqh.IntWarehouseId == WearHouseId
                                                                      orderby rfqh.IntRequestForQuotationId descending
                                                                      select new GetRequestForQuotationPasignationDTO
                                                                      {
                                                                          RequestForQuotationId = rfqh.IntRequestForQuotationId,
                                                                          RequestForQuotationCode = rfqh.StrRequestForQuotationCode,
                                                                          Rfqdate = rfqh.DteRfqdate,
                                                                          CurrencyId = rfqh.IntCurrencyId,
                                                                          CurrencyCode = rfqh.StrCurrencyCode,
                                                                          ValidTillDate = rfqh.DteValidTillDate

                                                                      });

            if (data == null)
                throw new Exception("Request For Quotation Not Exist in Database");
            else
            {
                if (viewOrder.ToUpper() == "ASC")
                    data = data.OrderBy(o => o.RequestForQuotationId);
                else if (viewOrder.ToUpper() == "DESC")
                    data = data.OrderByDescending(o => o.RequestForQuotationId);
            }

            if (PageNo <= 0)
                PageNo = 1;
            var itemdata = PagingList<GetRequestForQuotationPasignationDTO>.CreateAsync(data, PageNo, PageSize);
            int index = 1;
            foreach (var itms in itemdata)
            {
                itms.SL = index++;
            }
            RequestForQuotationPasignation itm = new RequestForQuotationPasignation();
            itm.Data = itemdata;
            itm.currentPage = PageNo;
            itm.totalCount = counts;
            itm.pageSize = PageSize;

            return itm;
        }

        public async Task<List<GetRFQCSDTO>> GetRFQCS(long RequestForQuotationId)
        {
            var data = await Task.FromResult((from r in _contextR.TblBusinessPartnerRequestForQuotationRow
                                              join h in _contextR.TblBusinessPartnerRequestForQuotationHeader on r.IntPartnerRfqid equals h.IntPartnerRfqid
                                              where r.IsActive == true && h.IsActive == true && h.IntRequestForQuotationId == RequestForQuotationId 
                                              orderby r.IntPartnerRfqid ascending
                                              select new GetRFQCSDTO
                                              {
                                                  RowId = r.IntRowId,
                                                  PartnerRfqid = r.IntPartnerRfqid,
                                                  ItemId = r.IntItemId,
                                                  ItemCode = r.StrItemCode,
                                                  ItemName = r.StrItemName,
                                                  UomId = r.IntUoMid,
                                                  UomName = r.StrUoMname,
                                                  PurchaseDescription = "",
                                                  RFQQty = r.NumRequestQuantity,
                                                  Rate = r.NumRate,
                                                  Value = r.NumRequestQuantity * r.NumRate,
                                                  supplierId = h.IntBusinessPartnerId,
                                                  supplierName = h.StrBusinessPartnerName,
                                                  supplierRefNo = h.StrSupplierRefNo,
                                                  supplierRefDate = h.DteSupplierRefDate

                                              }).ToList());

            int index = 1;
            foreach (var itms in data)
            {
                itms.SL = index++;
            }

            if (data == null)
                throw new Exception("RFQ Item Not Exist in Database");
            return data;

            //throw new NotImplementedException();
            /*var partnerRfq = from rh in _contextR.TblBusinessPartnerRequestForQuotationHeader
                             join rr in _contextR.TblBusinessPartnerRequestForQuotationRow on rh.IntPartnerRfqid equals rr.IntPartnerRfqid
                             where rh.IntAccountId == AccountId && rh.IntBusinessUnitId == BusinessUnitId && rh.IntRequestForQuotationId == RequestForQuotationId && rh.IsActive == true
                             select rh;
            var counts = partnerRfq.Count();
            IQueryable<GetRFQCSDTO> data = (from rfqh in _contextR.TblBusinessPartnerRequestForQuotationHeader
                                            join rfqr in _contextR.TblBusinessPartnerRequestForQuotationRow on rfqh.IntPartnerRfqid equals rfqr.IntPartnerRfqid
                                            where rfqh.IsActive == status && rfqh.IntAccountId == AccountId && rfqh.IntBusinessUnitId == BusinessUnitId
                                            && rfqh.IntRequestForQuotationId == RequestForQuotationId
                                            orderby rfqh.IntPartnerRfqid descending
                                            select new GetRFQCSDTO
                                            {
                                                RowId = rfqr.IntRowId,
                                                PartnerRfqid = rfqr.IntPartnerRfqid,
                                                ItemId = rfqr.IntItemId,
                                                ItemCode = rfqr.StrItemCode,
                                                ItemName = rfqr.StrItemName,
                                                UomId = rfqr.IntUoMid,
                                                UomName = rfqr.StrUoMname,
                                                PurchaseDescription = "",
                                                RFQQty = rfqr.NumRequestQuantity,
                                                Rate = rfqr.NumRate,
                                                Value = rfqr.NumRequestQuantity * rfqr.NumRate,

                                                supplierName = rfqh.StrBusinessPartnerName,
                                                supplierRefNo = rfqh.StrSupplierRefNo,
                                                supplierRefDate = rfqh.DteSupplierRefDate

                                            });
            if (data == null)
                throw new Exception("Request For Quotation Not Exist in Database");
            else
            {
                if (viewOrder.ToUpper() == "ASC")
                    data = data.OrderBy(o => o.RowId);
                else if (viewOrder.ToUpper() == "DESC")
                    data = data.OrderByDescending(o => o.RowId);
            }

            if (PageNo <= 0)
                PageNo = 1;
            var itemdata = PagingList<GetRFQCSDTO>.CreateAsync(data, PageNo, PageSize);
            int index = 1;
            foreach (var itms in itemdata)
            {
                itms.SL = index++;
            }
            RFQCSPasignation itm = new RFQCSPasignation();
            itm.Data = itemdata;
            itm.currentPage = PageNo;
            itm.totalCount = counts;
            itm.pageSize = PageSize;

            return itm;*/



        }

        public async Task<List<GetCommonDDLDTO>> GetRFQItemDDL(long AccountId, long BusinessUnitId, long SBUId, long PurchaseOrganizationId, long PlantId, long WearHouseId, long PurchaseRequestId, string Referrence)
        {
            var data = await Task.FromResult((from rh in _contextR.TblPurchaseRequestHeader
                                              join r in _contextR.TblPurchaseRequestRow on rh.IntPurchaseRequestId equals r.IntPurchaseRequestId
                                               where rh.IsActive == true && rh.IsApproved == true && rh.IsComplete == false && rh.IsClosed == false
                                               && rh.IntAccountId == AccountId && rh.IntBusinessUnitId == BusinessUnitId
                                               && rh.IntSbuid == SBUId && rh.IntPurchaseOrganizationId == PurchaseOrganizationId 
                                               && rh.IntPlantId == PlantId && rh.IntWarehouseId == WearHouseId 
                                               && rh.IntPurchaseRequestId == PurchaseRequestId && rh.StrReffNo == Referrence

                                              select new GetCommonDDLDTO
                                               {
                                                   Value = r.IntItemId,
                                                   Label = r.StrItemName,
                                                   Code = r.StrItemCode

                                               }).ToList());

            if (data == null)
                throw new Exception("RFQ Item Not Exist in Database");
            return data;
        }

        public async Task<RFQQuotationEntryPasignation> GetRFQQuotationEntry(long AccountId, long BusinessUnitId, long RFQId, bool status, string viewOrder, long PageNo, long PageSize)
        {
            //throw new NotImplementedException();
            var partnerRfq = from rh in _contextR.TblBusinessPartnerRequestForQuotationHeader
                             join rr in _contextR.TblBusinessPartnerRequestForQuotationRow on rh.IntPartnerRfqid equals rr.IntPartnerRfqid
                             where rh.IntAccountId == AccountId && rh.IntBusinessUnitId == BusinessUnitId && rh.IntRequestForQuotationId == RFQId && rh.IsActive == true
                             select rh;
            var counts = partnerRfq.Count();
            var data1 = await Task.FromResult((from rfqh in _contextR.TblBusinessPartnerRequestForQuotationHeader
                          join rfqr in _contextR.TblBusinessPartnerRequestForQuotationRow on rfqh.IntPartnerRfqid equals rfqr.IntPartnerRfqid
                          join rfqrr in _contextR.TblRequestForQuotationRow on rfqh.IntRequestForQuotationId equals rfqrr.IntRequestForQuotationId
                          where rfqh.IsActive == status && rfqh.IntAccountId == AccountId && rfqh.IntBusinessUnitId == BusinessUnitId
                          && rfqh.IntRequestForQuotationId == RFQId
                          orderby rfqh.IntPartnerRfqid descending
                          select new GetRFQQuotationEntryDTO
                          {
                              partnerRFQId = rfqh.IntPartnerRfqid,
                              Rowid = rfqr.IntRowId,
                              ItemId = rfqr.IntItemId,
                              ItemCode = rfqr.StrItemCode,
                              ItemName = rfqr.StrItemName,
                              UomId = rfqr.IntUoMid,
                              UomName = rfqr.StrUoMname,
                              PurchaseDescription = rfqrr.StrDescription,
                              RFQQty = rfqr.NumRequestQuantity,
                              Rate = rfqr.NumRate,
                              Value = rfqr.NumRequestQuantity * rfqr.NumRate,
                              Comments = rfqr.StrRemarks

                          })
                        .GroupBy(x => new { x.partnerRFQId, x.Rowid, x.ItemId, x.ItemCode, x.ItemName, x.UomId, x.UomName, x.PurchaseDescription, x.RFQQty, x.Rate, x.Value, x.Comments })
                        .Select(y => new GetRFQQuotationEntryDTO
                        {
                            partnerRFQId = y.Key.partnerRFQId,
                            Rowid = y.Key.Rowid,
                            ItemId = y.Key.ItemId,
                            ItemCode = y.Key.ItemCode,
                            ItemName = y.Key.ItemName,
                            UomId = y.Key.UomId,
                            UomName = y.Key.UomName,
                            PurchaseDescription = y.Key.PurchaseDescription,
                            RFQQty = y.Key.RFQQty,
                            Rate = y.Key.Rate,
                            Value = y.Key.Value,
                            Comments = y.Key.Comments
                        })
                        .ToList());

            IQueryable<GetRFQQuotationEntryDTO> data = data1.AsQueryable();

            if (data == null)
                throw new Exception("Request For Quotation Not Exist in Database");
            else
            {
                if (viewOrder.ToUpper() == "ASC")
                    data = data.OrderBy(o => o.Rowid);
                else if (viewOrder.ToUpper() == "DESC")
                    data = data.OrderByDescending(o => o.Rowid);
            }

            if (PageNo <= 0)
                PageNo = 1;
            var itemdata = PagingList<GetRFQQuotationEntryDTO>.CreateAsync(data, PageNo, PageSize);
            int index = 1;
            foreach (var itms in itemdata)
            {
                itms.SL = index++;
            }
            RFQQuotationEntryPasignation itm = new RFQQuotationEntryPasignation();
            itm.Data = itemdata;
            itm.currentPage = PageNo;
            itm.totalCount = counts;
            itm.pageSize = PageSize;

            return itm;
        }

        public async Task<List<GetCommonDDLDTO>> GetRFQSupplierDDL(long AccountId, long BusinessUnitId, long RequestForQuotationId)
        {
            var data = await Task.FromResult((from b in _contextR.TblBusinessPartnerRequestForQuotationHeader
                                              where b.IsActive == true && b.IntAccountId == AccountId && b.IntBusinessUnitId == BusinessUnitId
                                              && b.IntRequestForQuotationId == RequestForQuotationId
                                              select new GetCommonDDLDTO
                                              {
                                                  Value = b.IntBusinessPartnerId,
                                                  Label = b.StrBusinessPartnerName

                                              }).ToList());
            if (data == null)
                throw new Exception("Partner Not Exist in Database");
            return data;
        }

        public async Task<List<GetCommonDDLDTO>> GetRFQUOMDDL(long AccountId, long BusinessUnitId, long ItemId)
        {
            //throw new NotImplementedException();

            var data1 = await Task.FromResult((from b in _contextR.TblItemUomconversion
                                              where b.IsActive == true && b.IntAccountId == AccountId && b.IntBusinessUnitId == BusinessUnitId
                                              && b.IntItemId == ItemId
                                              select new GetCommonDDLDTO
                                              {
                                                  Value = b.IntBaseUom,
                                                  Label = b.StrBaseUomName

                                              }).ToList());

            var data2 = await Task.FromResult((from b in _contextR.TblItemUomconversion
                                               where b.IsActive == true && b.IntAccountId == AccountId && b.IntBusinessUnitId == BusinessUnitId
                                               && b.IntItemId == ItemId
                                               select new GetCommonDDLDTO
                                               {
                                                   Value = b.IntConvertedUom,
                                                   Label = b.StrConvertedUomName

                                               }).ToList());

            var data = data1.Union(data2).ToList();

            if (data == null)
                throw new Exception("RFQ UOM Not Exist in Database");
            return data;
        }
    }
}
