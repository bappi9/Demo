﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CostController.QueryBus.Query
{
    public class Class
    {
    }
}
