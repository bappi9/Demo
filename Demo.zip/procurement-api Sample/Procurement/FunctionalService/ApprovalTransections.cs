﻿using Procurement.DbContexts;
using Procurement.DTO;
using Procurement.DTO.PurchaseRequestApproval;
using Procurement.Helper;

using Procurement.Models.Write;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.FunctionalService
{
    public class ApprovalTransections
    {
        public readonly ReadDbContext _contextR;
        public readonly WriteDbContext _contextW;

        public ApprovalTransections(ReadDbContext contextR, WriteDbContext contextW)
        {
            _contextR = contextR;
            _contextW = contextW;
        }

        public async Task<string> CreateApproval(long intPoId, long intBusinessUnitId, long intUserId, long intAccountId, long intActivityId)
        {
            try
            {
                var dt = _contextR.TblApprovalConfigHeader.Where(a => a.PredisorActivityId == intActivityId && a.UnitId == intBusinessUnitId && a.IsActive == true).FirstOrDefault();
                if (dt != null)
                {
                    TblApprovalTransectionHeader aph = new TblApprovalTransectionHeader();
                    aph.IntApprovalConfigId = dt.ApprovalConfigId;
                    aph.IntAccountId = intAccountId;
                    aph.IntPredisorActivityId = intActivityId;
                    aph.StrPredisorActivityName = dt.PredisorActivityName;
                    aph.IntUnitId = intBusinessUnitId;
                    aph.IntApprovalConfigId = dt.ApprovalConfigId;
                    aph.IntTransectionPkId = intPoId;
                    aph.IsActive = true;
                    aph.IsAnyOrder = dt.IsAnyOrder;
                    aph.IsInSequence = dt.IsInSequence;
                    aph.IntAnyUsers = dt.AnyUsers;
                    aph.IsApproved = false;
                    aph.IntActionBy = 0;
                    aph.DteLastActionDateTime = DateTime.Now;
                    aph.DteServerDateTime = DateTime.Now;

                    await _contextW.TblApprovalTransectionHeader.AddAsync(aph);
                    await _contextW.SaveChangesAsync();
                    var arow = (from a in _contextR.TblApprovalConfigRow
                                where a.ApprovalConfigId == dt.ApprovalConfigId
                                select new TblApprovalTransectionRow()
                                {
                                    IntApprovalTransectionId = aph.IntApprovalTransectionId,
                                    IntUserId = (long)a.UserId,
                                    StrUserName = a.StrUserName,
                                    IntSequenceId = (int)a.SequenceId,
                                    IsApprove = false,
                                    NumThreshold = a.Threshold,

                                }).ToList();

                    await _contextW.TblApprovalTransectionRow.AddRangeAsync(arow);
                    await _contextW.SaveChangesAsync();

                }
                return "";

            }
            catch (Exception ex)
            {
                return "";
            }



        }
        public Task PoApproval(long ActivityId, long intPoId, long intBusinessUnitId, long intUserId)
        {
            try
            {
                var header = (from h in _contextW.TblApprovalTransectionHeader
                              where h.IntTransectionPkId == intPoId && h.IsApproved == false
                              select h).FirstOrDefault();

                var row = (from r in _contextW.TblApprovalTransectionRow
                           where r.IntApprovalTransectionId == header.IntApprovalTransectionId && r.IntUserId == intUserId && r.IsApprove == false
                           select r).FirstOrDefault();



                var poheader = _contextW.TblPurchaseOrderHeader.Where(c => c.IntPurchaseOrderId == intPoId && c.IsActive == true && c.IsApproved == false).FirstOrDefault();

                if (header == null || row == null || poheader == null)
                {
                    throw new Exception("Data not found");
                }

                row.IsApprove = true;
                _contextW.TblApprovalTransectionRow.Update(row);
                _contextW.SaveChanges();

                var userdata = (from h in _contextW.TblApprovalTransectionHeader
                                join r in _contextW.TblApprovalTransectionRow on h.IntApprovalTransectionId equals r.IntApprovalTransectionId
                                where h.IntTransectionPkId == intPoId && r.IsApprove == false
                                select r).ToList();

                if (header.IsAnyOrder)
                {
                    if (userdata.Count == 0)
                    {
                        poheader.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblApprovalTransectionHeader.Update(header);

                        _contextW.TblPurchaseOrderHeader.Update(poheader);

                    }
                }
                else if (header.IsInSequence)
                {
                    if (userdata.Count == 0)
                    {
                        poheader.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblPurchaseOrderHeader.Update(poheader);
                        _contextW.TblApprovalTransectionHeader.Update(header);
                    }
                }
                else if ((int)header.IntAnyUsers > 0)
                {
                    if (userdata.Count >= (int)header.IntAnyUsers)
                    {
                        poheader.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblPurchaseOrderHeader.Update(poheader);
                        _contextW.TblApprovalTransectionHeader.Update(header);
                    }
                }
                _contextW.SaveChanges();
                return Task.FromResult("");
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }
        public Task PurcahseRequestApproval(long ActivityId, long intPoId, long intBusinessUnitId, long intUserId)
        {
            #region  --- OLD ---
            //try
            //{
            //    var header = (from h in _contextW.TblApprovalTransectionHeader
            //                  where h.IntTransectionPkId == intPoId && h.IsApproved == false
            //                  select h).FirstOrDefault();

            //    var row = (from r in _contextW.TblApprovalTransectionRow
            //               where r.IntApprovalTransectionId == header.IntApprovalTransectionId && r.IntUserId == intUserId && r.IsApprove == false
            //               select r).FirstOrDefault();



            //    var approval = _contextW.TblPurchaseRequestHeader.Where(c => c.IntPurchaseRequestId == intPoId && c.IsActive == true && c.IsApproved == false).FirstOrDefault();

            //    if (header == null || row == null || approval == null)
            //    {
            //        throw new Exception("Data not found");
            //    }

            //    row.IsApprove = true;
            //    _contextW.TblApprovalTransectionRow.Update(row);
            //    _contextW.SaveChanges();


            //    var userdata = (from h in _contextW.TblApprovalTransectionHeader
            //                    join r in _contextW.TblApprovalTransectionRow on h.IntApprovalTransectionId equals r.IntApprovalTransectionId
            //                    where h.IntTransectionPkId == intPoId && r.IsApprove == true
            //                    select r).ToList();

            //    if (header.IsAnyOrder)
            //    {
            //        if (userdata.Count == 0)
            //        {
            //            approval.IsApproved = true;
            //            header.IsApproved = true;
            //            _contextW.TblApprovalTransectionHeader.Update(header);
            //            _contextW.TblPurchaseRequestHeader.Update(approval);
            //        }
            //    }
            //    else if (header.IsInSequence)
            //    {
            //        if (userdata.Count == 0)
            //        {
            //            approval.IsApproved = true;
            //            header.IsApproved = true;
            //            _contextW.TblApprovalTransectionHeader.Update(header);
            //            _contextW.TblPurchaseRequestHeader.Update(approval);
            //        }
            //    }
            //    else if ((int)header.IntAnyUsers > 0)
            //    {
            //        if (userdata.Count >= (int)header.IntAnyUsers)
            //        {
            //            approval.IsApproved = true;
            //            header.IsApproved = true;
            //            _contextW.TblApprovalTransectionHeader.Update(header);
            //            _contextW.TblPurchaseRequestHeader.Update(approval);
            //        }
            //    }
            //    _contextW.SaveChanges();
            //    return Task.FromResult("");
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
            #endregion

            try
            {
                var header = (from h in _contextW.TblApprovalTransectionHeader
                              where h.IntTransectionPkId == intPoId && h.IsApproved == false
                              select h).FirstOrDefault();

                var row = (from r in _contextW.TblApprovalTransectionRow
                           where r.IntApprovalTransectionId == header.IntApprovalTransectionId && r.IntUserId == intUserId && r.IsApprove == false
                           select r).FirstOrDefault();



                var prheader = _contextW.TblPurchaseRequestHeader.Where(c => c.IntPurchaseRequestId == intPoId && c.IsActive == true && c.IsApproved == false).FirstOrDefault();

                if (header == null || row == null || prheader == null)
                {
                    throw new Exception("Data not found");
                }

                var rowapp = (from pr in _contextW.TblPurchaseRequestRow
                              where pr.IntPurchaseRequestId == prheader.IntPurchaseRequestId && pr.IsActive == true
                              select pr).ToList();

                row.IsApprove = true;
                _contextW.TblApprovalTransectionRow.Update(row);
                _contextW.SaveChanges();

                foreach (var approve in rowapp)
                {

                    approve.NumApprovedQuantity = approve.NumRequestQuantity;

                    _contextW.TblPurchaseRequestRow.Update(approve);
                    _contextW.SaveChanges();
                }


                var userdata = (from h in _contextW.TblApprovalTransectionHeader
                                join r in _contextW.TblApprovalTransectionRow on h.IntApprovalTransectionId equals r.IntApprovalTransectionId
                                where h.IntTransectionPkId == intPoId && r.IsApprove == false
                                select r).ToList();

                if (header.IsAnyOrder)
                {
                    if (userdata.Count == 0)
                    {
                        prheader.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblApprovalTransectionHeader.Update(header);

                        _contextW.TblPurchaseRequestHeader.Update(prheader);

                    }
                }
                else if (header.IsInSequence)
                {
                    if (userdata.Count == 0)
                    {
                        prheader.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblPurchaseRequestHeader.Update(prheader);
                        _contextW.TblApprovalTransectionHeader.Update(header);
                    }
                }
                else if ((int)header.IntAnyUsers > 0)
                {
                    if (userdata.Count >= (int)header.IntAnyUsers)
                    {
                        prheader.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblPurchaseRequestHeader.Update(prheader);
                        _contextW.TblApprovalTransectionHeader.Update(header);
                    }
                }
                _contextW.SaveChanges();
                return Task.FromResult("");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Task ItemRequestApproval(long ActivityId, long intPoId, long intBusinessUnitId, long intUserId)
        {
            #region --- OLD ---
            //try
            //{
            //    var header = (from h in _contextW.TblApprovalTransectionHeader
            //                  where h.IntTransectionPkId == intRequestId && h.IntPredisorActivityId== ActivityId && h.IsApproved == false
            //                  select h).FirstOrDefault();

            //    var row = (from r in _contextW.TblApprovalTransectionRow
            //               where r.IntApprovalTransectionId == header.IntApprovalTransectionId && r.IntUserId == intUserId && r.IsApprove == false
            //               select r).FirstOrDefault();



            //    var approval = _contextW.TblItemRequestHeader.Where(c => c.IntItemRequestId == intRequestId && c.IsActive == true && c.IsApproved == false).FirstOrDefault();

            //    if (header == null || row == null || approval == null)
            //    {
            //        throw new Exception("Data not found");
            //    }

            //    row.IsApprove = true;
            //    _contextW.TblApprovalTransectionRow.Update(row);
            //    _contextW.SaveChanges();


            //    var userdata = (from h in _contextW.TblApprovalTransectionHeader
            //                    join r in _contextW.TblApprovalTransectionRow on h.IntApprovalTransectionId equals r.IntApprovalTransectionId
            //                    where h.IntTransectionPkId == intRequestId && r.IsApprove == true
            //                    select r).ToList();

            //    if (header.IsAnyOrder)
            //    {
            //        if (userdata.Count == 0)
            //        {
            //            approval.IsApproved = true;
            //            header.IsApproved = true;
            //            _contextW.TblApprovalTransectionHeader.Update(header);
            //            _contextW.TblItemRequestHeader.Update(approval);
            //        }
            //    }
            //    else if (header.IsInSequence)
            //    {
            //        if (userdata.Count == 0)
            //        {
            //            approval.IsApproved = true;
            //            header.IsApproved = true;
            //            _contextW.TblApprovalTransectionHeader.Update(header);
            //            _contextW.TblItemRequestHeader.Update(approval);
            //        }
            //    }
            //    else if ((int)header.IntAnyUsers > 0)
            //    {
            //        if (userdata.Count >= (int)header.IntAnyUsers)
            //        {
            //            approval.IsApproved = true;
            //            header.IsApproved = true;
            //            _contextW.TblApprovalTransectionHeader.Update(header);
            //            _contextW.TblItemRequestHeader.Update(approval);
            //        }
            //    }
            //    _contextW.SaveChanges();
            //    return Task.FromResult("");
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
            #endregion

            try
            {
                var header = (from h in _contextW.TblApprovalTransectionHeader
                              where h.IntTransectionPkId == intPoId && h.IsApproved == false
                              select h).FirstOrDefault();

                var row = (from r in _contextW.TblApprovalTransectionRow
                           where r.IntApprovalTransectionId == header.IntApprovalTransectionId && r.IntUserId == intUserId && r.IsApprove == false
                           select r).FirstOrDefault();



                var irheader = _contextW.TblItemRequestHeader.Where(c => c.IntItemRequestId == intPoId && c.IsActive == true && c.IsApproved == false).FirstOrDefault();


                if (header == null || row == null || irheader == null)
                {
                    throw new Exception("Data not found");
                }


                var rowapp = (from pr in _contextW.TblItemRequestRow
                              where pr.IntItemRequestId == irheader.IntItemRequestId && pr.IsActive == true
                              select pr).ToList();


                row.IsApprove = true;
                _contextW.TblApprovalTransectionRow.Update(row);
                _contextW.SaveChanges();

                foreach (var approve in rowapp)
                {

                    approve.NumApprovedQuantity = approve.NumRequestQuantity;

                    _contextW.TblItemRequestRow.Update(approve);
                    _contextW.SaveChanges();
                }


                var userdata = (from h in _contextW.TblApprovalTransectionHeader
                                join r in _contextW.TblApprovalTransectionRow on h.IntApprovalTransectionId equals r.IntApprovalTransectionId
                                where h.IntTransectionPkId == intPoId && r.IsApprove == false
                                select r).ToList();

                if (header.IsAnyOrder)
                {
                    if (userdata.Count == 0)
                    {
                        irheader.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblApprovalTransectionHeader.Update(header);

                        _contextW.TblItemRequestHeader.Update(irheader);

                    }
                }
                else if (header.IsInSequence)
                {
                    if (userdata.Count == 0)
                    {
                        irheader.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblItemRequestHeader.Update(irheader);
                        _contextW.TblApprovalTransectionHeader.Update(header);
                    }
                }
                else if ((int)header.IntAnyUsers > 0)
                {
                    if (userdata.Count >= (int)header.IntAnyUsers)
                    {
                        irheader.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblItemRequestHeader.Update(irheader);
                        _contextW.TblApprovalTransectionHeader.Update(header);
                    }
                }
                _contextW.SaveChanges();
                return Task.FromResult("");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Task PamentApproval(long ActivityId, long intRequestId, long intBusinessUnitId, long intUserId)
        {
            try
            {
                var header = (from h in _contextW.TblApprovalTransectionHeader
                              where h.IntTransectionPkId == intRequestId && h.IntPredisorActivityId == ActivityId && h.IsApproved == false
                              select h).FirstOrDefault();

                var row = (from r in _contextW.TblApprovalTransectionRow
                           where r.IntApprovalTransectionId == header.IntApprovalTransectionId && r.IntUserId == intUserId && r.IsApprove == false
                           select r).FirstOrDefault();



                var approval = _contextW.TblItemRequestHeader.Where(c => c.IntItemRequestId == intRequestId && c.IsActive == true && c.IsApproved == false).FirstOrDefault();

                if (header == null || row == null || approval == null)
                {
                    throw new Exception("Data not found");
                }

                row.IsApprove = true;
                _contextW.TblApprovalTransectionRow.Update(row);
                _contextW.SaveChanges();


                var userdata = (from h in _contextW.TblApprovalTransectionHeader
                                join r in _contextW.TblApprovalTransectionRow on h.IntApprovalTransectionId equals r.IntApprovalTransectionId
                                where h.IntTransectionPkId == intRequestId && r.IsApprove == true
                                select r).ToList();

                if (header.IsAnyOrder)
                {
                    if (userdata.Count == 0)
                    {
                        approval.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblApprovalTransectionHeader.Update(header);
                        _contextW.TblItemRequestHeader.Update(approval);
                    }
                }
                else if (header.IsInSequence)
                {
                    if (userdata.Count == 0)
                    {
                        approval.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblApprovalTransectionHeader.Update(header);
                        _contextW.TblItemRequestHeader.Update(approval);
                    }
                }
                else if ((int)header.IntAnyUsers > 0)
                {
                    if (userdata.Count >= (int)header.IntAnyUsers)
                    {
                        approval.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblApprovalTransectionHeader.Update(header);
                        _contextW.TblItemRequestHeader.Update(approval);
                    }
                }
                _contextW.SaveChanges();
                return Task.FromResult("");
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }
        public Task SalesOrderApproval(long ActivityId, long intRequestId, long intBusinessUnitId, long intUserId)
        {
            try
            {
                var header = (from h in _contextW.TblApprovalTransectionHeader
                              where h.IntTransectionPkId == intRequestId && h.IntPredisorActivityId == ActivityId && h.IsApproved == false
                              select h).FirstOrDefault();

                var row = (from r in _contextW.TblApprovalTransectionRow
                           where r.IntApprovalTransectionId == header.IntApprovalTransectionId && r.IntUserId == intUserId && r.IsApprove == false
                           select r).FirstOrDefault();



                var approval = _contextW.TblItemRequestHeader.Where(c => c.IntItemRequestId == intRequestId && c.IsActive == true && c.IsApproved == false).FirstOrDefault();

                if (header == null || row == null || approval == null)
                {
                    throw new Exception("Data not found");
                }

                row.IsApprove = true;
                _contextW.TblApprovalTransectionRow.Update(row);
                _contextW.SaveChanges();


                var userdata = (from h in _contextW.TblApprovalTransectionHeader
                                join r in _contextW.TblApprovalTransectionRow on h.IntApprovalTransectionId equals r.IntApprovalTransectionId
                                where h.IntTransectionPkId == intRequestId && r.IsApprove == true
                                select r).ToList();

                if (header.IsAnyOrder)
                {
                    if (userdata.Count == 0)
                    {
                        approval.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblApprovalTransectionHeader.Update(header);
                        _contextW.TblItemRequestHeader.Update(approval);
                    }
                }
                else if (header.IsInSequence)
                {
                    if (userdata.Count == 0)
                    {
                        approval.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblApprovalTransectionHeader.Update(header);
                        _contextW.TblItemRequestHeader.Update(approval);
                    }
                }
                else if ((int)header.IntAnyUsers > 0)
                {
                    if (userdata.Count >= (int)header.IntAnyUsers)
                    {
                        approval.IsApproved = true;
                        header.IsApproved = true;
                        _contextW.TblApprovalTransectionHeader.Update(header);
                        _contextW.TblItemRequestHeader.Update(approval);
                    }
                }
                _contextW.SaveChanges();
                return Task.FromResult("");
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }
        public Task<ApprovalLandingPaginationDTO> ApprovalTransectionList(long ActivityId, string ActivityName, long UserId, string viewOrder, long PageNo, long PageSize)
        {
            List<ApprovalLandingDTO> landing = new List<ApprovalLandingDTO>();

            var approvalList = (from h in _contextR.TblApprovalTransectionHeader
                                join r in _contextR.TblApprovalTransectionRow on h.IntApprovalTransectionId equals r.IntApprovalTransectionId
                                where h.IntPredisorActivityId == ActivityId && h.IsApproved == false && r.IsApprove == false
                                select new
                                {

                                    h.IntApprovalTransectionId,
                                    h.IntTransectionPkId,
                                    h.IntPredisorActivityId,
                                    h.StrPredisorActivityName,
                                    h.IsAnyOrder,
                                    h.IsInSequence,
                                    h.IntAnyUsers,
                                    r.IntUserId,
                                    r.NumThreshold,
                                    r.IntSequenceId,
                                    r.IsApprove,
                                    r.IntRowId
                                }).ToList();

            var data = new List<ApprovalTransectionListDTO>();

            if (ActivityId == 2)
            {
                var dataResult = (from h in _contextR.TblApprovalTransectionHeader
                                  join r in _contextR.TblApprovalTransectionRow on h.IntApprovalTransectionId equals r.IntApprovalTransectionId
                                  join p in _contextR.TblPurchaseOrderHeader on h.IntTransectionPkId equals p.IntPurchaseOrderId
                                  join pr in _contextR.TblPurchaseOrderRow on h.IntTransectionPkId equals pr.IntPurchaseOrderId
                                  where r.IntUserId == UserId && h.IntPredisorActivityId == ActivityId && p.IsApproved == false && h.IsApproved == false && r.IsApprove == false
                                  select new ApprovalTransectionListDTO
                                  {
                                      IntPurchaseOrderId = p.IntPurchaseOrderId,
                                      StrPurchaseOrderNo = p.StrPurchaseOrderNo,
                                      Description = pr.StrPurchaseDescription,
                                      IntApprovalTransectionId = h.IntApprovalTransectionId,
                                      IntTransectionPkId = h.IntTransectionPkId,
                                      IntPredisorActivityId = h.IntPredisorActivityId,
                                      StrPredisorActivityName = h.StrPredisorActivityName,
                                      IsAnyOrder = h.IsAnyOrder,
                                      IsInSequence = h.IsInSequence,
                                      IntAnyUsers = h.IntAnyUsers,
                                      IntUserId = r.IntUserId,
                                      RequestQuantity = pr.NumOrderQty,
                                      NumThreshold = r.NumThreshold,
                                      IntSequenceId = r.IntSequenceId,
                                      IsApprove = r.IsApprove,
                                      IntRowId = r.IntRowId,
                                      DtePurchaseOrderDate = p.DtePurchaseOrderDate,
                                      POValidityDate = p.DtePovalidityDate,
                                      RequestAmount = pr.NumTotalValue
                                  }).ToList();

                data.AddRange(dataResult);
            }
            else if (ActivityId == 1)
            {
                var dataResult = (from h in _contextR.TblApprovalTransectionHeader
                                  join r in _contextR.TblApprovalTransectionRow on h.IntApprovalTransectionId equals r.IntApprovalTransectionId
                                  join p in _contextR.TblPurchaseRequestHeader on h.IntTransectionPkId equals p.IntPurchaseRequestId
                                  join pr in _contextR.TblPurchaseRequestRow on h.IntTransectionPkId equals pr.IntPurchaseRequestId
                                  where r.IntUserId == UserId && h.IntPredisorActivityId == ActivityId && p.IsApproved == false && h.IsApproved == false && r.IsApprove == false
                                  select new ApprovalTransectionListDTO
                                  {
                                      IntPurchaseOrderId = p.IntPurchaseRequestId,
                                      StrPurchaseOrderNo = p.StrPurchaseRequestCode,
                                      Description = "",
                                      IntApprovalTransectionId = h.IntApprovalTransectionId,
                                      IntTransectionPkId = h.IntTransectionPkId,
                                      IntPredisorActivityId = h.IntPredisorActivityId,
                                      StrPredisorActivityName = h.StrPredisorActivityName,
                                      IsAnyOrder = h.IsAnyOrder,
                                      IsInSequence = h.IsInSequence,
                                      IntAnyUsers = h.IntAnyUsers,
                                      IntUserId = r.IntUserId,
                                      RequestQuantity = pr.NumRequestQuantity,
                                      NumThreshold = r.NumThreshold,
                                      IntSequenceId = r.IntSequenceId,
                                      IsApprove = r.IsApprove,
                                      IntRowId = r.IntRowId,
                                      DtePurchaseOrderDate = p.DteRequestDate
                                  }).Distinct().ToList();

                data.AddRange(dataResult);
            }
            else if (ActivityId == 74)
            {
                var dataResult = (from h in _contextR.TblApprovalTransectionHeader
                                  join r in _contextR.TblApprovalTransectionRow on h.IntApprovalTransectionId equals r.IntApprovalTransectionId
                                  join p in _contextR.TblItemRequestHeader on h.IntTransectionPkId equals p.IntItemRequestId
                                  join ir in _contextR.TblItemRequestRow on h.IntTransectionPkId equals ir.IntItemRequestId
                                  where r.IntUserId == UserId && h.IntPredisorActivityId == ActivityId && p.IsApproved == false && h.IsApproved == false && r.IsApprove == false
                                  && ir.IsActive == true
                                  select new ApprovalTransectionListDTO
                                  {
                                      IntPurchaseOrderId = p.IntItemRequestId,
                                      StrPurchaseOrderNo = p.StrItemRequestCode,
                                      Description = "pr.StrPurchaseDescription",
                                      IntApprovalTransectionId = h.IntApprovalTransectionId,
                                      IntTransectionPkId = h.IntTransectionPkId,
                                      IntPredisorActivityId = h.IntPredisorActivityId,
                                      StrPredisorActivityName = h.StrPredisorActivityName,
                                      IsAnyOrder = h.IsAnyOrder,
                                      IsInSequence = h.IsInSequence,
                                      IntAnyUsers = h.IntAnyUsers,
                                      IntUserId = r.IntUserId,
                                      RequestQuantity = ir.NumRequestQuantity,
                                      NumThreshold = r.NumThreshold,
                                      IntSequenceId = r.IntSequenceId,
                                      IsApprove = r.IsApprove,
                                      IntRowId = r.IntRowId,
                                      DtePurchaseOrderDate = p.DteRequestDate
                                  }).ToList();

                data.AddRange(dataResult);
            }



            if (approvalList.Count == 0 || data.Count == 0)
            {
                throw new Exception("Data not found");
            }

            if (data.FirstOrDefault().IsAnyOrder)
            {
                landing = data.Select(s => new ApprovalLandingDTO()
                {
                    TransectionId = s.IntTransectionPkId,
                    TransectionDate = s.DtePurchaseOrderDate,
                    ReffCode = s.StrPurchaseOrderNo,
                    Description = s.Description,
                    DueDate = s.DtePurchaseOrderDate,
                    Quantity = s.RequestQuantity,
                    Amount = s.RequestAmount
                }).ToList();

            }

            else if (data.FirstOrDefault().IsInSequence)
            {

                foreach (var d in data)
                {
                    var ds = approvalList.Where(c => c.IntTransectionPkId == d.IntPurchaseOrderId && c.IntSequenceId == d.IntSequenceId - 1).FirstOrDefault();

                    if (ds != null)
                    {
                        landing.Add(new ApprovalLandingDTO()
                        {
                            TransectionId = d.IntTransectionPkId,
                            TransectionDate = d.DtePurchaseOrderDate,
                            ReffCode = d.StrPurchaseOrderNo,
                            Description = d.Description,
                            DueDate = d.DtePurchaseOrderDate,
                            Quantity = d.RequestQuantity,
                            Amount = d.RequestAmount
                        });
                    }
                    else
                    {
                        landing.Add(new ApprovalLandingDTO()
                        {
                            TransectionId = d.IntTransectionPkId,
                            TransectionDate = d.DtePurchaseOrderDate,
                            ReffCode = d.StrPurchaseOrderNo,
                            Description = d.Description,
                            DueDate = d.DtePurchaseOrderDate,
                            Quantity = d.RequestQuantity,
                            Amount = d.RequestAmount
                        });
                    }
                }
            }
            else
            {
                landing = data.Select(s => new ApprovalLandingDTO()
                {
                    TransectionId = s.IntTransectionPkId,
                    TransectionDate = s.DtePurchaseOrderDate,
                    ReffCode = s.StrPurchaseOrderNo,
                    Description = s.Description,
                    DueDate = s.DtePurchaseOrderDate,
                    Quantity = s.RequestQuantity,
                    Amount = s.RequestAmount
                }).ToList();
            }

            var counts = landing.Count();

            var ILanding = landing.AsQueryable();
            if (landing == null)
                throw new Exception("Data not found.");
            else
            {
                if (viewOrder.ToUpper() == "ASC")
                    ILanding = ILanding.OrderBy(o => o.TransectionId);
                else if (viewOrder.ToUpper() == "DESC")
                    ILanding = ILanding.OrderByDescending(o => o.TransectionId);
            }

            if (PageNo <= 0)
                PageNo = 1;
            var itemdata = PagingList<ApprovalLandingDTO>.CreateAsync(ILanding, PageNo, PageSize);

            int index = 1;
            foreach (var itms in itemdata)
            {
                itms.Sl = index++;
            }
            ApprovalLandingPaginationDTO itm = new ApprovalLandingPaginationDTO();
            itm.Data = itemdata;
            itm.currentPage = PageNo;
            itm.totalCount = counts;
            itm.pageSize = PageSize;

            return Task.FromResult(itm);

        }


    }
}
