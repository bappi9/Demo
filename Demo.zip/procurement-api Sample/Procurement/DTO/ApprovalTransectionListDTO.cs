﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO
{
    public class ApprovalTransectionListDTO
    {
        public long IntPurchaseOrderId { get; set; }
        public string StrPurchaseOrderNo { get; set; }
        public string Description { get; set; }
        public long IntApprovalTransectionId { get; set; }
        public long IntTransectionPkId { get; set; }
        public long IntPredisorActivityId { get; set; }
        public string StrPredisorActivityName { get; set; }
        public decimal RequestQuantity { get; set; }
        public decimal RequestAmount { get; set; }
        public bool IsAnyOrder { get; set; }
        public bool IsInSequence { get; set; }
        public long? IntAnyUsers { get; set; }
        public long? IntUserId { get; set; }
        public decimal? NumThreshold { get; set; }
        public long? IntSequenceId { get; set; }
        public bool IsApprove { get; set; }
        public long IntRowId { get; set; }
        public DateTime DtePurchaseOrderDate { get; set; }
        public DateTime POValidityDate { get; set; }
    }
}
