﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO
{
    public class GetCommonDDLDTO
    {
        public long Value { get; set; }
        public string Label { get; set; }
        public string Code { get; set; }
        public decimal? RefQty { get; set; }
        public decimal? RestofQty { get; set; }
        public decimal? NetValue { get; set; }
        public long UoMId { get; set; }
        public string  UoMName { get; set; }

    }
}
