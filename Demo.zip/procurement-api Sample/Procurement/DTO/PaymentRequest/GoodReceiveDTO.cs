﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PaymentRequest
{
    public class GoodReceiveDTO
    {
        public long GoodReceiveId { get; set; }
        public string Code { get; set; }
        public string Type { get; set; }
        public DateTime RceiveDate { get; set; }
        public decimal Amount { get; set; }
    }
}
