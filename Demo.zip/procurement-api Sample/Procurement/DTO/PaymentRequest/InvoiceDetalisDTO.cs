﻿using Procurement.DTO.PaymentRequest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO
{
    public class InvoiceDetalisDTO
    {
        public long InvoiceId { get; set; }
        public string InvoiceCode { get; set; }
        public long WareHouseId { get; set; }
        public string WareHouseName { get; set; }
        public decimal PoAmount { get; set; }
        public decimal GrnAmount { get; set; }
        public decimal InvoiceAmount { get; set; }

        public List<PurchaseOrderDTO> PurchaseOrder { get; set; }
        public List<GoodReceiveDTO> GoodReceive { get; set; }

    }
}
