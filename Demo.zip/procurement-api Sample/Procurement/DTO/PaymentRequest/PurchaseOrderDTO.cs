﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO
{
    public class PurchaseOrderDTO
    {
        public long PurchaseOrderId { get; set; }
        public string Code { get; set; }
        public string Type { get; set; }
        public DateTime PoDate { get; set; }
        public decimal Amount { get; set; }
    }
}
