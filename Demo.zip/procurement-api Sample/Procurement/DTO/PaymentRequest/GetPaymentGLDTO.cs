﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PaymentRequest
{
    public class GetPaymentGLDTO
    {
        public long GLId { get; set; }
        public string GLCode { get; set; }
        public string GLName { get; set; }
        public decimal Amount { get; set; }
    }
}
