﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PaymentRequest
{
    public class CreateCashPaymentRowDTO
    {
        /// 0-Payment_Amount 1-NetPayment_Amount 2-TDS_Amount 3-VDS_Amount
        public long AmountTypeId { get; set; }
        public long? BankAccountId { get; set; }
        public string BankAccNo { get; set; }
        public long BusinessTransactionId { get; set; }
        public string BusinessTransactionCode { get; set; }
        public string BusinessTransactionName { get; set; }
        public long GeneralLedgerId { get; set; }
        public string GeneralLedgerCode { get; set; }
        public string GeneralLedgerName { get; set; }
        public decimal PayAmount { get; set; }
        //public decimal TDSAmount { get; set; }
        //public decimal VDSAmount { get; set; }
        public string Narration { get; set; }
    }
}
