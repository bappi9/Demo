﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO
{
    public class PaymentLandigDTO
    {
        public long Sl { get; set; }
        public long InvoiceId { get; set; }
        public string InvoiceCode { get; set; }
        public DateTime? TransanctionDate { get; set; }
        public DateTime InvoiceDate { get; set; }
        public long  WareHouseId { get; set; }
        public long SBUId { get; set; }
        public long PartnerId { get; set; }
        public string PartnerName { get; set; }
        public string WareHouseName { get; set; }
        public decimal PoAmount { get; set; }
        public decimal GrnAmount { get; set; }
        public decimal InvoiceAmount   { get; set; }
        public decimal LedgerBalance { get; set; }
    }
}
