﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PaymentRequest
{
    public class CreateCashPaymentHeaderDTO
    {
        // 1-Cash 2-Bank
        public long PaymentProcessType { get; set; }
        public string InvoiceCode { get; set; }
        public DateTime JournalDate { get; set; }
        public long AccountId { get; set; }
        public long BusinessUnitId { get; set; }
        public long Sbuid { get; set; }
        public string ReceiveFrom { get; set; }
        public string TransferTo { get; set; }
        public string PaidTo { get; set; }                
        public decimal PayAmount { get; set; }  
        public string Narration { get; set; }      
        public long? BusinessPartnerId { get; set; }
        public string BusinessPartnerCode { get; set; }
        public string BusinessPartnerName { get; set; }
        public long GeneralLedgerId { get; set; }
        public string GeneralLedgerCode { get; set; }
        public string GeneralLedgerName { get; set; }
        public long ActionBy { get; set; }



        // -----------Bank Info
        //public DateTime VoucherDate { get; set; }
        //public long AccountId { get; set; }
        //public long BusinessUnitId { get; set; }
        //public long Sbuid { get; set; }
        public long BankId { get; set; }
        public string BankName { get; set; }
        public long BankBranchId { get; set; }
        public string BankBranchName { get; set; }
        public long BankAccountId { get; set; }
        public string BankAccountNumber { get; set; }

        //public string ReceiveFrom { get; set; }
        //public string PaidTo { get; set; }
        //public string TransferTo { get; set; }

        public bool IsPlacedInBank { get; set; }
        public DateTime PlacingDate { get; set; }

        //public long GeneralLedgerId { get; set; }
        //public string GeneralLedgerCode { get; set; }
        //public string GeneralLedgerName { get; set; }
        //public decimal NumAmount { get; set; }
        //public decimal? NumInvoiceAdjustAmount { get; set; }
        //public decimal? NumAdjustmentPendingAmount { get; set; }

        //public string Narration { get; set; }
        //public bool IsPosted { get; set; }
        public DateTime? CompleteDateTime { get; set; }

        //public long? BusinessPartnerId { get; set; }
        //public string BusinessPartnerCode { get; set; }
        //public string BusinessPartnerName { get; set; }

        public long? InstrumentId { get; set; }
        public string InstrumentName { get; set; }
        public string InstrumentNo { get; set; }
        public DateTime? InstrumentDate { get; set; }

        //public long AccountingJournalTypeId { get; set; }
        //public bool IsDirectPosting { get; set; }
        //public bool? IsActive { get; set; }
        //public long ActionBy { get; set; }
    }
}
