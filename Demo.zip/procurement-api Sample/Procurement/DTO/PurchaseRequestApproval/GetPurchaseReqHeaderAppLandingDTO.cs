﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseRequestApproval
{
    public class GetPurchaseReqHeaderAppLandingDTO
    {
        public long Sl { get; set; }
        public long PurchaseRequestId { get; set; }
        public string PurchaseRequestCode { get; set; }
        public string ReffNo { get; set; }
        public string PurchaseRequestTypeName { get; set; }
        public string Sbuname { get; set; }
        public string PurchaseOrganizationName { get; set; }
        public string PlantName { get; set; }
        public string WarehouseName { get; set; }
        public string DeliveryAddress { get; set; }
       // public string SupplyingWarehouseName { get; set; }
        public DateTime RequestDate { get; set; }      
        public bool? IsActive { get; set; }
    }
}
