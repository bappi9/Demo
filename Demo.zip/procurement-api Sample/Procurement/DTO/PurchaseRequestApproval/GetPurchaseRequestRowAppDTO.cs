﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseRequestApproval
{
    public class GetPurchaseRequestRowAppDTO
    {
        public long RowId { get; set; }
        public long PurchaseRequestId { get; set; }
        public string PurchaseRequestCode { get; set; }
        public long ItemId { get; set; }
        public string ItemName { get; set; }
        public string ItemCode  { get; set; }
        public long UoMid { get; set; }
        public string UoMname { get; set; }
        public decimal NumRequestQuantity { get; set; }
        public decimal? NumApprovedQuantity { get; set; }
        public decimal? NumRfqquantity { get; set; }
        public decimal? NumPurchaseOrderQuantity { get; set; }
        public DateTime DteRequiredDate { get; set; }
        public long? CostElementId { get; set; }
        public string CostElementName { get; set; }
        public long? BillOfMaterialId { get; set; }
        public string Remarks { get; set; }
    }
}
