﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseRequestApproval
{
    public class EditPurchaseRequestRowApprDTO
    {
        [Required]
        [Range(0 , Int64.MaxValue , ErrorMessage = "The field {0} must be greater than {0}.")]
        public long RowId { get; set; }

        [Required]
        [Range(1 , Int64.MaxValue , ErrorMessage = "The field {0} must be greater than {1}.")]
        public long PurchaseRequestId { get; set; }
        public string PurchaseRequestCode { get; set; }

        [Required]
        [Range(1 , Int64.MaxValue , ErrorMessage = "The field {0} must be greater than {1}.")]
        public long ItemId { get; set; }
        public string ItemName { get; set; }
        public string ItemCode { get; set; }

        [Required]
        [Range(1 , Int64.MaxValue , ErrorMessage = "The field {0} must be greater than {1}.")]
        public long UoMid { get; set; }
        public string UoMname { get; set; }
        public decimal NumRequestQuantity { get; set; }
        public decimal NumApprovedQuantity { get; set; }
        public decimal NumRfqquantity { get; set; }
        public decimal NumPurchaseOrderQuantity { get; set; }
        public DateTime DteRequiredDate { get; set; }
        public long? CostElementId { get; set; }
        public string CostElementName { get; set; }

        [Required]
        [Range(1 , Int64.MaxValue , ErrorMessage = "The field {0} must be greater than {1}.")]
        public long? BillOfMaterialId { get; set; }
        public string Remarks { get; set; }
    }
}
