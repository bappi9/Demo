﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseRequestApproval
{
    public class GetPurchaseRequestApproveCommonDTO
    {
        public GetPurchaseRequestHeaderAppDTO objHeaderDTO { get; set; }
        public List<GetPurchaseRequestRowAppDTO> objRowListDTO { get; set; }
    }
}
