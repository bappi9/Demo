﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseRequestApproval
{
    public class EditPurchaseRequestApproveCommonDTO
    {
        public EditPurchaseRequestHeaderApprDTO objEditHeaderDTO { get; set; }
        public List<EditPurchaseRequestRowApprDTO> objListRowD { get; set; }
    }
}
