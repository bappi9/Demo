﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation.RFQEdit
{
    public class RFQEditHeaderDTO
    {
        public long RequestForQuotationId { get; set; }
        public long AccountId { get; set; }
        public string AccountName { get; set; }
        public long BusinessUnitId { get; set; }
        public string BusinessUnitName { get; set; }
        public long RequestTypeId { get; set; }
        public string RequestTypeName { get; set; }
        public long ActionBy { get; set; }
    }
}
