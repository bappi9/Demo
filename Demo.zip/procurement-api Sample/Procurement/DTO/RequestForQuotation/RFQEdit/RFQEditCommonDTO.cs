﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation.RFQEdit
{
    public class RFQEditCommonDTO
    {
        public RFQEditHeaderDTO objHeader { get; set; }
        public List<RFQEditRowDTO> objRow { get; set; }
        public List<RFQEditSupplierDTO> objSuppliers { get; set; }
    }
}
