﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation.RFQEdit
{
    public class RFQEditRowDTO
    {
        public long RowId { get; set; }
        public long RequestForQuotationId { get; set; }
        public long ItemId { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public long UoMid { get; set; }
        public string UoMname { get; set; }
        public decimal NumRfqquantity { get; set; }
        public long? ReferenceId { get; set; }
        public string ReferenceCode { get; set; }
        public decimal? NumReferenceQuantity { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
    }
}
