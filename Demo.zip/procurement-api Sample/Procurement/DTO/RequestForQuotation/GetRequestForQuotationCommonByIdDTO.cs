﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation
{
    public class GetRequestForQuotationCommonByIdDTO
    {
        public GetRequestForQuotationHeaderByIdDTO objHeader { get; set; }
        public List<GetRequestForQuotationRowDTO> objRow { get; set; }
        public List<GetSupplierListDTO> objSuplier { get; set; }
    }
}
