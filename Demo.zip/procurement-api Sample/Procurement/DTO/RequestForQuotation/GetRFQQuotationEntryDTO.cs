﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation
{
    public class GetRFQQuotationEntryDTO
    {
        public long partnerRFQId { get; set; }
        public long SL { get; set; }
        public long Rowid { get; set; }
        public long ItemId { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public long UomId { get; set; }
        public string UomName { get; set; }
        public string PurchaseDescription { get; set; }
        public decimal RFQQty { get; set; }
        public decimal? Rate { get; set; }
        public decimal? Value { get; set; }
        public string Comments { get; set; }
    }
}
