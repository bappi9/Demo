﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation
{
    public class GetRequestForQuotationByIdDTO
    {
        public long RequestForQuotationId { get; set; }
        public string RequestForQuotationCode { get; set; }
        public DateTime Rfqdate { get; set; }
        public long CurrencyId { get; set; }
        public string CurrencyCode { get; set; }
        public DateTime ValidTillDate { get; set; }
    }
}
