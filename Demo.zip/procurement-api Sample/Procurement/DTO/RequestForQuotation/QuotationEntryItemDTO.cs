﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation
{
    public class QuotationEntryItemDTO
    {
        public long ItemId { get; set; }
        public decimal Rate { get; set; }
        public string  Comments { get; set; }
    }
}
