﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation.RFQEntryPage
{
    public class CreateRFQEntryHeaderDTO
    {
        public long PartnerRFQId { get; set; }
        public long RequestForQuotationId { get; set; }
        public long AccountId { get; set; }
        public long BusinessUnitId { get; set; }
        public long BusinessPartnerId { get; set; }
        public string SupplierRefNo { get; set; }
        public DateTime SupplierRefDate { get; set; }
        
    }
}
