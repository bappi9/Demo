﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation.RFQEntryPage
{
    public class CreateRFQEntryRowDTO
    {
        public long RowId { get; set; }
        public decimal? NumRate { get; set; }
        public string Remarks { get; set; }
    }
}
