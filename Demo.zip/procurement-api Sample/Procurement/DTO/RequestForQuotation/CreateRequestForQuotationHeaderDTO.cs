﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation
{
    public class CreateRequestForQuotationHeaderDTO
    {
        public DateTime Rfqdate { get; set; }
        public long AccountId { get; set; }
        public string AccountName { get; set; }
        public long BusinessUnitId { get; set; }
        public string BusinessUnitName { get; set; }
        public long Sbuid { get; set; }
        public string Sbuname { get; set; }
        public long PurchaseOrganizationId { get; set; }
        public string PurchaseOrganizationName { get; set; }
        public long PlantId { get; set; }
        public string PlantName { get; set; }
        public long WarehouseId { get; set; }
        public string WarehouseName { get; set; }
        public long RequestTypeId { get; set; }
        public string RequestTypeName { get; set; }
        public string ReferenceTypeName { get; set; }
        public long CurrencyId { get; set; } 
        public DateTime ValidTillDate { get; set; } 
        public long ActionBy { get; set; }
        public DateTime LastActionDateTime { get; set; }
       
       
    }
}
