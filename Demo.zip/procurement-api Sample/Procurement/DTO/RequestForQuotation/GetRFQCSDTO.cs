﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation
{
    public class GetRFQCSDTO
    {
        public long SL { get; set; }
        public long RowId { get; set; }
        public long PartnerRfqid { get; set; }
        public long ItemId { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public long UomId { get; set; }
        public string UomName { get; set; }
        public string PurchaseDescription { get; set; }
        public decimal RFQQty { get; set; }
        public decimal? Rate { get; set; }
        public decimal? Value { get; set; }

        public long supplierId { get; set; }
        public string supplierName { get; set; }
        public string supplierRefNo { get; set; }
        public DateTime supplierRefDate { get; set; }
    }
}
