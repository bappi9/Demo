﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation
{
    public class GetRequestForQuotationRowDTO
    {
        public long RowId { get; set; }
        public long RequestForQuotationId { get; set; }
        public string RequestForQuotationCode { get; set; }
        public long ItemId { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public long UoMid { get; set; }
        public string UoMname { get; set; }
        public decimal Reqquantity { get; set; }
        public long? ReferenceId { get; set; }
        public string ReferenceCode { get; set; }
        public decimal? ReferenceQuantity { get; set; }
        public string Description { get; set; }
    }
}
