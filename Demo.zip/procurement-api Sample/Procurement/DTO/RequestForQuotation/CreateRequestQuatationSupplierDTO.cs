﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation
{
    public class CreateRequestQuatationSupplierDTO
    {
        
        public long BusinessPartnerId { get; set; }
        public string BusinessPartnerName { get; set; } 
        public string BusinessPartnerAddress { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        public bool IsEmailSend { get; set; }


    }
}
