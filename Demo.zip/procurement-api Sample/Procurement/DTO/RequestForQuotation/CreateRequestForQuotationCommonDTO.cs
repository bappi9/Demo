﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation
{
    public class CreateRequestForQuotationCommonDTO
    {
        public CreateRequestForQuotationHeaderDTO objHeader { get; set; }
        public List<CreateRequestForQuotationRowDTO> objRow { get; set; }
        public List<CreateRequestQuatationSupplierDTO> SupplierRow { get; set; }
        
    }
}
