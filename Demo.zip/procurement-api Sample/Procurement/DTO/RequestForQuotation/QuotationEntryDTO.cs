﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.RequestForQuotation
{
    public class QuotationEntryDTO
    {
        public long SupplierId { get; set; }
        public string SupplierReff { get; set; }
        public DateTime SupplierReffDate { get; set; }

        public IList<QuotationEntryItemDTO> QuotationItem { get; set; }
    }
}
