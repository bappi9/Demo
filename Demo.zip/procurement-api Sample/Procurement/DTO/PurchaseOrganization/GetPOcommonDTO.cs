﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrganization
{
    public class GetPOcommonDTO
    {
        public GetPurchaseOrganizationByIdDTO objHeader { get; set; }
        public List<GetPurchaseOrgRowDTO> objRow { get; set; }
    }
}
