﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrganization
{
    public class GetPurchaseOrganizationPasignationDTO
    {
        public long SL { get; set; }
        public long PurchaseOrganizationid { get; set; }
        public string PurchaseOrganization { get; set; }
    }
}
