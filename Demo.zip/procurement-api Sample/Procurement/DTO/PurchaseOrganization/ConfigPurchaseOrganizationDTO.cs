﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrganization
{
    public class ConfigPurchaseOrganizationDTO
    {
        public long ConfigId { get; set; }
        public long AccountId { get; set; }
        public long BusinessUnitId { get; set; }
        public string BusinessUnitName { get; set; }
        public string AccountName { get; set; }
        public long PurchaseOrganizationid { get; set; }
        public string PurchaseOrganization { get; set; }
        public DateTime LastActionDateTime { get; set; }
        public long ActionBy { get; set; }
        public bool? Active { get; set; }

    }
}
