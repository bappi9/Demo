﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseRequest
{
    public class EditPurchaseRequestStatusUpdate
    {
        [Required]
        [Range(1 , Int64.MaxValue , ErrorMessage = "The field {0} must be greater than {1}.")]
        public long PurchaseRequestId { get; set; }
        public long ActionBy { get; set; }
        public DateTime LastActionDateTime { get; set; }
        public bool? IsActive { get; set; }
    }
}
