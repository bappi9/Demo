﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseRequest
{
    public class EditPurchaseRequestHeaderDTO
    {
        public long PurchaseRequestId { get; set; }
        public string PurchaseRequestCode { get; set; }
        //public long PurchaseRequestTypeId { get; set; }
        //public string PurchaseRequestTypeName { get; set; }
        //public long AccountId { get; set; }
        //public string AccountName { get; set; }
        //public long BusinessUnitId { get; set; }
        //public string BusinessUnitName { get; set; }
        //public long Sbuid { get; set; }
        //public string Sbuname { get; set; }
        //public long PurchaseOrganizationId { get; set; }
        //public string PurchaseOrganizationName { get; set; }
        //public long PlantId { get; set; }
        //public string PlantName { get; set; }
        //public long WarehouseId { get; set; }
        //public string WarehouseName { get; set; }
        //public string DeliveryAddress { get; set; }
        //public long? SupplyingWarehouseId { get; set; }
        //public string SupplyingWarehouseName { get; set; }
        //public DateTime RequestDate { get; set; }
        //public bool? IsApproved { get; set; }
        //public long ApprovedBy { get; set; }
        //public string ApprovedByName { get; set; }
        //public DateTime ApprovedDateTime { get; set; }
        //public bool IsComplete { get; set; }
        //public bool IsClosed { get; set; }
        //public long ClosedBy { get; set; }
        //public string ClosedByName { get; set; }
        //public DateTime ClosedDateTime { get; set; }
        //public long ActionBy { get; set; }
        //public DateTime LastActionDateTime { get; set; }
        //public bool? IsActive { get; set; }
    }
}
