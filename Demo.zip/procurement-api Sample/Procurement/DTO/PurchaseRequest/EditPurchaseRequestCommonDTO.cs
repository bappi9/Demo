﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseRequest
{
    public class EditPurchaseRequestCommonDTO
    {
        public EditPurchaseRequestHeaderDTO objHeader { get; set; }
        public List<EditPurchaseRequestRowDTO> objRow { get; set; }
    }
}
