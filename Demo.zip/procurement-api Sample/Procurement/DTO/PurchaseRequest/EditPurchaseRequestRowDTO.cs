﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseRequest
{
    public class EditPurchaseRequestRowDTO
    {
        public long RowId { get; set; }
        public long ItemId { get; set; }
        public long UoMid { get; set; }
        public long PurchaseRequestId { get; set; }
        public string PurchaseRequestCode { get; set; }
        public string UoMname { get; set; }
        public decimal NumRequestQuantity { get; set; }
        public DateTime DteRequiredDate { get; set; }
        public long? CostElementId { get; set; }
        public string CostElementName { get; set; }
        public long? BillOfMaterialId { get; set; }
        public string Remarks { get; set; }
    }
}
