﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseRequest
{
    public class GetPurchaseRequestCommonDTO
    {
        public GetPurchaseRequestHeaderDTO GetPurchaseRequestHeader { get; set; }
        public List<GetPurchaseRequestRowDTO> GetPurchaseRequestRow { get; set; }
    }
}
