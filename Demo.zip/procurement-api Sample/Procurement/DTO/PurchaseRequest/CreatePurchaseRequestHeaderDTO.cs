﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseRequest
{
    public class CreatePurchaseRequestHeaderDTO
    {
        //public string PurchaseRequestCode { get; set; }
        public string ReffNo { get; set; }
        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long PurchaseRequestTypeId { get; set; }

        public string PurchaseRequestTypeName { get; set; }

        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long AccountId { get; set; }

        public string AccountName { get; set; }

        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long BusinessUnitId { get; set; }
        public string BusinessUnitName { get; set; }

        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long Sbuid { get; set; }
        public string Sbuname { get; set; }

        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long PurchaseOrganizationId { get; set; }
        public string PurchaseOrganizationName { get; set; }

        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long PlantId { get; set; }
        public string PlantName { get; set; }

        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long WarehouseId { get; set; }
        public string WarehouseName { get; set; }
        public string DeliveryAddress { get; set; }

        public long? SupplyingWarehouseId { get; set; }
        public string SupplyingWarehouseName { get; set; }

        public DateTime RequestDate { get; set; }

        public long ActionBy { get; set; }
        //public DateTime LastActionDateTime { get; set; }
        //public bool? IsActive { get; set; }
    }
}
