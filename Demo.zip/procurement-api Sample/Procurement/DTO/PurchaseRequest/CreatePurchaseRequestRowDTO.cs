﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseRequest
{
    public class CreatePurchaseRequestRowDTO
    {
        [Required]
        [Range(1 , Int64.MaxValue , ErrorMessage = "The field {0} must be greater than {1}.")]
        public long ItemId { get; set; }
        [Required]
        [Range(1 , Int64.MaxValue , ErrorMessage = "The field {0} must be greater than {1}.")]
        public long UoMid { get; set; }
        public string UoMname { get; set; }
        public decimal NumRequestQuantity { get; set; }
       
        public DateTime DteRequiredDate { get; set; }
        public long? CostElementId { get; set; }
        public string CostElementName { get; set; }

        public long? BillOfMaterialId { get; set; }
        public string Remarks { get; set; }
    }
}
