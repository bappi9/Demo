﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.SupplierInvoice
{
    public class GetSupplierInvoiceCommonDTOById
    {
        public GetSupplierInvoiceHeaderDTO objHeaderDTO { get; set; }
        public List<GetSupplierInvoiceRowDTO> objRowListDTO { get; set; }
    }
}
