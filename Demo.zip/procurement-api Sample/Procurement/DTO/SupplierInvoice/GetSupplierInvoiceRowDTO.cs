﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.SupplierInvoice
{
    public class GetSupplierInvoiceRowDTO
    {
        public long RowId { get; set; }
        public long SupplierInvoiceId { get; set; }
        public long ReferenceId { get; set; }
        public string ReferenceName { get; set; }
        public decimal ReferenceAmount { get; set; }
        public long ActionBy { get; set; }
     
    }
}
