﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.SupplierInvoice
{
    public class EditSupplierInvoiceRowDTO
    {
        [Required]
        [Range(0, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long RowId { get; set; }
        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long SupplierInvoiceId { get; set; }
        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long ReferenceId { get; set; }
        public decimal ReferenceAmount { get; set; }
        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long ActionBy { get; set; }
    }
}
