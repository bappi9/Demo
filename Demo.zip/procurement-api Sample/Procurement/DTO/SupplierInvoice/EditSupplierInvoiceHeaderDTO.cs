﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.SupplierInvoice
{
    public class EditSupplierInvoiceHeaderDTO
    {
        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long SupplierInvoiceId { get; set; }

        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long AccountId { get; set; }

        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long BusinessUnitId { get; set; }

        public decimal TotalReferenceAmount { get; set; }
        public decimal GrossInvoiceAmount { get; set; }
        public decimal DeductionAmount { get; set; }
        public decimal NetPaymentAmount { get; set; }
        public string Remarks { get; set; }
        public string AttachmentId { get; set; }

    }
}
