﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.SupplierInvoice
{
    public class EditSupplierInvoiceCommonDTO
    {
        public EditSupplierInvoiceHeaderDTO HeaderData { get; set; }
        public List<EditSupplierInvoiceRowDTO> RowData { get; set; }
    }
}
