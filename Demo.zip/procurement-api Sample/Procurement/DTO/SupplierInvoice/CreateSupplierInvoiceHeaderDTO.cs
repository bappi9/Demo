﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.SupplierInvoice
{
    public class CreateSupplierInvoiceHeaderDTO
    {
        public long SupplierInvoiceId { get; set; }
        public string SupplierInvoiceCode { get; set; }
        public long AccountId { get; set; }
        public long BusinessUnitId { get; set; }
        public string BusinessUnitName { get; set; }
        public long Sbuid { get; set; }
        public string Sbuname { get; set; }
        public long PurchaseOrganizationId { get; set; }
        public string PurchaseOrganizationName { get; set; }
        public long PlantId { get; set; }
        public string PlantName { get; set; }
        public long WarehouseId { get; set; }
        public string WarehouseName { get; set; }
        public long BusinessPartnerId { get; set; }
        public long PurchaseOrderId { get; set; }
        public string PurchaseOrderNo { get; set; }
        public DateTime PurchaseOrderDate { get; set; }
        public string InvoiceNumber { get; set; }
        public DateTime InvoiceDate { get; set; }
        public decimal TotalReferenceAmount { get; set; }
        public decimal GrossInvoiceAmount { get; set; }
        public decimal DeductionAmount { get; set; }
        public decimal? AdvanceAdjustmentAmount { get; set; }
        public decimal NetPaymentAmount { get; set; }
        public DateTime PaymentDueDate { get; set; }
        public string Remarks { get; set; }
        public long ActionBy { get; set; }
        public DateTime LastActionDateTime { get; set; }
        public DateTime ServerDateTime { get; set; }
        public bool Active { get; set; }
        public string AttachmentId { get; set; }
    }
}
