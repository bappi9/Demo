﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.SupplierInvoice
{
    public class CreateSupplierInvoiceRowDTO
    {
        
        public long ReferenceId { get; set; }
        public decimal ReferenceAmount { get; set; }
        public long ActionBy { get; set; }
        public DateTime LastActionDateTime { get; set; }
        public DateTime ServerDateTime { get; set; }
        public bool Active { get; set; }
    }
}
