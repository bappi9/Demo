﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrder
{
    public class GetPurchaseOrderPIDDLDTO
    {
        public long IntPurchaseOrderId { get; set; }
        public string IntPurchaseOrderNumber { get; set; }
        public decimal TotalPOAmount { get; set; }
        public long PlantId { get; set; }
        public string Plant { get; set; }
        public long PurchaseOrganizationId { get; set; }
        public string PurchaseOrganizationName { get; set; }
        public long WarehouseId { get; set; }
        public string WarehouseName { get; set; }
        public long SupplierId { get; set; }
        public string SupplierName { get; set; }
    }
}
