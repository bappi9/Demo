﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrder
{
    public class GetPriceStructureRowDTO
    {
        public long RowId { get; set; }
        public long PriceStructureId { get; set; }
        public long PriceComponentId { get; set; }
        public string PriceComponentCode { get; set; }
        public string ValueType { get; set; }
        public decimal Value { get; set; }
        public decimal Amount { get; set; }
        public long? BaseComponentId { get; set; }
        public long SerialNo { get; set; }
        public long SumFromSerial { get; set; }
        public long SumToSerial { get; set; }
        public bool Mannual { get; set; }
        public bool? Active { get; set; }
    }
}
