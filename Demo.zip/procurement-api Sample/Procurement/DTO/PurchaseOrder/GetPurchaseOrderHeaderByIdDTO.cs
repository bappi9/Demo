﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrder
{
    public class GetPurchaseOrderHeaderByIdDTO
    {
        public long PurchaseOrderId { get; set; }
        public string PurchaseOrderNo { get; set; }
        public long AccountId { get; set; }
        public long BusinessUnitId { get; set; }
        public long PurchaseOrderTypeId { get; set; }
        public string PurchaseOrderTypeName { get; set; }
        public DateTime PurchaseOrderDate { get; set; }
        public long PlantId { get; set; }
        public string PlantName { get; set; }
        public long WarehouseId { get; set; }
        public string WarehouseName { get; set; }
        public long? SupplyingWarehouseId { get; set; }
        public string SupplyingWarehouseName { get; set; }
        public long PurchaseOrganizationId { get; set; }
        public string PurchaseOrganizationName { get; set; }
        public long BusinessPartnerId { get; set; }
        public string SupplierName { get; set; }
        public string SupplierAddress { get; set; }
        public string SupplierReference { get; set; }
        public DateTime? ReferenceDate { get; set; }
        public string DeliveryAddress { get; set; }
        public bool? YsnPartialShipment { get; set; }
        public long NumberOfShipments { get; set; }

        public long IncotermsId { get; set; }
        public string IncotermsName { get; set; }
        public long CurrencyId { get; set; }
        public string CurrencyCode { get; set; }
       
        public long ReferenceTypeId { get; set; }
        public string ReferenceTypeName { get; set; }
        public long PaymentTerms { get; set; }
        public string PaymentTermsName { get; set; }
        public long CreditPercent { get; set; }
        public long CashOrAdvancePercent { get; set; }
        public string OtherTerms { get; set; }
        
        public DateTime LastShipmentDate { get; set; }
        public long PaymentDaysAfterDelivery { get; set; }
        public DateTime ValidityDate { get; set; }
        public DateTime ReturnDate { get; set; }
        public long SBUId { get; set; }
        public string SBUName { get; set; }
        public long ActionBy { get; set; }
    }
}
