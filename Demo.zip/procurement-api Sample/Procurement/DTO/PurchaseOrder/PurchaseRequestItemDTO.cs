﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrder
{
    public class PurchaseRequestItemDTO
    {
        public long? Value { get; set; }
        public string Label { get; set; }
        public string Description { get; set; }
        public decimal RestofQty { get; set; }
        public decimal refQty { get; set; }
        public long UOM { get; set; }
        public string UOMName { get; set; }
    }
}
