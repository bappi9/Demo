﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrder
{
    public class EditPurchaseOrderHeaderDTO
    {
        [Range(0, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        [Required]
        public long PurchaseOrderId { get; set; }
        public string PurchaseOrderNo { get; set; }
        public long AccountId { get; set; }
        public long BusinessUnitId { get; set; }

        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long SbuId { get; set; }

        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long PlantId { get; set; }
        public string PlantName { get; set; }
        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long WarehouseId { get; set; }
        public string WarehouseName { get; set; }
        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]

        public long PurchaseOrganizationId { get; set; }
        
        public long BusinessPartnerId { get; set; }
        public DateTime PurchaseOrderDate { get; set; }
        public long PurchaseOrderTypeId { get; set; }
        
        public long IncotermsId { get; set; }
        
        public long CurrencyId { get; set; }
        public string CurrencyCode { get; set; }

        public string SupplierReference { get; set; }
        public DateTime? ReferenceDate { get; set; }
        public long ReferenceTypeId { get; set; }
        public long? PriceStructureId { get; set; }
        public long PaymentTerms { get; set; }
        public long CreditPercent { get; set; }
        public long CashOrAdvancePercent { get; set; }
        public string OtherTerms { get; set; }
        public DateTime POValidityDate { get; set; }
        public DateTime ReturnDate { get; set; }
        public DateTime LastShipmentDate { get; set; }
        public long PaymentDaysAfterDelivery { get; set; }
        public string DeliveryAddress { get; set; }
        public long ActionBy { get; set; }
        public long SupplyingWarehouseId { get; set; }
        public string SupplyingWarehouseName { get; set; }
    }
}
