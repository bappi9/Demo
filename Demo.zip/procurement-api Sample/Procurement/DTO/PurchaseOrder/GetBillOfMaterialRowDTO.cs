﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrder
{
    public class GetBillOfMaterialRowDTO
    {
        public long RowId { get; set; }
        public long BillOfMaterialId { get; set; }
        public long ItemId { get; set; }
        public long UnitOfMeasureId { get; set; }
        public decimal Quantity { get; set; }
        public decimal NetWeightKg { get; set; }
    }
}
