﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrder
{
    public class GetBillOfMaterialCommonDTO
    {
        public GetBillOfMaterialHeaderDTO objHeaderDTO { get; set; }
        public List<GetBillOfMaterialRowDTO> objRowListDTO { get; set; }
    }
}
