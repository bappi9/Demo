﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrder
{
    public class getBOMDTO
    {
        public long BOMId { get; set; }
        public string BOMCode { get; set; }
        public string BOMName { get; set; }
        public long ItemId { get; set; }
        public string ItemName { get; set; }
        public long OutUnitOfMesurement { get; set; }
        public decimal LotSize { get; set; }
        public decimal NetWeight { get; set; }
        public string Remarks { get; set; }
        public long Value { get; set; }
        public string Label { get; set; }
        public string Code { get; set; }
    }
}
