﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrder
{
    public class GetBillOfMaterialHeaderDTO
    {
        public long BillOfMaterialId { get; set; }
        public string BillOfMaterialCode { get; set; }
        public string BillOfMaterialName { get; set; }
        public string PlantName { get; set; }
        public string ItemName { get; set; }
        public long OutUnitOfMeasure { get; set; }
        public decimal NetWeightKg { get; set; }
        public decimal Quantity { get; set; }
    }
}
