﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrder
{
    public class GetPriceStructureHeaderDTO
    {
        public long PriceStructureId { get; set; }
        public string PriceStructureCode { get; set; }
        public string PriceStructureName { get; set; }
        public long PriceStructureTypeId { get; set; }
        public bool? Active { get; set; }
    }
}
