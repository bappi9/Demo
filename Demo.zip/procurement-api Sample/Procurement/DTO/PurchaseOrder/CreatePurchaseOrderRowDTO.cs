﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrder
{
    public class CreatePurchaseOrderRowDTO
    {
        public long ReferenceId { get; set; }
        public string ReferenceCode { get; set; }
        public decimal ReferenceQty { get; set; }
        public long ItemId { get; set; }
        public string ItemName { get; set; }
        public long UoMid { get; set; }
        public string UoMname { get; set; }
        public long? ControllingUnitId { get; set; }
        public string ControllingUnitName { get; set; }
        public long? CostCenterId { get; set; }
        public string CostCenterName { get; set; }
        public long? CostElementId { get; set; }
        public string CostElementName { get; set; }
        public string PurchaseDescription { get; set; }
        public decimal OrderQty { get; set; }
        public decimal BasePrice { get; set; }
        public decimal FinalPrice { get; set; }
        public decimal TotalValue { get; set; }
        public long ActionBy { get; set; }
        public DateTime LastActionDateTime { get; set; }
        public long BomId { get; set; }
        
        //public List<CreatePurchaseOrderRowPricingDetailDTO> objPriceRowListDTO { get; set; }
        public List<GetPriceStructureByPartnerDTO> objPriceRowListDTO { get; set; }
    }
}
