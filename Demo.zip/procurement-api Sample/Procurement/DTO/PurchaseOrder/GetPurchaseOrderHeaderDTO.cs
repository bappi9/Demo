﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.PurchaseOrder
{
    public class GetPurchaseOrderHeaderDTO
    {
        public int Sl { get; set; }
        public long PurchaseOrderId { get; set; }
        public string PurchaseOrderNo { get; set; }
        public DateTime PurchaseOrderDate { get; set; }
        public string DeliveryAddress { get; set; }
        public long CurrencyId { get; set; }
        public string CurrencyName { get; set; }
        public long PaymentTerms { get; set; }
        public string PaymentTermsName { get; set; }
        public DateTime ValidityDate { get; set; }
        public bool? IsApprove { get; set; }
        public long PurchaseOrganizationId { get; set; }
        public string PurchaseOrganizationName { get; set; }
        public long SupplierId { get; set; }
        public string SupplierName { get; set; }
        public string SupplierAddress { get; set; }
        public long NumberOfShipments { get; set; }
        
        
        
    }
}
