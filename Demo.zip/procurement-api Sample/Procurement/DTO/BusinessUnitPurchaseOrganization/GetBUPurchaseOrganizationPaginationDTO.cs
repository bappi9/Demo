﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.BusinessUnitPurchaseOrganization
{
    public class GetBUPurchaseOrganizationPaginationDTO
    {
        public List<GetBusinessUnitPurchaseOrganizationDTO> Data { get; set; }
        public long currentPage { get; set; }
        public long totalCount { get; set; }
        public long pageSize { get; set; }
    }
}
