﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.BusinessUnitPurchaseOrganization
{
    public class EditBusinessUnitPurchaseOrganizationDTO
    {
        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long ConfigId { get; set; }
        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long PurchaseOrganizationid { get; set; }
        public string PurchaseOrganization { get; set; }
        [Required]
        [Range(1, Int64.MaxValue, ErrorMessage = "The field {0} must be greater than {1}.")]
        public long ActionBy { get; set; }
      
    }
}
