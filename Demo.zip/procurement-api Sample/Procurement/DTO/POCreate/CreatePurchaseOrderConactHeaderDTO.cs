﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.POCreate
{
    public class CreatePurchaseOrderConactHeaderDTO
    {
        //public long PurchaseContractId { get; set; }
        //public string PurchaseContractNo { get; set; }
        public long AccountId { get; set; }
        public long BusinessUnitId { get; set; }
        public long PlantId { get; set; }
        public string PlantName { get; set; }
        public long SbuId { get; set; }
        public long WarehouseId { get; set; }
        public string WarehouseName { get; set; }
        public long PurchaseOrganizationId { get; set; }
        public long BusinessPartnerId { get; set; }
        public DateTime PurchaseContractDate { get; set; }
        public long CurrencyId { get; set; }
        public string CurrencyCode { get; set; }
        public long ReferenceTypeId { get; set; }
        public long ReferenceId { get; set; }
        public string ReferenceCode { get; set; }
        public long? PaymentTerms { get; set; }
        public int? CreditPercent { get; set; }
        public int? CashOrAdvancePercent { get; set; }
        public long? IncotermsId { get; set; }
        public string SupplierReference { get; set; }
        public DateTime? ReferenceDate { get; set; }
        public string ItemGroupName { get; set; }
        public string ContractType { get; set; }
        public DateTime? PcvalidityDate { get; set; }
        public string OtherTerms { get; set; }
        public long ApproveBy { get; set; }
        public DateTime ApproveDatetime { get; set; }
        public DateTime LastShipmentDate { get; set; }
        public long PaymentDaysAfterDelivery { get; set; }
        public string DeliveryAddress { get; set; }
        public long ActionBy { get; set; }
        public DateTime LastActionDateTime { get; set; }
    }
}
