﻿using Procurement.DTO.PurchaseOrder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.POCreate
{
    public class CreatePurchaseContactRowDTO
    {
        public long PurchaseContractId { get; set; }
        public long ReferenceId { get; set; }
        public string ReferenceCode { get; set; }
        public long ItemId { get; set; }
        public string ItemName { get; set; }
        public long UoMid { get; set; }
        public string UoMname { get; set; }
        public string PurchaseDescription { get; set; }
        public decimal ReferenceQty { get; set; }
        public decimal ContractQty { get; set; }
        public decimal BasePrice { get; set; }
        public decimal FinalPrice { get; set; }
        public decimal TotalValue { get; set; }
        public long ActionBy { get; set; }
        public DateTime LastActionDateTime { get; set; }
        public DateTime DeliveryDateTime { get; set; }
        public List<GetPriceStructureByPartnerDTO> objListCPCPriceingDetailsDTO { get; set; }
    }
}
