﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.POCreate
{
    public class EditPurchaseContactCommonDTO
    {
        public EditPurchaseContactHeaderDTO HeaderDTO { get; set; }
        public List<EditPurchaseContactRowDTO> RowListDTO { get; set; }
    }
}
