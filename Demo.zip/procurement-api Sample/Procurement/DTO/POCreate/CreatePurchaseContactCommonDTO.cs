﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.POCreate
{
    public class CreatePurchaseContactCommonDTO
    {
        public CreatePurchaseOrderConactHeaderDTO objCPCHeaderDTO { get; set; }
        public List<CreatePurchaseContactRowDTO> objListCPCRowDTO { get; set; }
        //public List<CreatePurchaseContactPriceingDetailsDTO> objListCPCPriceingDetailsDTO { get; set; }
    }
}
