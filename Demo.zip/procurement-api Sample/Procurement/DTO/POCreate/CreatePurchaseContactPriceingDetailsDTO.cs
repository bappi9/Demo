﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.POCreate
{
    public class CreatePurchaseContactPriceingDetailsDTO
    {
        public long PurchaseContractRowId { get; set; }
        public long PriceComponentId { get; set; }
        public string PriceComponentCode { get; set; }
        public string PriceComponentName { get; set; }
        public long Sequence { get; set; }
        public decimal BaseAmount { get; set; }
        public decimal PercentOnBase { get; set; }
        public decimal Amount { get; set; }
        public decimal NextBaseAmount { get; set; }
        public bool Manual { get; set; }
    }
}
