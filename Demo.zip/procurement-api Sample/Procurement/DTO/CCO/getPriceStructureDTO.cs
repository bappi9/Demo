﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.CCO
{
    public class getPriceStructureDTO
    {
        public long PriceStructureId { get; set; }
        public string PriceStructureName { get; set; }
        public long PriceComponentId { get; set; }
        public string PriceComponentCode { get; set; }
        public string PriceComponentName { get; set; }
        public string ValueType { get; set; }
        public decimal Value { get; set; }
        public long? BaseComponentId { get; set; }
        public long SerialNo { get; set; }
        public long SumFromSerial { get; set; }
        public long SumToSerial { get; set; }
        public bool Mannual { get; set; }

    }
}
