﻿using Procurement.DTO.PurchaseOrder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.CCO
{
    public class getPurchaseContractHeaderDTO
    {
        

        public GetPurchaseContactHeaderDataDTO objHeaderDTO { get; set; }
        public List<GetPurchaseContactRowDTO> objRowListDTO { get; set; }
    }
}
