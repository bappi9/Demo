﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO
{
    public class ApprovalLandingDTO
    {
        public long Sl { get; set; }
        public long TransectionId { get; set; }
        public DateTime TransectionDate { get; set; }
        public string ReffCode { get; set; }
        public string Description { get; set; }
        public DateTime ? DueDate { get; set; }
        public decimal Quantity { get; set; }
        public decimal Amount { get; set; }
        
    }
}
