﻿using Procurement.DTO.PurchaseRequest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.DTO.LandingPasignation
{
    public class purchaseRequestPasignation
    {
        public List<GetPurchaseRequestHeaderDTO> Data { get; set; }

        public long currentPage { get; set; }
        public long totalCount { get; set; }
        public long pageSize { get; set; }
    }
}
