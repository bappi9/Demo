﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain.Core.Bus;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Procurement.DTO.PurchaseOrganization;
using Procurement.Helper;
using Procurement.IRepository;
using Swashbuckle.AspNetCore.Annotations;

namespace Procurement.Controllers
{
    [Route("procurement/[controller]")]
    [ApiController]
    public class PurchaseOrganizationController : ControllerBase
    {
        private readonly IEventBus _bus;
        private readonly IMediator _mediator;
        private readonly IPurchaseOrganization _IRepository;

        public PurchaseOrganizationController(IMediator mediator, IEventBus bus, IPurchaseOrganization IRepository)
        {
            _bus = bus;
            _mediator = mediator;
            _IRepository = IRepository;
        }

        [HttpPost]
        [Route("CreatePurchaseOrganization")]
        [SwaggerOperation(Description = "Example {} ")]
        public async Task<MessageHelper> CreatePurchaseOrganization(CreatePurchaseOrganizationDTO objCPO)
        {
            try
            {
                var msg = await _IRepository.CreatePurchaseOrganization(objCPO);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        [Route("ConfigPurchaseOrganization")]
        [SwaggerOperation(Description = "Example {} ")]
        public async Task<MessageHelper> ConfigPurchaseOrganization(List<ConfigPurchaseOrganizationDTO> objConfigCPO)
        {
            try
            {
                var msg = await _IRepository.ConfigPurchaseOrganization(objConfigCPO);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPut]
        [Route("UpdatePurchaseOrganization")]
        [SwaggerOperation(Description = "Example {} ")]
        public async Task<MessageHelper> UpdatePurchaseOrganization(UpdatePurchaseOrganizationDTO objUpdateConfigCPO)
        {
            try
            {
                var msg = await _IRepository.UpdatePurchaseOrganization(objUpdateConfigCPO);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPurchaseOrganizationPasignation")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetPurchaseOrganizationPasignation(long AccountId, bool status, string viewOrder, long PageNo, long PageSize)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseOrganizationPasignation (AccountId, status, viewOrder, PageNo, PageSize);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt); 
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpGet]
        [Route("GetConfigPurchaseOrganizationPasignation")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetConfigPurchaseOrganizationPasignation(long AccountId,  bool status, string viewOrder, long PageNo, long PageSize)
        {
            try
            {
                var dt = await _IRepository.GetConfigPurchaseOrganizationPasignation(AccountId, status, viewOrder, PageNo, PageSize);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt); 
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPurchaseOrganizationById")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetPurchaseOrganizationById( long POId)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseOrganizationById( POId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPurchaseOrganizationViewDataByPOId")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetPurchaseOrganizationViewDataByPOId(long POId)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseOrganizationViewDataByPOId( POId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpGet]
        [Route("GetPurchaseOrganizationList")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetPurchaseOrganizationList(long UnitId)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseOrganizationList(UnitId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}