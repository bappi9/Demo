﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Procurement.DTO.PaymentRequest;
using Procurement.Helper;
using Procurement.IRepository;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Procurement.Controllers
{
    [Route("procurement/[controller]")]
    [ApiController]
    public class PaymentRequestController : ControllerBase
    {
        private readonly IPayemntRequest _Repository;

        public PaymentRequestController(IPayemntRequest Repository)
        {

            _Repository = Repository;
        }
        [HttpGet]
        [Route("PaymentRequestLanding")] 
        public async Task<ActionResult> PaymentRequestLanding(long BusinessUnitId, long PlantId, long UserId, string viewOrder, long PageNo, long PageSize)
        {
            try
            {
                var data = await _Repository.PaymentRequestLanding(BusinessUnitId, PlantId, UserId, viewOrder,PageNo,PageSize);

                return Ok(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpGet]
        [Route("PurchaseInvoiceDetails")]
        
        public async Task<ActionResult> PurchaseInvoiceDetails(long InvoiceId)
        {
            try
            {
                var data = await _Repository.PurchaseInvoiceDetails(InvoiceId);

                return Ok(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetCPurchaseGridData")]
        public async Task<IActionResult> GetCPurchaseGridData(long AccountId, long BusinessUnitId, long SBUId, long PartnerId, long CashGLId, decimal CashAmount, long BankAccId)
        {
            try
            {
                var dt = await _Repository.GetCPurchaseGridData(AccountId, BusinessUnitId, SBUId, PartnerId, CashGLId, CashAmount, BankAccId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        [Route("CreateCashBankPayment")]
        [SwaggerOperation(Description = "Example { ")]
        public async Task<MessageHelper> CreateCashBankPayment(CreateCashPaymentCommonDTO objCreate)
        {
            try
            {
                var msg = await _Repository.CreateCashBankPayment(objCreate);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
