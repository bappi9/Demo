﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Procurement.DbContexts;
using Procurement.FunctionalService;
using Swashbuckle.AspNetCore.Annotations;

namespace Procurement.Controllers
{
    [Route("procurement/[controller]")]
    [ApiController]
    public class ApprovalController : ControllerBase
    {

        private readonly ApprovalTransections _Repository;
        public readonly ReadDbContext _contextR;

        public ApprovalController(ApprovalTransections Repository, ReadDbContext contextR)
        {

            _Repository = Repository;
            _contextR = contextR;
        }


        [HttpGet]
        [Route("GetPurchaseOrderApprovalList")]
        [SwaggerOperation(Description = "Example {}")]
        public async Task<ActionResult> GetPurchaseOrderApprovalList(long ActivityId, string ActivityName, long UserId, string viewOrder, long PageNo, long PageSize)
        {
            try
            {
                var data = await _Repository.ApprovalTransectionList(ActivityId, ActivityName, UserId, viewOrder, PageNo, PageSize);

                return Ok(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPut]
        [Route("DynamicApproval")]
        [SwaggerOperation(Description = "Example {}")]
        public async Task<ActionResult> DynamicApproval(long ActivityId, long PoId, long BusinessUnitId, long UserId)
        {
            try
            {
                long PRActivityId = _contextR.TblModuleFeature.FirstOrDefault(a => a.StrFeatureName == "Purchase Request").IntFeatureId;
                long POActivityId = _contextR.TblModuleFeature.FirstOrDefault(a => a.StrFeatureName == "Purchase Order").IntFeatureId;
                long IRActivityId = _contextR.TblModuleFeature.FirstOrDefault(a => a.StrFeatureName == "Item Request").IntFeatureId;
                if (ActivityId == PRActivityId)
                {
                    //Purchase Request
                    await _Repository.PurcahseRequestApproval(ActivityId, PoId, BusinessUnitId, UserId);

                }

                else if (ActivityId == POActivityId)
                {
                    //Purchase Order
                    await _Repository.PoApproval(ActivityId, PoId, BusinessUnitId, UserId);
                }
                else if (ActivityId == IRActivityId)
                {
                    //Item Request
                    await _Repository.ItemRequestApproval(ActivityId, PoId, BusinessUnitId, UserId);
                }


                return Ok("Submitted Successfully");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
