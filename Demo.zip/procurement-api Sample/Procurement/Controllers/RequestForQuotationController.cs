﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain.Core.Bus;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Procurement.DTO.RequestForQuotation;
using Procurement.DTO.RequestForQuotation.RFQEdit;
using Procurement.DTO.RequestForQuotation.RFQEntryPage;
using Procurement.Helper;
using Procurement.IRepository;
using Swashbuckle.AspNetCore.Annotations;

namespace Procurement.Controllers
{
    [Route("procurement/[controller]")]
    [ApiController]
    public class RequestForQuotationController : ControllerBase
    {
        private readonly IEventBus _bus;
        private readonly IMediator _mediator;
        private readonly IRequestForQuotation _IRepository;

        public RequestForQuotationController(IMediator mediator, IEventBus bus, IRequestForQuotation IRepository)
        {
            _bus = bus;
            _mediator = mediator;
            _IRepository = IRepository;
        }


        [HttpPost]
        [Route("CreateRequestForQuotation")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> CreateRequestForQuotation(CreateRequestForQuotationCommonDTO objRfq)
        {
            try
            {
                var msg = await _IRepository.CreateRequestForQuotation(objRfq);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpPut]
        [Route("EditRequestForQuotation")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> EditRequestForQuotation(RFQEditCommonDTO objRFQ)
        {
            try
            {
                var msg = await _IRepository.EditRequestForQuotation( objRFQ);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpPost]
        [Route("CreateRFQEntryPage")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> CreateRFQEntryPage(CreateCommonRFQEntryPage postRFQ)
        {
            try
            {
                var msg = await _IRepository.CreateRFQEntryPage(postRFQ);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetRequestForQuotationPasignation")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetRequestForQuotationPasignation(long AccountId, long UnitId, long RequestTypeId, long SBUId, long PurchaseOrganizationId, long PlantId, long WearHouseId, bool status, string viewOrder, long PageNo, long PageSize)
        {
            try
            {
                var dt = await _IRepository.GetRequestForQuotationPasignation(AccountId, UnitId, RequestTypeId, SBUId, PurchaseOrganizationId, PlantId, WearHouseId, status, viewOrder, PageNo, PageSize);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetRFQCS")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetRFQCS( long RequestForQuotationId)
        {
            try
            {
                var dt = await _IRepository.GetRFQCS( RequestForQuotationId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        [HttpGet]
        [Route("GetRFQQuotationEntry")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetRFQQuotationEntry(long AccountId, long BusinessUnitId, long RFQId, bool status, string viewOrder, long PageNo, long PageSize)
        {
            try
            {
                var dt = await _IRepository.GetRFQQuotationEntry(AccountId, BusinessUnitId, RFQId, status, viewOrder, PageNo, PageSize);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetRequestForQuotationById")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetRequestForQuotationById(long RequestForQuotationId)
        {
            try
            {
                var dt = await _IRepository.GetRequestForQuotationById( RequestForQuotationId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        [HttpGet]
        [Route("GetRFQSupplierDDL")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetRFQSupplierDDL(long AccountId, long BusinessUnitId, long RequestForQuotationId)
        {
            try
            {
                var dt = await _IRepository.GetRFQSupplierDDL(AccountId, BusinessUnitId, RequestForQuotationId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        [HttpGet]
        [Route("GetRFQUOMDDL")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetRFQUOMDDL(long AccountId, long BusinessUnitId, long ItemId)
        {
            try
            {
                var dt = await _IRepository.GetRFQUOMDDL(AccountId, BusinessUnitId, ItemId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }       
        
        [HttpGet]
        [Route("GetRFQItemDDL")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetRFQItemDDL(long AccountId, long BusinessUnitId, long SBUId, long PurchaseOrganizationId, long PlantId, long WearHouseId, long PurchaseRequestId,string Referrence)
        {
            try
            {
                var dt = await _IRepository.GetRFQItemDDL(AccountId, BusinessUnitId, SBUId, PurchaseOrganizationId, PlantId, WearHouseId, PurchaseRequestId, Referrence);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        


        [HttpGet]
        [Route("GetPRReferrenceNoDDL")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetPRReferrenceNoDDL(long AccountId, long BusinessUnitId, long SBUId, long PurchaseOrganizationId, long PlantId, long WearHouseId)
        {
            try
            {
                var dt = await _IRepository.GetPRReferrenceNoDDL(AccountId, BusinessUnitId, SBUId, PurchaseOrganizationId, PlantId, WearHouseId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}