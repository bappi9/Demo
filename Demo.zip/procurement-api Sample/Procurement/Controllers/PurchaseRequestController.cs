﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain.Core.Bus;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Procurement.DTO.PurchaseRequest;
using Procurement.Helper;
using Procurement.IRepository;
using Swashbuckle.AspNetCore.Annotations;

namespace Procurement.Controllers
{
    [Route("procurement/[controller]")]
    [ApiController]
    public class PurchaseRequestController : ControllerBase
    {

        private readonly IEventBus _bus;
        private readonly IMediator _mediator;
        public readonly IPurchaseRequest _IRepository;
        public PurchaseRequestController(IMediator mediator , IEventBus bus , IPurchaseRequest IRepository)
        {
            _bus = bus;
            _mediator = mediator;
            _IRepository = IRepository;
        }


        [HttpPost]
        [Route("CreatePurchaseRequestInfo")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> CreatePurchaseRequestInfo(CratePruchaseRequestCommonDTO createPurchaseRequestCommonDTO)
        {
            try
            {
                var msg = await _IRepository.CreatePurchaseRequestInfo(createPurchaseRequestCommonDTO);
                return msg;
            }
            catch ( Exception ex )
            {
                throw ex;
            }
        }

        [HttpPut]
        [Route("EditPurchaseRequest")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> EditPurchaseRequest(EditPurchaseRequestCommonDTO editPurchaseRequestCommonDTO)
        {
            try
            {
                var msg = await _IRepository.EditPurchaseRequest(editPurchaseRequestCommonDTO);
                return msg;
            }
            catch ( Exception ex )
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPurchaseRequestInformationPasignation")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetPurchaseRequestInformationPasignation(string search,long AccountId , long BusinessUnitId ,string viewOrder , long PageNo , long PageSize)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseRequestInformationPasignation(search, AccountId, BusinessUnitId,viewOrder , PageNo , PageSize);
                if ( dt == null )
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch ( Exception ex )
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPurchaseRequestInformation")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetPurchaseRequestInformation(long AccountId , long BusinessUnitId , long plant , long Whouse)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseRequestInformation(AccountId , BusinessUnitId , plant , Whouse );
                if ( dt == null )
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch ( Exception ex )
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPurchaseRequestInformationByRequestId")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetPurchaseRequestInformationByRequestId( long RequestId)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseRequestInformationByRequestId( RequestId );
                if ( dt == null )
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch ( Exception ex )
            {
                throw ex;
            }
        }

        [HttpPut]
        [Route("UpdatePurchaseRequestStatus")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> UpdatePurchaseRequestStatus(EditPurchaseRequestStatusUpdate updatePurchaseRequestStatusDTO)
        {
            try
            {
                var msg = new MessageHelper();
                msg = await _IRepository.UpdatePurchaseRequestStatus(updatePurchaseRequestStatusDTO);

                return msg;
            }
            catch ( Exception ex )
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPurchaseRequestTypeListDDL")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetPurchaseRequestTypeListDDL()
        {
            try
            {
                var dt = await _IRepository.GetPurchaseRequestTypeListDDL();
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPurchaseRequestInformationSearchPasignation")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetPurchaseRequestInformationSearchPasignation(string searchTerm, long AccountId, long BusinessUnitId, string viewOrder, long PageNo, long PageSize)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseRequestInformationSearchPasignation(searchTerm, AccountId, BusinessUnitId, viewOrder, PageNo, PageSize);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}