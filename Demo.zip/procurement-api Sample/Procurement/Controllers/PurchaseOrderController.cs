﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain.Core.Bus;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Procurement.DTO.POCreate;
using Procurement.DTO.PurchaseOrder;
using Procurement.Helper;
using Procurement.IRepository;
using Swashbuckle.AspNetCore.Annotations;

namespace Procurement.Controllers
{
    [Route("procurement/[controller]")]
    [ApiController]
    public class PurchaseOrderController : ControllerBase
    {

        private readonly IEventBus _bus;
        private readonly IMediator _mediator;
        public readonly IPurchaseOrder _IRepository;
        public PurchaseOrderController(IMediator mediator , IEventBus bus , IPurchaseOrder IRepository)
        {
            _bus = bus;
            _mediator = mediator;
            _IRepository = IRepository;
        }


        [HttpPost]
        [Route("CreateStanderdAssetServicePurchaseOrder")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> CreateStanderdAssetServicePurchaseOrder(CreatePurchaseOrderCommonDTO objPO)
        {
            try
            {
                var msg = await _IRepository.CreateStanderdAssetServicePurchaseOrder(objPO);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetCurrencyListDDL")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetCurrencyListDDL(long AccountId,long UnitId)
        {
            try
            {
                var dt = await _IRepository.GetCurrencyListDDL(AccountId,UnitId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                 throw ex;
            }
        }
      
        [HttpGet]
        [Route("GetSupplierListDDL")]
        [SwaggerOperation(Description = "Example { AccountId: 0 ,UnitId=0}")]
        public async Task<IActionResult> GetSupplierListDDL(long AccountId, long UnitId, long SBUId)
        {
            try
            {
                var dt = await _IRepository.GetSupplierListDDL(AccountId, UnitId, SBUId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetSupplierDDL")]
        [SwaggerOperation(Description = "Example { AccountId: 0 ,UnitId=0}")]
        public async Task<IActionResult> GetSupplierDDL(long AccountId, long UnitId)
        {
            try
            {
                var dt = await _IRepository.GetSupplierDDL(AccountId, UnitId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpGet]
        [Route("GetPurchaseOrderDDL")]
        public async Task<IActionResult> GetPurchaseOrderDDL(long AccountId, long BusinessUnitId, long SBUId, long PurchaseOrganizationId, long PlantId, long WarehouseId, long SupplierId)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseOrderDDL(AccountId, BusinessUnitId, SBUId,PurchaseOrganizationId,PlantId,WarehouseId, SupplierId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        [HttpGet]
        [Route("GetPurchaseOrderPIDDL")]
        public async Task<IActionResult> GetPurchaseOrderPIDDL(long AccountId, long BusinessUnitId, long SBUId)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseOrderPIDDL( AccountId,  BusinessUnitId,  SBUId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpGet]
        [Route("GetIncotermListDDL")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetIncotermListDDL()
        {
            try
            {
                var dt = await _IRepository.GetIncotermListDDL();
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetOrderTypeListDDL")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetOrderTypeListDDL()
        {
            try
            {
                var dt = await _IRepository.GetOrderTypeListDDL();
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPaymentTermsListDDL")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetPaymentTermsListDDL()
        {
            try
            {
                var dt = await _IRepository.GetPaymentTermsListDDL();
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpGet]
        [Route("GetPlantDDLFromPO")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetPlantDDLFromPO(long AccountId, long BusinessUnitId)
        {
            try
            {
                var dt = await _IRepository.GetPlantDDLFromPOH(AccountId, BusinessUnitId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetWearHouseDDLFromPO")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetWearHouseDDLFromPO(long AccountId, long BusinessUnitId, long plantId)
        {
            try
            {
                var dt = await _IRepository.GetWearHouseDDLFromPOH(AccountId, BusinessUnitId, plantId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("getPOReferenceType")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> getPOReferenceType(long PoTypeId)
        {
            try
            {
                var dt = await _IRepository.getPOReferenceType(PoTypeId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpGet]
        [Route("GetPOReferenceNoDDL")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetPOReferenceNoDDL(long RefTypeId, long WarehouseId)
        {
            try
            {
                var dt = await _IRepository.GetPOReferenceNoDDL(RefTypeId, WarehouseId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPOReferenceNoWiseItemDDL")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetPOReferenceNoWiseItemDDL(long AccountId, long BusinessUnitId, /*long SbuId,*/ long PurchaseOrganizationId, long PlantId, long WearhouseId, long PartnerId, long RefTypeId, long RefNoId)
        {
            try
            {
                var dt = await _IRepository.GetPOReferenceNoWiseItemDDL( AccountId,  BusinessUnitId, /*long SbuId,*/  PurchaseOrganizationId,  PlantId,  WearhouseId,  PartnerId,  RefTypeId,  RefNoId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

       
        [HttpGet]
        [Route("getWHAddressbyWHId")]
        [SwaggerOperation(Description = "Example {WhId=0 }")]
        public async Task<IActionResult> getWHAddressbyWHId(long WhId)
        {
            try
            {
                var dt = await _IRepository.getWHAddressbyWHId(WhId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("getReferanceNoByPR")]
        [SwaggerOperation(Description = "Example {AccountId=0 ,UnitId=0,referenceTypeId=0}")]
        public async Task<IActionResult> getReferanceNoByPR(long AccountId, long UnitId, long referenceTypeId)
        {
            try
            {
                var dt = await _IRepository.getReferanceNoByPR(AccountId, UnitId, referenceTypeId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpGet]
        [Route("getPRItemList")]
        [SwaggerOperation(Description = "Example {AccountId=0 ,ReferanceTypeId=0}")]
        public async Task<IActionResult> getPRItemList(long PurRequestId, long ReferanceTypeId)
        {
            try
            {
                var dt = await _IRepository.getPRItemList(PurRequestId, ReferanceTypeId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("getPRItemByItemId")]
        [SwaggerOperation(Description = "Example {AccountId=0 ,ReferanceTypeId=0, ItemId=0}")]
        public async Task<IActionResult> getPRItemByItemId(long RequestId, long ReferanceTypeId, long ItemId)
        {
            try
            {
                var dt = await _IRepository.getPRItemByItemId(RequestId, ReferanceTypeId, ItemId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("getBOM")]
        [SwaggerOperation(Description = "Example {AccountId=0 ,UnitId=0,PlantId=0}")]
        public async Task<IActionResult> getBOM(long AccountId, long UnitId, long PlantId , long ItemId)
        {
            try
            {
                var dt = await _IRepository.getBOM(AccountId, UnitId, PlantId, ItemId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetCostCenter")]
        [SwaggerOperation(Description = "Example {AccountId=0 ,UnitId=0}")]
        public async Task<IActionResult> GetCostCenter(long AccountId, long UnitId)
        {
            try
            {
                var dt = await _IRepository.GetCostCenter(AccountId, UnitId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetControllingUnit")]
        [SwaggerOperation(Description = "Example {AccountId=0 ,UnitId=0}")]
        public async Task<IActionResult> GetControllingUnit(long AccountId, long UnitId)
        {
            try
            {
                var dt = await _IRepository.GetControllingUnit(AccountId, UnitId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetCostElement")]
        [SwaggerOperation(Description = "Example {AccountId=0 ,UnitId=0}")]
        public async Task<IActionResult> GetCostElement(long AccountId, long UnitId, long ControllingUnitId)
        {
            try
            {
                var dt = await _IRepository.GetCostElement(AccountId, UnitId, ControllingUnitId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpGet]
        [Route("getPurchaseContactHeaderInfo")]
        [SwaggerOperation(Description = "Example {PurchaseContactId=0}")]
        public async Task<IActionResult> getPurchaseContactHeaderInfo(long PurchaseContactId)
        {
            try
            {
                var dt = await _IRepository.getPurchaseContactHeaderInfo(PurchaseContactId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPurchaseOrderInformationByPO_Id")]
        [SwaggerOperation(Description = "Example {PurchaseOrderId=0}")]
        public async Task<IActionResult> GetPurchaseOrderInformationByPO_Id(long PurchaseOrderId)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseOrderInformationByPO_Id(PurchaseOrderId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpGet]
        [Route("getPriceStructure")]
        [SwaggerOperation(Description = "Example {accountid=0,unitid=0}")]
        public async Task<IActionResult> getPriceStructure(long AccountId, long UnitId)
        {
            try
            {
                var dt = await _IRepository.getPriceStructure(AccountId, UnitId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpPost]
        [Route("CreatePurchaseContact")]
        [SwaggerOperation(Description = "Example {DTO}")]
        public async Task<IActionResult> CreatePurchaseContact(CreatePurchaseContactCommonDTO objPC)
        {
            try
            {
                var dt = await _IRepository.CreatePurchaseContact(objPC);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpGet]
        [Route("GetPurchaseOrderInformationPasignation")]
        [SwaggerOperation(Description = "Example {accountid=0,unitid=0}")]
        public async Task<IActionResult> GetPurchaseOrderInformationPasignation(long AccountId, long UnitId, long Sbu, long Plant, long WearHouse,long PurchaseOrderTypeId,long PurchaseOrganizationId,long ReferenceTypeId, bool isApproved, string viewOrder, long PageNo, long PageSize)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseOrderInformationPasignation(AccountId, UnitId, Sbu, Plant, WearHouse, PurchaseOrderTypeId, PurchaseOrganizationId, ReferenceTypeId, isApproved, viewOrder, PageNo, PageSize);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPriceStructureList")]
        [SwaggerOperation(Description = "Example {}")]
        public async Task<IActionResult> GetPriceStructureList(long AccountId, long BusinessUnitId, long PriceStructureId)
        {
            try
            {
                var dt = await _IRepository.GetPriceStructureList(AccountId, BusinessUnitId, PriceStructureId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpGet]
        [Route("GetBillOfMaterialList")]
        [SwaggerOperation(Description = "Example {}")]
        public async Task<IActionResult> GetBillOfMaterialList(long AccountId, long BusinessUnitId, long BillOfMaterialId)
        {
            try
            {
                var dt = await _IRepository.GetBillOfMaterialList(AccountId, BusinessUnitId, BillOfMaterialId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPut]
        [Route("EditPurchaseOrder")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> EditPurchaseOrder(EditPurchaseOrderCommonDTO objPO)
        {
            try
            {
                var msg = new MessageHelper();
                msg = await _IRepository.EditPurchaseOrder(objPO);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpPut]
        [Route("EditPurchaseContact")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> EditPurchaseContact(EditPurchaseContactCommonDTO objPO)
        {
            try
            {
                var msg = new MessageHelper();
                msg = await _IRepository.EditPurchaseContact(objPO);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpGet]
        [Route("GetPOItemByItemId")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetPOItemByItemId(long RequestId, long ReferanceTypeId, long ItemId, string ReferanceTypeName)
        {
            try
            {
                var dt = await _IRepository.GetPOItemByItemId(RequestId, ReferanceTypeId, ItemId, ReferanceTypeName);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPOItemListInfo")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetPOItemListInfo(long RequestId, long ReferanceTypeId, string ReferanceTypeName)
        {
            try
            {
                var dt = await _IRepository.GetPOItemListInfo(RequestId, ReferanceTypeId, ReferanceTypeName);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPriceStructureByPartnerId")]
        [SwaggerOperation(Description = "Example { }")]
        public async Task<IActionResult> GetPriceStructureByPartnerId(long AccountId, long UnitId, long PartnerId)
        {
            try
            {
                var dt = await _IRepository.GetPriceStructureByPartnerId(AccountId, UnitId, PartnerId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPONoDDL")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetPONoDDL(long AccountId, long BusinessUnitId, long WarehouseId)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseOrderPIDDL(AccountId, BusinessUnitId, WarehouseId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpGet]
        [Route("GetPurchaseOrderInformationSearchPasignation")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetPurchaseOrderInformationSearchPasignation(string searchTerm, long AccountId, long UnitId, long Sbu, long Plant, long WearHouse, long PurchaseOrderTypeId, long PurchaseOrganizationId, long ReferenceTypeId, bool isApproved, string viewOrder, long PageNo, long PageSize)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseOrderInformationSearchPasignation( searchTerm,  AccountId,  UnitId,  Sbu, Plant, WearHouse,  PurchaseOrderTypeId,  PurchaseOrganizationId, ReferenceTypeId, isApproved,  viewOrder,  PageNo,  PageSize);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
