﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain.Core.Bus;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Procurement.DTO.PurchaseRequestApproval;
using Procurement.Helper;
using Procurement.IRepository;
using Swashbuckle.AspNetCore.Annotations;

namespace Procurement.Controllers
{
    [Route("procurement/[controller]")]
    [ApiController]
    public class PurchaseRequestApprovalController : ControllerBase
    {
        private readonly IEventBus _bus;
        private readonly IMediator _mediator;
        public readonly IPurchaseRequestApproval _IRepository;

        public PurchaseRequestApprovalController(IMediator mediator, IEventBus bus, IPurchaseRequestApproval IRepository)
        {
            _bus = bus;
            _mediator = mediator;
            _IRepository = IRepository;
        }

        [HttpGet]
        [Route("GetPurchaseRequestApproveLandingPagination")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetPurchaseRequestApproveLandingPagination(long accountId, long businessUnitId, long plantId, long warehouseId, long PageNo, long PageSize, string viewOrder)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseRequestApproveLandingPagination(accountId, businessUnitId, plantId, warehouseId, PageNo, PageSize, viewOrder);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPurchaseRequestApproveList")]
        [SwaggerOperation(Description = "Example { email: 0 }")]
        public async Task<IActionResult> GetPurchaseRequestApproveList(long accountId, long businessUnitId, long plantId, long warehouseId)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseRequestApproveList(accountId, businessUnitId, plantId, warehouseId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetPurchaseRequestInformationByRequestId")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<IActionResult> GetPurchaseRequestInformationByRequestId(long PurchaseRequestId)
        {
            try
            {
                var dt = await _IRepository.GetPurchaseRequestInformationByRequestId(PurchaseRequestId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPut]
        [Route("EditPurchaseRequestApprove")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> EditPurchaseRequestApprove(EditPurchaseRequestApproveCommonDTO editPurchaseRequestCommonDTO)
        {
            try
            {
                var msg = await _IRepository.EditPurchaseRequestApprove(editPurchaseRequestCommonDTO);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPut]
        [Route("UpdateStatusPurchaseRequestApprove")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> UpdateStatusPurchaseRequestApprove(UpdateStatusPurchaseRequestHeaderApprDTO objDTO)
        {
            try
            {
                var msg = await _IRepository.UpdateStatusPurchaseRequestApprove(objDTO);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}