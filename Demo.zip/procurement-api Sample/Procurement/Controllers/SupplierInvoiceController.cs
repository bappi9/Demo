﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Procurement.DTO.SupplierInvoice;
using Procurement.Helper;
using Procurement.IRepository;

namespace Procurement.Controllers
{
    [Route("procurement/[controller]")]
    [ApiController]
    public class SupplierInvoiceController : ControllerBase
    {
        public readonly ISupplierInvoice _IRepository;
        public SupplierInvoiceController(ISupplierInvoice IRepository)
        {
            _IRepository = IRepository;
        }

        [HttpGet]
        [Route("GetPSupplierInvoicePasignation")]
        public async Task<IActionResult> GetSupplierInvoicePasignation(long AccountId, long UnitId, long SbuId, long Plant, long WearHouse, long PurchaseOrganizationId, string viewOrder, long PageNo, long PageSize)
        {
            try
            {
                var dt = await _IRepository.GetSupplierInvoicePasignation( AccountId,  UnitId,  SbuId,  Plant,  WearHouse,  PurchaseOrganizationId,  viewOrder,  PageNo,  PageSize);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpGet]
        [Route("GetSupplierInvoiceSearchPasignation")]
        public async Task<IActionResult> GetSupplierInvoiceSearchPasignation(string searchTerm, long AccountId, long UnitId, long SbuId, long Plant, long WearHouse, long PurchaseOrganizationId, string viewOrder, long PageNo, long PageSize)
        {
            try
            {
                var dt = await _IRepository.GetSupplierInvoiceSearchPasignation(searchTerm, AccountId,  UnitId,  SbuId,  Plant,  WearHouse,  PurchaseOrganizationId,  viewOrder,  PageNo,  PageSize);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetSupplierInvoiceById")]
        
        public async Task<IActionResult> GetSupplierInvoiceById(long SupplierInvoiceId)
        {
            try
            {
                var dt = await _IRepository.GetSupplierInvoiceCommonDTOById(SupplierInvoiceId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        [Route("CreateSupplierInvoice")]
        public async Task<MessageHelper> CreateSupplierInvoice(CreateSupplierInvoiceCommonDTO objSI)
        {
            try
            {
                var msg = await _IRepository.CreateSupplierInvoice(objSI);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPut]
        [Route("EditSupplierInvoice")]
        
        public async Task<MessageHelper> EditSupplierInvoice(EditSupplierInvoiceCommonDTO objESI)
        {
            try
            {
                var msg = new MessageHelper();
                msg = await _IRepository.EditSupplierInvoice(objESI);
                return msg;     
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}