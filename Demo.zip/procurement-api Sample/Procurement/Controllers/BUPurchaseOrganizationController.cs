﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain.Core.Bus;
using MediatR;
using Microsoft.AspNet.OData;
using Microsoft.AspNet.OData.Routing;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Procurement.DTO.BusinessUnitPurchaseOrganization;
using Procurement.Helper;
using Procurement.IRepository;
using Swashbuckle.AspNetCore.Annotations;

namespace Procurement.Controllers
{
    [Route("procurement/[controller]")]
    [ApiController]
    public class BUPurchaseOrganizationController : ControllerBase
    {
        private readonly IEventBus _bus;
        private readonly IMediator _mediator;

        private readonly IBUPurchaseOrganization _IRepository;

        public BUPurchaseOrganizationController(IMediator mediator, IEventBus bus, IBUPurchaseOrganization IRepository)
        {
            _bus = bus;
            _mediator = mediator;
            _IRepository = IRepository;
        }


        [HttpPost]
        [Route("CreateBusinessUnitPurchaseOrganization")]
        [SwaggerOperation(Description = "Example { ")]
        public async Task<MessageHelper> CreateBusinessUnitPurchaseOrganization(CreateBusinessUnitPurchaseOrganizationDTO objCreateBUPO)
        {
            try
            {
                var msg = await _IRepository.CreateBusinessUnitPurchaseOrganization(objCreateBUPO);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPut]
        [Route("EditBusinessUnitPurchaseOrganization")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> EditBusinessUnitPurchaseOrganization(EditBusinessUnitPurchaseOrganizationDTO objEditBUPO)
        {
            try
            {
                var msg = new MessageHelper();
                msg = await _IRepository.EditBusinessUnitPurchaseOrganization(objEditBUPO);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPut]
        [Route("UpdateStatusBUPurchaseOrganization")]
        [SwaggerOperation(Description = "Example {  }")]
        public async Task<MessageHelper> UpdateStatusBUPurchaseOrganization(UpdateStatusBUPurchaseOrganizationDTO objUpdateStatusBUPO)
        {
            try
            {
                var msg = new MessageHelper();
                msg = await _IRepository.UpdateStatusBUPurchaseOrganization(objUpdateStatusBUPO);
                return msg;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
         
        [Route("GetBUPurchaseOrganizationLandingPagination")]
        [SwaggerOperation(Description = "Example { ")]
        public async Task<IActionResult> GetBUPurchaseOrganizationLandingPagination(long AccountId, long BusinessUnitId, bool status, long PageNo, long PageSize, string viewOrder)
        {
            try
            {
                var dt = await _IRepository.GetBUPurchaseOrganizationLandingPagination(AccountId, BusinessUnitId, status, PageNo, PageSize, viewOrder);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [EnableQuery()]
        [Route("GetBUPurchaseOrganizationById")]
        [SwaggerOperation(Description = "Example { ConfigID: 0 }")]
        public async Task<IActionResult> GetBUPurchaseOrganizationById(long ConfigID)
        {
            try
            {
                var dt = await _IRepository.GetBUPurchaseOrganizationById(ConfigID);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetBUPurchaseOrganizationDDL")]
        [SwaggerOperation(Description = "Example { ConfigID: 0 }")]
        public async Task<IActionResult> GetBUPurchaseOrganizationDDL(long AccountId, long BusinessUnitId)
        {
            try
            {
                var dt = await _IRepository.GetBUPurchaseOrganizationDDL( AccountId,  BusinessUnitId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpGet]
        [ODataRoute("GetBUPurchaseOrganization(AccountId={AccountId},BusinessUnitId={BusinessUnitId})")]
       // [Route("GetBUPurchaseOrganization")]
        [SwaggerOperation(Description = "Example")]
        public async Task<IActionResult> GetBUPurchaseOrganization([FromODataUri] long AccountId, [FromODataUri] long BusinessUnitId)
        {
            try
            {
                var dt = await _IRepository.GetBUPurchaseOrganization(AccountId, BusinessUnitId);
                if (dt == null)
                {
                    return NotFound();
                }
                return Ok(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}